package io.latchkey.bridge;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PersistableBundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int REQ_STORAGE = 11;
    private static final int REQ_NOTIFICATIONS = 12;

    private TextView statusDot;
    private TextView statusText;
    private TextView endpointText;
    private TextView permText;
    private TextView pairHint;
    private TextView clientsText;
    private TextView keyText;
    private TextView fingerprintText;
    private TextView statsText;
    private Button permBtn;
    private Button pairBtn;
    private Button revokeClientsBtn;
    private Button copyBtn;
    private Button regenBtn;
    private Button startBtn;
    private Button batteryBtn;
    private Button viewLogBtn;
    private Button exportLogBtn;
    private Button clearLogBtn;

    private String key = "";
    private boolean keyVisible = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm:ss", Locale.US);

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventLog.init(this);
        EventLog.info("app", "create", "MainActivity created");
        setContentView(R.layout.activity_main);
        View root = findViewById(R.id.content);
        bindViews();
        applyInsets(root);

        key = KeyStoreManager.getOrCreateKey(this);
        updateKeyViews();

        keyText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                keyVisible = !keyVisible;
                EventLog.info("ui", "key", keyVisible ? "key revealed" : "key hidden");
                updateKeyViews();
            }
        });
        permBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EventLog.info("ui", "permission", "opened all-files settings");
                openAllFilesSettings();
            }
        });
        pairBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pairAssistant();
            }
        });
        revokeClientsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmRevokeClients();
            }
        });
        copyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                copyKey();
            }
        });
        regenBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EventLog.info("ui", "regenerate", "key regeneration confirmation opened");
                confirmRegenerate();
            }
        });
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ServerRuntime.running) {
                    EventLog.info("ui", "stop", "stop requested from activity");
                    LatchkeyService.stop(MainActivity.this);
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            refresh();
                        }
                    }, 350L);
                } else {
                    startServer();
                }
            }
        });
        batteryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EventLog.info("ui", "battery", "battery exemption requested");
                requestBatteryExemption();
            }
        });
        viewLogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showLog();
            }
        });
        exportLogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exportLog();
            }
        });
        clearLogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearLog();
            }
        });

        refresh();
    }

    private void bindViews() {
        statusDot = (TextView) findViewById(R.id.statusDot);
        statusText = (TextView) findViewById(R.id.statusText);
        endpointText = (TextView) findViewById(R.id.endpointText);
        permText = (TextView) findViewById(R.id.permText);
        pairHint = (TextView) findViewById(R.id.pairHint);
        clientsText = (TextView) findViewById(R.id.clientsText);
        keyText = (TextView) findViewById(R.id.keyText);
        fingerprintText = (TextView) findViewById(R.id.fingerprintText);
        statsText = (TextView) findViewById(R.id.statsText);
        permBtn = (Button) findViewById(R.id.permBtn);
        pairBtn = (Button) findViewById(R.id.pairBtn);
        revokeClientsBtn = (Button) findViewById(R.id.revokeClientsBtn);
        copyBtn = (Button) findViewById(R.id.copyBtn);
        regenBtn = (Button) findViewById(R.id.regenBtn);
        startBtn = (Button) findViewById(R.id.startBtn);
        batteryBtn = (Button) findViewById(R.id.batteryBtn);
        viewLogBtn = (Button) findViewById(R.id.viewLogBtn);
        exportLogBtn = (Button) findViewById(R.id.exportLogBtn);
        clearLogBtn = (Button) findViewById(R.id.clearLogBtn);
    }

    private void applyInsets(View root) {
        final int horizontal = dp(20);
        final int vertical = dp(20);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                if (Build.VERSION.SDK_INT >= 30) {
                    Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                            | WindowInsets.Type.displayCutout());
                    top = bars.top;
                    bottom = bars.bottom;
                }
                view.setPadding(horizontal, vertical + top, horizontal, vertical + bottom);
                return insets;
            }
        });
        root.requestApplyInsets();
    }

    @Override
    protected void onResume() {
        super.onResume();
        EventLog.info("app", "resume", "MainActivity resumed");
        handler.removeCallbacks(ticker);
        refresh();
        handler.postDelayed(ticker, 1000L);
    }

    @Override
    protected void onPause() {
        EventLog.info("app", "pause", "MainActivity paused");
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        EventLog.info("app", "destroy", "MainActivity destroyed");
        super.onDestroy();
    }

    private void updateKeyViews() {
        keyText.setText(keyVisible ? key : getString(R.string.key_hidden));
        try {
            String fingerprint = Crypto.fingerprint(Crypto.decodeKey(key));
            if (KeyStoreManager.isPersisted()) {
                fingerprintText.setText("SHA-256  " + fingerprint);
                fingerprintText.setTextColor(getColor(R.color.muted));
            } else {
                fingerprintText.setText("SHA-256  " + fingerprint + "\n"
                        + KeyStoreManager.storageWarning());
                fingerprintText.setTextColor(getColor(R.color.bad));
            }
        } catch (Exception e) {
            fingerprintText.setText("SHA-256  unavailable");
            fingerprintText.setTextColor(getColor(R.color.bad));
        }
    }

    private void refresh() {
        boolean running = ServerRuntime.running;
        boolean error = !running && ServerRuntime.lastError != null;

        if (running) {
            statusDot.setTextColor(getColor(R.color.ok));
            statusText.setText(R.string.status_running);
            endpointText.setText("127.0.0.1:" + ServerRuntime.port
                    + "  \u2022  up " + formatUptime(ServerRuntime.uptimeMs()));
            startBtn.setText(R.string.btn_stop);
            startBtn.setBackgroundResource(R.drawable.bg_button_stop);
        } else if (error) {
            statusDot.setTextColor(getColor(R.color.bad));
            statusText.setText(R.string.status_error);
            endpointText.setText(ServerRuntime.lastError);
            startBtn.setText(R.string.btn_start);
            startBtn.setBackgroundResource(R.drawable.bg_button_primary);
        } else {
            statusDot.setTextColor(getColor(R.color.muted));
            statusText.setText(R.string.status_stopped);
            endpointText.setText("127.0.0.1:" + ServerRuntime.PORT + "  \u2022  not running");
            startBtn.setText(R.string.btn_start);
            startBtn.setBackgroundResource(R.drawable.bg_button_primary);
        }

        boolean granted = hasAllFilesAccess();
        if (granted) {
            permText.setText(R.string.perm_granted);
            permText.setTextColor(getColor(R.color.ok));
            permBtn.setText("Manage");
            permBtn.setBackgroundResource(R.drawable.bg_button_secondary);
            permBtn.setTextColor(getColor(R.color.btn_secondary_text));
        } else {
            permText.setText("Not granted \u2014 file access will fail");
            permText.setTextColor(getColor(R.color.bad));
            permBtn.setText(R.string.btn_grant);
            permBtn.setBackgroundResource(R.drawable.bg_button_primary);
            permBtn.setTextColor(getColor(R.color.on_accent));
        }

        statsText.setText("requests " + ServerRuntime.requests.get()
                + "  \u2022  in " + human(ServerRuntime.bytesIn.get())
                + "  \u2022  out " + human(ServerRuntime.bytesOut.get())
                + "  \u2022  auth fails " + ServerRuntime.authFailures.get()
                + "\nlast  " + ServerRuntime.lastOp + "  " + shorten(ServerRuntime.lastPath, 34)
                + "  " + ServerRuntime.lastMs + " ms");
        updateClientViews();
    }

    private void updateClientViews() {
        int count = PairStore.count(this);
        if (count == 0) {
            clientsText.setText(R.string.clients_none);
        } else if (count == 1) {
            clientsText.setText(R.string.clients_one);
        } else {
            clientsText.setText(getString(R.string.clients_many, count));
        }
        revokeClientsBtn.setVisibility(count == 0 ? View.GONE : View.VISIBLE);
    }

    private void pairAssistant() {
        if (!ServerRuntime.running) {
            Toast.makeText(this, "Start the server first", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            String link = PairingManager.createLink(this, appFingerprint(),
                    ServerRuntime.port);
            ClipboardManager clipboard =
                    (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard == null) {
                Toast.makeText(this, "Clipboard unavailable", Toast.LENGTH_SHORT).show();
                return;
            }
            ClipData clip = ClipData.newPlainText("Latchkey pairing link", link);
            if (Build.VERSION.SDK_INT >= 33) {
                PersistableBundle extras = new PersistableBundle();
                extras.putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true);
                clip.getDescription().setExtras(extras);
            }
            clipboard.setPrimaryClip(clip);
            pairHint.setText(R.string.pair_copied);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    pairHint.setText(R.string.pair_hint);
                }
            }, 5000L);
            Toast.makeText(this, "Pairing link copied", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            String message = e.getMessage();
            if (message == null || message.length() == 0) {
                message = e.getClass().getSimpleName();
            }
            EventLog.error("pair", "link-failed", message);
            Toast.makeText(this, "Could not create pairing link",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void confirmRevokeClients() {
        final int count = PairStore.count(this);
        if (count == 0) {
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Revoke paired assistants and rotate key?")
                .setMessage(count + (count == 1 ? " assistant" : " assistants")
                        + " will lose access immediately and the legacy key will be regenerated.")
                .setPositiveButton("Revoke & rotate", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int revoked = PairManager.revokeAll(MainActivity.this);
                        String newKey = PairManager.regenerateKey(MainActivity.this);
                        EventLog.warn("key", "regenerate",
                                "access key regenerated from app revoke");
                        key = KeyStoreManager.getOrCreateKey(MainActivity.this);
                        updateKeyViews();
                        updateClientViews();
                        LatchkeyService.restart(MainActivity.this);
                        Toast.makeText(MainActivity.this,
                                "Revoked " + revoked + (revoked == 1 ? " assistant" : " assistants")
                                        + " · key rotated",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String appFingerprint() {
        try {
            int flags = Build.VERSION.SDK_INT >= 28
                    ? PackageManager.GET_SIGNING_CERTIFICATES
                    : PackageManager.GET_SIGNATURES;
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), flags);
            Signature[] signatures = null;
            if (Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) {
                signatures = info.signingInfo.getApkContentsSigners();
            } else if (info.signatures != null) {
                signatures = info.signatures;
            }
            if (signatures != null && signatures.length > 0) {
                return Crypto.fingerprint(signatures[0].toByteArray());
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private void showLog() {
        String text = EventLog.snapshotText(500, clock);
        if (text.length() == 0) {
            text = "No activity yet.";
        }
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextIsSelectable(true);
        view.setTypeface(Typeface.MONOSPACE);
        view.setTextSize(11);
        int padding = dp(16);
        view.setPadding(padding, padding, padding, padding);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(view);
        new AlertDialog.Builder(this)
                .setTitle("Activity log (last 500)")
                .setView(scroll)
                .setPositiveButton("Close", null)
                .show();
        EventLog.info("log", "view", "recent activity log viewed");
    }

    private void exportLog() {
        final File directory = new File(
                Environment.getExternalStorageDirectory(), "Download/Latchkey/logs");
        final String name = "latchkey-events-"
                + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date())
                + ".jsonl";
        final File destination = new File(directory, name);
        EventLog.info("log", "export", "activity log export requested");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    long bytes = EventLog.exportTo(destination);
                    EventLog.info("log", "exported", bytes + " bytes exported",
                            Json.put(Json.obj(), "path", destination.getAbsolutePath()));
                    final String message = "Exported " + human(bytes) + " to "
                            + destination.getAbsolutePath();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, message,
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (final Exception e) {
                    String message = e.getMessage();
                    if (message == null || message.length() == 0) {
                        message = e.getClass().getSimpleName();
                    }
                    EventLog.error("log", "export-failed", message);
                    final String text = message;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this,
                                    "Export failed: " + text, Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }, "latchkey-log-export").start();
    }

    private void clearLog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.clear_log_title)
                .setMessage(R.string.clear_log_message)
                .setPositiveButton(R.string.btn_clear_log,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            JSONObject cleared = EventLog.clear();
                                            int files = cleared.optInt("files", 0);
                                            long bytes = cleared.optLong("bytes", 0L);
                                            final String message = "Cleared " + files
                                                    + " log file(s), " + human(bytes);
                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    Toast.makeText(MainActivity.this,
                                                            message, Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                        } catch (final Exception e) {
                                            String message = e.getMessage();
                                            if (message == null || message.length() == 0) {
                                                message = e.getClass().getSimpleName();
                                            }
                                            EventLog.error("log", "clear-failed", message);
                                            final String text = message;
                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    Toast.makeText(MainActivity.this,
                                                            "Clear failed: " + text,
                                                            Toast.LENGTH_LONG).show();
                                                }
                                            });
                                        }
                                    }
                                }, "latchkey-log-clear").start();
                            }
                        })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startServer() {
        EventLog.info("ui", "start", "start requested from activity");
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIFICATIONS);
        }
        if (!hasAllFilesAccess()) {
            EventLog.warn("permission", "missing", "all-files access is not granted");
            Toast.makeText(this, "Grant all-files access for file reads and writes",
                    Toast.LENGTH_LONG).show();
        }
        LatchkeyService.start(this);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                refresh();
            }
        }, 600L);
    }

    private void copyKey() {
        ClipboardManager clipboard =
                (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null) {
            Toast.makeText(this, "Clipboard unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipData clip = ClipData.newPlainText("Latchkey access key", key);
        if (Build.VERSION.SDK_INT >= 33) {
            PersistableBundle extras = new PersistableBundle();
            extras.putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true);
            clip.getDescription().setExtras(extras);
        }
        clipboard.setPrimaryClip(clip);
        EventLog.info("key", "copy", "access key copied to clipboard");
        Toast.makeText(this, "Key copied", Toast.LENGTH_SHORT).show();
    }

    private void confirmRegenerate() {
        new AlertDialog.Builder(this)
                .setTitle("Generate a new key?")
                .setMessage("The legacy key stops working immediately. "
                        + "Paired assistants keep access until you revoke them. "
                        + "The server will restart with the new key.")
                .setPositiveButton("New key", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        boolean wasRunning = ServerRuntime.running;
                        key = KeyStoreManager.regenerate(MainActivity.this);
                        keyVisible = false;
                        updateKeyViews();
                        if (wasRunning) {
                            EventLog.warn("key", "restart", "restarting server after key change");
                            LatchkeyService.restart(MainActivity.this);
                        }
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                refresh();
                            }
                        }, 700L);
                        Toast.makeText(MainActivity.this, "New key generated",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void openAllFilesSettings() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                return;
            } catch (Exception ignored) {
            }
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                return;
            } catch (Exception ignored) {
            }
        }
        requestPermissions(new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        }, REQ_STORAGE);
    }

    private void requestBatteryExemption() {
        PowerManager power = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (power != null && power.isIgnoringBatteryOptimizations(getPackageName())) {
            EventLog.info("battery", "already-exempt", "battery optimization already disabled");
            Toast.makeText(this, "Battery optimization already disabled",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception first) {
            try {
                startActivity(new Intent(
                        Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception second) {
                EventLog.warn("battery", "unavailable", "battery settings unavailable");
                Toast.makeText(this, "Battery settings unavailable",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean hasAllFilesAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        int granted = 0;
        for (int result : grantResults) {
            if (result == PackageManager.PERMISSION_GRANTED) {
                granted++;
            }
        }
        EventLog.info("permission", "result", "request=" + requestCode
                + " granted=" + granted + "/" + grantResults.length);
        refresh();
    }

    private static String shorten(String text, int max) {
        if (text == null) {
            return "";
        }
        if (text.length() <= max) {
            return text;
        }
        return "\u2026" + text.substring(text.length() - Math.max(0, max - 1));
    }

    private static String human(long bytes) {
        if (bytes < 1024L) {
            return bytes + " B";
        }
        double value = bytes / 1024.0;
        if (value < 1024.0) {
            return String.format(Locale.US, "%.1f KiB", value);
        }
        value /= 1024.0;
        if (value < 1024.0) {
            return String.format(Locale.US, "%.1f MiB", value);
        }
        value /= 1024.0;
        return String.format(Locale.US, "%.2f GiB", value);
    }

    private static String formatUptime(long ms) {
        long seconds = ms / 1000L;
        if (seconds < 60L) {
            return seconds + "s";
        }
        long minutes = seconds / 60L;
        if (minutes < 60L) {
            return minutes + "m " + (seconds % 60L) + "s";
        }
        long hours = minutes / 60L;
        return hours + "h " + (minutes % 60L) + "m";
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}

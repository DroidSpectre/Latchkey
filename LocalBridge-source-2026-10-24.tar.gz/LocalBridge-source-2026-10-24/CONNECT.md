# Connect to the running APK

The client auto-loads the token from `/root/.config/localbridge/token`.

```sh
python3 agent/localbridge_client.py ping
python3 agent/localbridge_client.py ls .
python3 agent/localbridge_client.py stat Download
```

If the token file is not present, open LocalBridge and copy the token shown in
the app, then use:

```sh
python3 agent/localbridge_client.py --token '<token>' ping
```

`agent/connect.sh` runs the same client with its token lookup unchanged.
The bridge is loopback-only; the APK must be running on the same device.

#!/bin/bash
set -euo pipefail

export JAVA_HOME=/opt/jdk-17.0.20.1+1-jre
export PATH="$JAVA_HOME/bin:$PATH"

ROOT=/root/LocalBridge
SDK=/opt/android-sdk
BT="$SDK/build-tools/36.0.0"
ANDROID_JAR="$SDK/platforms/android-36/android.jar"
JAVA="$JAVA_HOME/bin/java"
KEYTOOL="$JAVA_HOME/bin/keytool"
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON="$ROOT/test-lib/json-20240303.jar"
KEYDIR=/root/.local/share/localbridge
KEYSTORE="$KEYDIR/localbridge.keystore"
PASSFILE="$KEYDIR/keystore.pass"
OUT="$ROOT/build"
APK="$OUT/LocalBridge.apk"

python3 - <<'PY'
import os, shutil
for d in ['/root/LocalBridge/build/classes', '/root/LocalBridge/build/dex']:
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d, exist_ok=True)
for p in ['/root/LocalBridge/build/res.zip', '/root/LocalBridge/build/base.apk',
          '/root/LocalBridge/build/classes.jar', '/root/LocalBridge/build/unsigned.apk',
          '/root/LocalBridge/build/aligned.apk']:
    if os.path.exists(p):
        os.remove(p)
PY

"$BT/aapt2" compile --dir "$ROOT/res" -o "$OUT/res.zip"
"$BT/aapt2" link -o "$OUT/base.apk" -I "$ANDROID_JAR" \
    --manifest "$ROOT/AndroidManifest.xml" "$OUT/res.zip"

SOURCES=$(python3 - <<'PY'
import glob
print(' '.join(sorted(glob.glob('/root/LocalBridge/src/**/*.java', recursive=True))))
PY
)
"$JAVA" -jar "$ECJ" -source 8 -target 8 -cp "$JSON:$ANDROID_JAR" -d "$OUT/classes" $SOURCES

python3 - <<'PY'
import os, zipfile
src = '/root/LocalBridge/build/classes'
out = '/root/LocalBridge/build/classes.jar'
with zipfile.ZipFile(out, 'w') as z:
    for root, dirs, files in os.walk(src):
        for name in files:
            path = os.path.join(root, name)
            z.write(path, os.path.relpath(path, src))
PY

"$BT/d8" --lib "$ANDROID_JAR" --min-api 30 --output "$OUT/dex" "$OUT/classes.jar"

python3 - <<'PY'
import shutil, zipfile
base = '/root/LocalBridge/build/base.apk'
un = '/root/LocalBridge/build/unsigned.apk'
shutil.copyfile(base, un)
with zipfile.ZipFile(un, 'a') as z:
    z.write('/root/LocalBridge/build/dex/classes.dex', 'classes.dex')
PY

"$BT/zipalign" -f 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

python3 - <<'PY'
import os, secrets, pathlib
keydir = pathlib.Path('/root/.local/share/localbridge')
keydir.mkdir(parents=True, exist_ok=True)
passfile = keydir / 'keystore.pass'
if not passfile.exists():
    passfile.write_text(secrets.token_hex(24))
    os.chmod(passfile, 0o600)
PY

PASS=$(cat "$PASSFILE")
if [ ! -f "$KEYSTORE" ]; then
    "$KEYTOOL" -genkeypair -keystore "$KEYSTORE" -alias localbridge \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass "$PASS" -keypass "$PASS" \
        -dname "CN=LocalBridge" -noprompt
fi

"$BT/apksigner" sign --ks "$KEYSTORE" --ks-key-alias localbridge \
    --ks-pass "pass:$PASS" --key-pass "pass:$PASS" \
    --out "$APK" "$OUT/aligned.apk"

"$BT/apksigner" verify --print-certs "$APK"
"$BT/aapt2" dump badging "$APK" | head -20
python3 - <<'PY'
import os
p = '/root/LocalBridge/build/LocalBridge.apk'
print('APK', p, os.path.getsize(p), 'bytes')
PY

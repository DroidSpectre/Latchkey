package dev.aetherix.localbridge;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.concurrent.atomic.AtomicInteger;

public final class BridgeServer implements Runnable, Closeable {
    public interface Listener {
        void onState(String state);
    }

    private static final int MAX_FRAME = 1024 * 1024;

    private final ServerSocket server;
    private final byte[] token;
    private final FileOps files;
    private final Listener listener;
    private final SecureRandom random = new SecureRandom();
    private final AtomicInteger failures = new AtomicInteger();
    private volatile boolean running = true;
    private volatile Socket client;
    private volatile long lockUntil;

    public BridgeServer(int port, byte[] token, File root, Listener listener) throws IOException {
        this.token = token.clone();
        this.files = new FileOps(root);
        this.listener = listener;
        this.server = new ServerSocket();
        this.server.setReuseAddress(false);
        this.server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 1);
    }

    public int getPort() {
        return server.getLocalPort();
    }

    @Override
    public void run() {
        state("listening");
        while (running) {
            try {
                Socket socket = server.accept();
                client = socket;
                handle(socket);
            } catch (SocketException e) {
                if (running) state("error");
                break;
            } catch (IOException e) {
                if (running) state("error");
            } finally {
                client = null;
            }
        }
        state("stopped");
    }

    private void handle(Socket socket) {
        try (Socket ignored = socket) {
            socket.setSoTimeout(30000);
            InputStream in = socket.getInputStream();
            OutputStream out = socket.getOutputStream();

            if (System.currentTimeMillis() < lockUntil) {
                send(out, Protocol.handshakeError("locked"));
                return;
            }

            byte[] nonceBytes = new byte[32];
            random.nextBytes(nonceBytes);
            String nonce = Hmac.hex(nonceBytes);
            send(out, Protocol.hello(nonce, Hmac.serverProof(token, nonce)));

            String authLine = readLine(in, MAX_FRAME);
            if (authLine == null) return;
            JSONObject auth;
            try {
                auth = Protocol.parseObject(authLine);
            } catch (JSONException e) {
                fail(out);
                return;
            }

            String clientName = auth.optString("client", "");
            String proof = auth.optString("proof", "");
            if (!"auth".equals(auth.optString("type", ""))
                    || !validClientName(clientName) || !Hmac.constantTimeEquals(
                    Hmac.clientProof(token, nonce, clientName), proof)) {
                fail(out);
                return;
            }

            failures.set(0);
            byte[] session = new byte[16];
            random.nextBytes(session);
            send(out, Protocol.ready(Hmac.hex(session)));
            state("authenticated");

            socket.setSoTimeout(120000);
            while (running) {
                String line = readLine(in, MAX_FRAME);
                if (line == null) break;
                JSONObject request;
                long id = 0;
                try {
                    request = Protocol.parseObject(line);
                    id = request.optLong("id", 0);
                    send(out, handleRequest(id, request));
                } catch (JSONException e) {
                    send(out, Protocol.error(id, "bad_request", "invalid JSON"));
                } catch (FileOps.Error e) {
                    send(out, Protocol.error(id, e.code, e.getMessage()));
                } catch (IllegalArgumentException e) {
                    send(out, Protocol.error(id, "bad_request", "invalid argument"));
                } catch (Exception e) {
                    send(out, Protocol.error(id, "io_error", "request failed"));
                }
            }
        } catch (IOException e) {
            state("disconnected");
        }
    }

    private String handleRequest(long id, JSONObject request) throws Exception {
        String op = request.optString("op", "");
        switch (op) {
            case "ping":
                return Protocol.ok(id, new JSONObject().put("time", System.currentTimeMillis()));
            case "stat":
                return Protocol.ok(id, files.stat(required(request, "path")));
            case "list":
                return Protocol.ok(id, files.list(required(request, "path"), request.optInt("limit", 1000)));
            case "read":
                return Protocol.ok(id, files.read(
                        required(request, "path"),
                        request.optLong("offset", 0),
                        request.optInt("length", FileOps.MAX_CHUNK)));
            case "write": {
                String encoded = required(request, "data");
                byte[] data = Base64.getDecoder().decode(encoded);
                return Protocol.ok(id, files.write(
                        required(request, "path"),
                        request.optLong("offset", 0),
                        data,
                        request.optBoolean("truncate", false)));
            }
            case "mkdir":
                return Protocol.ok(id, files.mkdir(required(request, "path"), request.optBoolean("parents", false)));
            case "rename":
                return Protocol.ok(id, files.rename(required(request, "path"), required(request, "to")));
            case "delete":
                return Protocol.ok(id, files.delete(required(request, "path")));
            case "hash":
                return Protocol.ok(id, files.hash(required(request, "path")));
            default:
                return Protocol.error(id, "unsupported", "unknown operation");
        }
    }

    private static String required(JSONObject request, String name) throws JSONException {
        if (!request.has(name) || request.isNull(name)) throw new JSONException("missing " + name);
        return request.getString(name);
    }

    private void fail(OutputStream out) throws IOException {
        int count = failures.incrementAndGet();
        if (count >= 5) {
            lockUntil = System.currentTimeMillis() + 60000;
            failures.set(0);
        }
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        send(out, Protocol.handshakeError("auth_failed"));
        state("auth_failed");
    }

    private static boolean validClientName(String name) {
        if (name == null || name.isEmpty() || name.length() > 64) return false;
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c < 0x20 || c > 0x7e) return false;
        }
        return true;
    }

    private static void send(OutputStream out, String line) throws IOException {
        out.write((line + "\n").getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    private static String readLine(InputStream in, int max) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int value;
        while ((value = in.read()) != -1) {
            if (value == '\n') break;
            if (value != '\r') buffer.write(value);
            if (buffer.size() > max) throw new IOException("frame too large");
        }
        if (value == -1 && buffer.size() == 0) return null;
        return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
    }

    private void state(String value) {
        if (listener != null) listener.onState(value);
    }

    @Override
    public void close() {
        running = false;
        Socket current = client;
        if (current != null) {
            try {
                current.close();
            } catch (IOException ignored) {
            }
        }
        try {
            server.close();
        } catch (IOException ignored) {
        }
    }
}

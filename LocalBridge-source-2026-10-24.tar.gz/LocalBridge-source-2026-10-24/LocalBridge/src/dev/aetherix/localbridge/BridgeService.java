package dev.aetherix.localbridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;

import java.io.File;

public final class BridgeService extends Service {
    public static final String ACTION_START = "dev.aetherix.localbridge.START";
    public static final String ACTION_STOP = "dev.aetherix.localbridge.STOP";
    public static final int PORT = 39401;

    private static final String CHANNEL = "localbridge";
    private static final int NOTIFICATION_ID = 39401;

    private BridgeServer server;
    private Thread thread;
    private static volatile boolean running;

    public static boolean isRunning() {
        return running;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager.getNotificationChannel(CHANNEL) == null) {
            manager.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "LocalBridge", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        startForegroundCompat(notification("Starting"));
        if (ACTION_STOP.equals(action)) {
            stopBridge();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Environment.isExternalStorageManager()) {
            notify("All files access is required");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (server == null) {
            try {
                File root = Environment.getExternalStorageDirectory();
                server = new BridgeServer(PORT, PairingStore.getOrCreate(this), root, this::notify);
                thread = new Thread(server, "localbridge-server");
                thread.start();
                running = true;
                notify("Listening on 127.0.0.1:" + PORT);
            } catch (Exception e) {
                notify("Cannot start: " + e.getMessage());
                stopSelf();
            }
        }
        return START_NOT_STICKY;
    }

    private void stopBridge() {
        running = false;
        if (server != null) {
            server.close();
            server = null;
        }
        if (thread != null) {
            try {
                thread.join(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            thread = null;
        }
    }

    private void startForegroundCompat(Notification notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(
                this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, BridgeService.class).setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(
                this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("LocalBridge")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentIntent(content)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent).build())
                .setOngoing(true)
                .build();
    }

    private void notify(String text) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.notify(NOTIFICATION_ID, notification(text));
    }

    @Override
    public void onDestroy() {
        stopBridge();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

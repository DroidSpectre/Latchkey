package dev.aetherix.localbridge;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;

public final class FileOps {
    public static final int MAX_CHUNK = 512 * 1024;
    private static final int MAX_LIST_BYTES = 800 * 1024;

    public static final class Error extends Exception {
        private static final long serialVersionUID = 1L;

        public final String code;

        public Error(String code, String message) {
            super(message);
            this.code = code;
        }
    }

    private final PathGuard guard;

    public FileOps(File root) throws IOException {
        this.guard = new PathGuard(root);
    }

    public JSONObject stat(String path) throws Error {
        File file = resolve(path);
        if (!file.exists()) throw new Error("not_found", "not found");
        return stat(file);
    }

    public JSONObject list(String path, int limit) throws Error {
        File dir = resolve(path);
        if (!dir.exists()) throw new Error("not_found", "not found");
        if (!dir.isDirectory()) throw new Error("bad_request", "not a directory");
        File[] children = dir.listFiles();
        if (children == null) throw new Error("io_error", "cannot list directory");

        List<File> sorted = new ArrayList<>(Arrays.asList(children));
        sorted.sort(Comparator.comparing(File::getName));

        int max = Math.max(1, Math.min(limit <= 0 ? 1000 : limit, 5000));
        JSONArray entries = new JSONArray();
        int bytes = 0;
        boolean truncated = false;

        for (File child : sorted) {
            if (entries.length() >= max) {
                truncated = true;
                break;
            }
            JSONObject entry = new JSONObject()
                    .put("name", child.getName())
                    .put("type", type(child))
                    .put("size", child.isFile() ? child.length() : 0L)
                    .put("mtime", child.lastModified());
            int size = entry.toString().getBytes(StandardCharsets.UTF_8).length + 1;
            if (bytes + size > MAX_LIST_BYTES) {
                truncated = true;
                break;
            }
            entries.put(entry);
            bytes += size;
        }

        return new JSONObject()
                .put("entries", entries)
                .put("truncated", truncated);
    }

    public JSONObject read(String path, long offset, int length) throws Error {
        File file = resolve(path);
        if (!file.exists()) throw new Error("not_found", "not found");
        if (!file.isFile()) throw new Error("bad_request", "not a file");
        if (offset < 0) throw new Error("bad_request", "negative offset");
        int max = Math.max(1, Math.min(length <= 0 ? MAX_CHUNK : length, MAX_CHUNK));
        long size = file.length();

        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] buffer = new byte[max];
            int count = 0;
            if (offset < size) {
                raf.seek(offset);
                count = raf.read(buffer);
                if (count < 0) count = 0;
            }
            byte[] data = count == buffer.length ? buffer : Arrays.copyOf(buffer, count);
            return new JSONObject()
                    .put("data", Base64.getEncoder().encodeToString(data))
                    .put("offset", offset)
                    .put("length", count)
                    .put("size", size)
                    .put("eof", offset + count >= size);
        } catch (IOException e) {
            throw new Error("io_error", "cannot read file");
        }
    }

    public JSONObject write(String path, long offset, byte[] data, boolean truncate) throws Error {
        if (data == null) throw new Error("bad_request", "missing data");
        if (data.length > MAX_CHUNK) throw new Error("too_large", "chunk too large");
        if (offset < 0) throw new Error("bad_request", "negative offset");

        File file = resolve(path);
        File parent = file.getParentFile();
        if (parent == null || !parent.isDirectory()) throw new Error("not_found", "parent not found");
        if (file.exists() && !file.isFile()) throw new Error("bad_request", "not a file");

        try (RandomAccessFile raf = new RandomAccessFile(file, "rw")) {
            if (truncate) raf.setLength(0);
            raf.seek(offset);
            raf.write(data);
            return new JSONObject()
                    .put("written", data.length)
                    .put("size", raf.length());
        } catch (IOException e) {
            throw new Error("io_error", "cannot write file");
        }
    }

    public JSONObject mkdir(String path, boolean parents) throws Error {
        File dir = resolve(path);
        if (dir.exists()) throw new Error("exists", "already exists");
        boolean created = parents ? dir.mkdirs() : dir.mkdir();
        if (!created) throw new Error("io_error", "cannot create directory");
        return new JSONObject().put("created", true);
    }

    public JSONObject rename(String from, String to) throws Error {
        File source = resolve(from);
        File target = resolve(to);
        if (!source.exists()) throw new Error("not_found", "source not found");
        if (target.exists()) throw new Error("exists", "target exists");
        File parent = target.getParentFile();
        if (parent == null || !parent.isDirectory()) throw new Error("not_found", "target parent not found");
        if (!source.renameTo(target)) throw new Error("io_error", "rename failed");
        return new JSONObject().put("renamed", true);
    }

    public JSONObject delete(String path) throws Error {
        File file = resolve(path);
        if (file.equals(guard.root())) throw new Error("bad_request", "cannot delete storage root");
        if (!file.exists()) throw new Error("not_found", "not found");
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null && children.length > 0) throw new Error("not_empty", "directory not empty");
        }
        if (!file.delete()) throw new Error("io_error", "delete failed");
        return new JSONObject().put("deleted", true);
    }

    public JSONObject hash(String path) throws Error {
        File file = resolve(path);
        if (!file.exists()) throw new Error("not_found", "not found");
        if (!file.isFile()) throw new Error("bad_request", "not a file");
        try (FileInputStream in = new FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = in.read(buffer)) >= 0) {
                digest.update(buffer, 0, count);
            }
            return new JSONObject()
                    .put("algorithm", "sha256")
                    .put("value", Hmac.hex(digest.digest()))
                    .put("size", file.length());
        } catch (Exception e) {
            throw new Error("io_error", "cannot hash file");
        }
    }

    private JSONObject stat(File file) {
        return new JSONObject()
                .put("path", guard.relative(file))
                .put("type", type(file))
                .put("size", file.isFile() ? file.length() : 0L)
                .put("mtime", file.lastModified());
    }

    private File resolve(String path) throws Error {
        try {
            return guard.resolve(path);
        } catch (SecurityException e) {
            throw new Error("bad_path", "path escapes shared storage");
        } catch (IOException e) {
            throw new Error("io_error", "cannot resolve path");
        }
    }

    private static String type(File file) {
        if (file.isDirectory()) return "dir";
        if (file.isFile()) return "file";
        return "other";
    }
}

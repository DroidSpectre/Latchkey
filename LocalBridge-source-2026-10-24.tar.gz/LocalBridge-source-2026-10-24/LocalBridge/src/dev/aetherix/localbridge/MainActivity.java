package dev.aetherix.localbridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private TextView status;
    private TextView token;
    private Button grant;
    private Button start;
    private Button stop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[] { android.Manifest.permission.POST_NOTIFICATIONS }, 1);
        }
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        title.setText("LocalBridge");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 24, 0, 8);
        root.addView(status);

        grant = new Button(this);
        grant.setText("Grant All files access");
        grant.setOnClickListener(v -> openAllFilesSettings());
        root.addView(grant);

        TextView label = new TextView(this);
        label.setText("Pairing token");
        label.setPadding(0, 24, 0, 4);
        root.addView(label);

        token = new TextView(this);
        token.setTextSize(13);
        token.setTypeface(Typeface.MONOSPACE);
        token.setTextIsSelectable(true);
        ScrollView tokenScroll = new ScrollView(this);
        tokenScroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 160));
        tokenScroll.addView(token);
        root.addView(tokenScroll);

        LinearLayout tokenButtons = new LinearLayout(this);
        tokenButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = new Button(this);
        copy.setText("Copy");
        copy.setOnClickListener(v -> copyToken());
        Button regenerate = new Button(this);
        regenerate.setText("Regenerate");
        regenerate.setOnClickListener(v -> confirmRegenerate());
        tokenButtons.addView(copy);
        tokenButtons.addView(regenerate);
        root.addView(tokenButtons);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        start = new Button(this);
        start.setText("Start");
        start.setOnClickListener(v -> startBridge());
        stop = new Button(this);
        stop.setText("Stop");
        stop.setOnClickListener(v -> stopBridge());
        controls.addView(start);
        controls.addView(stop);
        root.addView(controls);

        TextView note = new TextView(this);
        note.setText("Android/data and Android/obb may remain restricted even with All files access.");
        note.setTextSize(12);
        note.setPadding(0, 24, 0, 0);
        root.addView(note);

        return root;
    }

    private void refresh() {
        boolean granted = Environment.isExternalStorageManager();
        status.setText((granted ? "All files access: granted" : "All files access: not granted")
                + "\nServer: " + (BridgeService.isRunning() ? "running on 127.0.0.1:" + BridgeService.PORT : "stopped"));
        grant.setEnabled(!granted);
        token.setText(PairingStore.hex(this));
        start.setEnabled(granted && !BridgeService.isRunning());
        stop.setEnabled(BridgeService.isRunning());
    }

    private void openAllFilesSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
            startActivity(intent);
        }
    }

    private void startBridge() {
        if (!Environment.isExternalStorageManager()) {
            Toast.makeText(this, "Grant All files access first", Toast.LENGTH_SHORT).show();
            openAllFilesSettings();
            return;
        }
        Intent intent = new Intent(this, BridgeService.class).setAction(BridgeService.ACTION_START);
        startForegroundService(intent);
        start.postDelayed(this::refresh, 300);
    }

    private void stopBridge() {
        startService(new Intent(this, BridgeService.class).setAction(BridgeService.ACTION_STOP));
        start.postDelayed(this::refresh, 300);
    }

    private void copyToken() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("LocalBridge token", PairingStore.hex(this)));
        Toast.makeText(this, "Token copied", Toast.LENGTH_SHORT).show();
    }

    private void confirmRegenerate() {
        new AlertDialog.Builder(this)
                .setTitle("Regenerate token?")
                .setMessage("The current token will stop working immediately.")
                .setPositiveButton("Regenerate", (dialog, which) -> {
                    stopService(new Intent(this, BridgeService.class));
                    PairingStore.regenerate(this);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}

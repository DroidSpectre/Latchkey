package dev.aetherix.localbridge;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.SecureRandom;

public final class PairingStore {
    private static final String PREFS = "localbridge";
    private static final String KEY = "token";

    private PairingStore() {
    }

    public static synchronized byte[] getOrCreate(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String value = prefs.getString(KEY, null);
        if (value != null && value.length() == 64) {
            try {
                return Hmac.fromHex(value);
            } catch (IllegalArgumentException ignored) {
            }
        }
        return Hmac.fromHex(regenerate(context));
    }

    public static synchronized String hex(Context context) {
        return Hmac.hex(getOrCreate(context));
    }

    public static synchronized String regenerate(Context context) {
        byte[] token = new byte[32];
        new SecureRandom().nextBytes(token);
        String value = Hmac.hex(token);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY, value)
                .commit();
        return value;
    }
}

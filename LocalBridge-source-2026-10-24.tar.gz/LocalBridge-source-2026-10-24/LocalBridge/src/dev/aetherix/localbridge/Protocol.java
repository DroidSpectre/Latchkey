package dev.aetherix.localbridge;

import org.json.JSONException;
import org.json.JSONObject;

public final class Protocol {
    public static final int VERSION = 1;

    private Protocol() {
    }

    public static JSONObject parseObject(String line) throws JSONException {
        return new JSONObject(line);
    }

    public static String hello(String nonce, String serverProof) {
        return new JSONObject()
                .put("type", "hello")
                .put("v", VERSION)
                .put("nonce", nonce)
                .put("server_proof", serverProof)
                .toString();
    }

    public static String ready(String session) {
        return new JSONObject()
                .put("type", "ready")
                .put("session", session)
                .toString();
    }

    public static String ok(long id, JSONObject result) {
        return new JSONObject()
                .put("id", id)
                .put("ok", true)
                .put("result", result)
                .toString();
    }

    public static String error(long id, String code, String message) {
        JSONObject error = new JSONObject()
                .put("code", code)
                .put("message", message);
        return new JSONObject()
                .put("id", id)
                .put("ok", false)
                .put("error", error)
                .toString();
    }

    public static String handshakeError(String code) {
        return new JSONObject()
                .put("type", "error")
                .put("code", code)
                .toString();
    }
}

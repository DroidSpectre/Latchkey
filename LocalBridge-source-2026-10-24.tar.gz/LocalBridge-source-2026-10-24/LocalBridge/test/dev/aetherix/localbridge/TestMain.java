package dev.aetherix.localbridge;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public final class TestMain {
    public static void main(String[] args) throws Exception {
        testHmac();
        testProtocol();
        testPathGuard();
        testFileOps();
        testServer();
        System.out.println("ALL TESTS PASSED");
    }

    private static void testHmac() throws Exception {
        byte[] key = "Jefe".getBytes(StandardCharsets.UTF_8);
        String mac = Hmac.hex(Hmac.sha256(key, "what do ya want for nothing?"));
        eq("5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843", mac, "RFC 4231 case 2");

        byte[] token = Hmac.fromHex("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f");
        eq(64, Hmac.serverProof(token, "abc").length(), "server proof length");
        eq(64, Hmac.clientProof(token, "abc", "opencode").length(), "client proof length");
        check(!Hmac.serverProof(token, "abc").equals(Hmac.clientProof(token, "abc", "opencode")), "proof domains differ");
        check(Hmac.constantTimeEquals(Hmac.serverProof(token, "abc"), Hmac.serverProof(token, "abc")), "constant-time equal");
        check(!Hmac.constantTimeEquals(Hmac.serverProof(token, "abc"), Hmac.serverProof(token, "abd")), "constant-time unequal");
    }

    private static void testProtocol() throws Exception {
        JSONObject result = new JSONObject().put("time", 123L);
        JSONObject ok = Protocol.parseObject(Protocol.ok(7L, result));
        eq(7L, ok.getLong("id"), "ok id");
        eq(true, ok.getBoolean("ok"), "ok flag");
        eq(123L, ok.getJSONObject("result").getLong("time"), "ok result");

        JSONObject error = Protocol.parseObject(Protocol.error(8L, "bad_path", "nope"));
        eq(8L, error.getLong("id"), "error id");
        eq(false, error.getBoolean("ok"), "error flag");
        eq("bad_path", error.getJSONObject("error").getString("code"), "error code");

        JSONObject hello = Protocol.parseObject(Protocol.hello("00", "11"));
        eq(1, hello.getInt("v"), "hello version");
        eq("00", hello.getString("nonce"), "hello nonce");
        eq("11", hello.getString("server_proof"), "hello proof");
    }

    private static void testPathGuard() throws Exception {
        File root = Files.createTempDirectory("lb-path").toFile();
        new File(root, "Download").mkdirs();
        File outside = Files.createTempDirectory("lb-outside").toFile();
        Files.write(new File(root, "Download/ok.txt").toPath(), "ok".getBytes(StandardCharsets.UTF_8));

        PathGuard guard = new PathGuard(root);
        eq(new File(root, "Download/ok.txt").getCanonicalPath(), guard.resolve("Download/ok.txt").getPath(), "valid relative");
        eq("Download/ok.txt", guard.relative(guard.resolve("Download/ok.txt")), "relative output");

        expectBad(() -> guard.resolve("../etc/passwd"), "parent traversal");
        expectBad(() -> guard.resolve(outside.getAbsolutePath() + "/x"), "absolute outside");
        expectBad(() -> guard.resolve(root.getAbsolutePath() + "2/x"), "prefix collision");

        File link = new File(root, "escape");
        Files.createSymbolicLink(link.toPath(), outside.toPath());
        expectBad(() -> guard.resolve("escape/x"), "symlink escape");
    }

    private static void testFileOps() throws Exception {
        File root = Files.createTempDirectory("lb-files").toFile();
        new File(root, "Download").mkdirs();
        FileOps files = new FileOps(root);

        JSONObject write = files.write("Download/a.txt", 0, "hello".getBytes(StandardCharsets.UTF_8), true);
        eq(5L, write.getLong("written"), "write length");
        eq(5L, write.getLong("size"), "write size");

        JSONObject stat = files.stat("Download/a.txt");
        eq("file", stat.getString("type"), "stat type");
        eq(5L, stat.getLong("size"), "stat size");

        JSONObject read = files.read("Download/a.txt", 0, 1024);
        eq("hello", new String(java.util.Base64.getDecoder().decode(read.getString("data")), StandardCharsets.UTF_8), "read data");
        eq(true, read.getBoolean("eof"), "read eof");

        JSONObject hash = files.hash("Download/a.txt");
        eq("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824", hash.getString("value"), "sha256");

        files.mkdir("Download/sub", false);
        eq("dir", files.stat("Download/sub").getString("type"), "mkdir");

        JSONObject rename = files.rename("Download/a.txt", "Download/b.txt");
        eq(true, rename.getBoolean("renamed"), "rename");
        eq("file", files.stat("Download/b.txt").getString("type"), "rename target");

        JSONObject list = files.list("Download", 10);
        eq(2, list.getJSONArray("entries").length(), "list length");
        eq(false, list.getBoolean("truncated"), "list truncation");

        try {
            files.delete("Download/sub/x");
            throw new AssertionError("missing delete should fail");
        } catch (FileOps.Error e) {
            eq("not_found", e.code, "missing delete code");
        }

        files.delete("Download/b.txt");
        files.delete("Download/sub");
        expectBad(() -> {
            try { files.stat("../../etc/passwd"); }
            catch (FileOps.Error e) { throw new SecurityException(e.code); }
        }, "file traversal");

        try {
            files.delete(".");
            throw new AssertionError("root delete should fail");
        } catch (FileOps.Error e) {
            eq("bad_request", e.code, "root delete code");
        }
    }

    private static void testServer() throws Exception {
        File root = Files.createTempDirectory("lb-server").toFile();
        Files.write(new File(root, "hello.txt").toPath(), "hello".getBytes(StandardCharsets.UTF_8));
        byte[] token = Hmac.fromHex("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f");

        BridgeServer server = new BridgeServer(0, token, root, null);
        Thread thread = new Thread(server, "test-server");
        thread.start();
        try {
            try (Socket socket = new Socket("127.0.0.1", server.getPort())) {
                socket.setSoTimeout(5000);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                Writer out = new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8);

                JSONObject hello = new JSONObject(in.readLine());
                eq("hello", hello.getString("type"), "hello type");
                String nonce = hello.getString("nonce");
                eq(Hmac.serverProof(token, nonce), hello.getString("server_proof"), "server proof");

                out.write(new JSONObject()
                        .put("type", "auth")
                        .put("client", "test")
                        .put("proof", Hmac.clientProof(token, nonce, "test"))
                        .toString() + "\n");
                out.flush();

                JSONObject ready = new JSONObject(in.readLine());
                eq("ready", ready.getString("type"), "ready type");

                out.write("{\"id\":1,\"op\":\"ping\"}\n");
                out.flush();
                JSONObject ping = new JSONObject(in.readLine());
                eq(true, ping.getBoolean("ok"), "ping ok");
                check(ping.getJSONObject("result").getLong("time") > 0, "ping time");

                out.write("{\"id\":2,\"op\":\"stat\",\"path\":\"hello.txt\"}\n");
                out.flush();
                JSONObject stat = new JSONObject(in.readLine());
                eq(5L, stat.getJSONObject("result").getLong("size"), "stat size");

                out.write("{\"id\":3,\"op\":\"stat\",\"path\":\"../x\"}\n");
                out.flush();
                JSONObject bad = new JSONObject(in.readLine());
                eq(false, bad.getBoolean("ok"), "bad path failed");
                eq("bad_path", bad.getJSONObject("error").getString("code"), "bad path code");
            }

            try (Socket socket = new Socket("127.0.0.1", server.getPort())) {
                socket.setSoTimeout(5000);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                Writer out = new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8);
                new JSONObject(in.readLine());
                out.write(new JSONObject()
                        .put("type", "auth")
                        .put("client", "test")
                        .put("proof", "00".repeat(32))
                        .toString() + "\n");
                out.flush();
                JSONObject error = new JSONObject(in.readLine());
                eq("error", error.getString("type"), "auth error type");
                eq("auth_failed", error.getString("code"), "auth error code");
            }
        } finally {
            server.close();
            thread.join(3000);
        }
    }

    private static void expectBad(ThrowingRunnable action, String message) {
        try {
            action.run();
            throw new AssertionError(message + ": expected SecurityException");
        } catch (SecurityException expected) {
        } catch (Exception e) {
            throw new AssertionError(message + ": wrong exception " + e, e);
        }
    }

    private interface ThrowingRunnable {
        void run() throws Exception;
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static void eq(Object expected, Object actual, String message) {
        if (!expected.equals(actual)) throw new AssertionError(message + ": " + expected + " != " + actual);
    }
}

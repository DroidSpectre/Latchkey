import base64
import hashlib
import hmac
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import unittest

TOKEN = bytes.fromhex("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
CLIENT = "/root/tools/localbridge_client.py"


def mac(key, text):
    return hmac.new(key, text.encode(), hashlib.sha256).hexdigest()


class MockServer(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.sock = socket.socket()
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(1)
        self.port = self.sock.getsockname()[1]
        self.error = None

    def run(self):
        try:
            conn, _ = self.sock.accept()
            with conn:
                f = conn.makefile("rwb")
                nonce = "aa" * 32
                f.write((json.dumps({
                    "type": "hello", "v": 1, "nonce": nonce,
                    "server_proof": mac(TOKEN, "server|" + nonce),
                }) + "\n").encode())
                f.flush()
                line = f.readline()
                if not line:
                    return
                auth = json.loads(line)
                expected = mac(TOKEN, "client|" + nonce + "|" + auth["client"])
                assert auth["proof"] == expected, auth
                f.write((json.dumps({"type": "ready", "session": "bb" * 16}) + "\n").encode())
                f.flush()
                req = json.loads(f.readline())
                assert req["op"] == "ping", req
                f.write((json.dumps({
                    "id": req["id"], "ok": True,
                    "result": {"time": 123},
                }) + "\n").encode())
                f.flush()
        except Exception as e:
            self.error = e
        finally:
            self.sock.close()


class ClientTest(unittest.TestCase):
    def test_ping(self):
        server = MockServer()
        server.start()
        proc = subprocess.run(
            [sys.executable, CLIENT, "--port", str(server.port), "--token", TOKEN.hex(), "ping"],
            capture_output=True, text=True, timeout=10)
        server.join(5)
        self.assertIsNone(server.error)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn('"time": 123', proc.stdout)

    def test_wrong_token_is_rejected_by_client(self):
        server = MockServer()
        server.start()
        proc = subprocess.run(
            [sys.executable, CLIENT, "--port", str(server.port), "--token", "00" * 32, "ping"],
            capture_output=True, text=True, timeout=10)
        server.join(5)
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("server authentication failed", proc.stderr)


if __name__ == "__main__":
    unittest.main()

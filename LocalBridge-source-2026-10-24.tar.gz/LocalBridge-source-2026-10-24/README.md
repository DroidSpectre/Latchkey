# LocalBridge source bundle

Exported 2026-10-24 from `/root/LocalBridge`.

## Contents

- `LocalBridge/` - Android app source, tests, resources, build script, and
  the test-only JSON jar.
- `agent/localbridge_client.py` - Python client used by the agent.
- `agent/connect.sh` - convenience wrapper for the client.
- `dist/LocalBridge.apk` - signed APK (same build that was validated).
- `docs/` - approved design and implementation plan.

## Connect

The app must be installed, running, and have All files access. Open LocalBridge
and tap Start if it is stopped.

```sh
python3 agent/localbridge_client.py ping
python3 agent/localbridge_client.py ls .
python3 agent/localbridge_client.py get Download/example.txt /tmp/example.txt
```

The client reads the pairing token from
`/root/.config/localbridge/token` by default. Override with `--token` or
`LOCALBRIDGE_TOKEN`. The live token is **not** included in this archive; read it
from the app or the token file above.

The server listens only on `127.0.0.1:39401` and accepts one active client.
Paths are relative to `/storage/emulated/0` unless absolute paths inside that
root are supplied.

## Build

`build.sh` uses absolute paths, so extract or copy the app to
`/root/LocalBridge` before building:

```sh
cd /root/LocalBridge
./build.sh
```

Required toolchain: Android SDK build-tools (`aapt2`, `d8`, `zipalign`,
`apksigner`), a JDK, and ECJ at `/opt/bionic-build/lib/ecj-3.40.0.jar`.
The build intentionally compiles with `-source 8 -target 8` so Android's
checked `org.json.JSONException` signature is used.

## Validation

Java `TestMain` reports `ALL TESTS PASSED`; Python mock tests pass 2/2.
On-device checks passed for ping/token auth, 10 MB upload/download with matching
SHA-256, directory operations, path traversal rejection, single-client behavior,
and five-failure lockout with recovery. Stop/Start and token persistence also
passed. Final Stop was confirmed and port 39401 was closed.

`Android/data` and `Android/obb` can be statted but cannot be listed
(`io_error: cannot list directory`) on this Android build.

## Security

The signing keystore, keystore password, and live pairing token are deliberately
excluded. The included APK is signed; see `BUILD-INFO.txt` for its digest.
Do not share the live token; it grants full read/write access to shared storage
through the local bridge while the server is running.

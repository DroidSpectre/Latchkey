#!/usr/bin/env python3
import argparse
import base64
import hashlib
import hmac
import json
import os
import socket
import sys
from pathlib import Path

DEFAULT_PORT = 39401
CHUNK = 512 * 1024
TOKEN_FILE = Path("/root/.config/localbridge/token")


def mac(key, text):
    return hmac.new(key, text.encode(), hashlib.sha256).hexdigest()


def load_token(value):
    if value:
        return bytes.fromhex(value)
    env = os.environ.get("LOCALBRIDGE_TOKEN")
    if env:
        return bytes.fromhex(env)
    if TOKEN_FILE.exists():
        return bytes.fromhex(TOKEN_FILE.read_text().strip())
    raise SystemExit("no token; use --token or create /root/.config/localbridge/token")


class Bridge:
    def __init__(self, host, port, token, client="opencode"):
        self.sock = socket.create_connection((host, port), timeout=10)
        self.sock.settimeout(30)
        self.f = self.sock.makefile("rwb")
        self.token = token
        self.client = client
        self.next_id = 1

    def close(self):
        try:
            self.f.close()
        finally:
            self.sock.close()

    def handshake(self):
        hello = json.loads(self.f.readline())
        if hello.get("type") != "hello" or hello.get("v") != 1:
            raise SystemExit("unexpected server greeting")
        nonce = hello["nonce"]
        expected = mac(self.token, "server|" + nonce)
        if not hmac.compare_digest(expected, hello.get("server_proof", "")):
            raise SystemExit("server authentication failed")
        proof = mac(self.token, "client|" + nonce + "|" + self.client)
        self._write({"type": "auth", "client": self.client, "proof": proof})
        ready = json.loads(self.f.readline())
        if ready.get("type") != "ready":
            raise SystemExit("authentication rejected: %s" % ready)
        return ready

    def _write(self, obj):
        self.f.write((json.dumps(obj, separators=(",", ":")) + "\n").encode())
        self.f.flush()

    def request(self, op, **kwargs):
        rid = self.next_id
        self.next_id += 1
        obj = {"id": rid, "op": op}
        obj.update(kwargs)
        self._write(obj)
        line = self.f.readline()
        if not line:
            raise SystemExit("connection closed")
        response = json.loads(line)
        if response.get("id") != rid:
            raise SystemExit("response id mismatch")
        if not response.get("ok"):
            error = response.get("error", {})
            raise SystemExit("%s: %s" % (error.get("code", "error"), error.get("message", "")))
        return response.get("result", {})


def path_arg(value):
    return value


def cmd_ping(bridge, args):
    print(json.dumps(bridge.request("ping"), indent=2))


def cmd_ls(bridge, args):
    result = bridge.request("list", path=args.path, limit=args.limit)
    for entry in result.get("entries", []):
        print("%s\t%s\t%s" % (entry["type"], entry.get("size", 0), entry["name"]))
    if result.get("truncated"):
        print("(truncated)", file=sys.stderr)


def cmd_stat(bridge, args):
    print(json.dumps(bridge.request("stat", path=args.path), indent=2))


def cmd_get(bridge, args):
    stat = bridge.request("stat", path=args.remote)
    size = stat.get("size", 0)
    target = Path(args.local)
    target.parent.mkdir(parents=True, exist_ok=True)
    offset = 0
    with target.open("wb") as out:
        while offset < size or size == 0:
            result = bridge.request("read", path=args.remote, offset=offset, length=CHUNK)
            data = base64.b64decode(result["data"])
            out.write(data)
            offset += len(data)
            if result.get("eof") or not data:
                break
    print("%s bytes -> %s" % (target.stat().st_size, target))


def cmd_put(bridge, args):
    source = Path(args.local)
    size = source.stat().st_size
    if size == 0:
        bridge.request("write", path=args.remote, offset=0, data="", truncate=True)
        print("0 bytes -> %s" % args.remote)
        return
    offset = 0
    with source.open("rb") as inp:
        while True:
            data = inp.read(CHUNK)
            if not data:
                break
            bridge.request("write", path=args.remote, offset=offset,
                           data=base64.b64encode(data).decode(), truncate=offset == 0)
            offset += len(data)
    print("%s bytes -> %s" % (offset, args.remote))


def cmd_mkdir(bridge, args):
    print(json.dumps(bridge.request("mkdir", path=args.path, parents=args.parents), indent=2))


def cmd_mv(bridge, args):
    print(json.dumps(bridge.request("rename", path=args.source, to=args.target), indent=2))


def cmd_rm(bridge, args):
    print(json.dumps(bridge.request("delete", path=args.path), indent=2))


def cmd_hash(bridge, args):
    print(json.dumps(bridge.request("hash", path=args.path), indent=2))


def main():
    parser = argparse.ArgumentParser(description="LocalBridge client")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--token")
    parser.add_argument("--client", default="opencode")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("ping")
    p.set_defaults(func=cmd_ping)

    p = sub.add_parser("ls")
    p.add_argument("path", default=".", nargs="?")
    p.add_argument("--limit", type=int, default=1000)
    p.set_defaults(func=cmd_ls)

    p = sub.add_parser("stat")
    p.add_argument("path")
    p.set_defaults(func=cmd_stat)

    p = sub.add_parser("get")
    p.add_argument("remote")
    p.add_argument("local")
    p.set_defaults(func=cmd_get)

    p = sub.add_parser("put")
    p.add_argument("local")
    p.add_argument("remote")
    p.set_defaults(func=cmd_put)

    p = sub.add_parser("mkdir")
    p.add_argument("path")
    p.add_argument("--parents", action="store_true")
    p.set_defaults(func=cmd_mkdir)

    p = sub.add_parser("mv")
    p.add_argument("source")
    p.add_argument("target")
    p.set_defaults(func=cmd_mv)

    p = sub.add_parser("rm")
    p.add_argument("path")
    p.set_defaults(func=cmd_rm)

    p = sub.add_parser("hash")
    p.add_argument("path")
    p.set_defaults(func=cmd_hash)

    args = parser.parse_args()
    token = load_token(args.token)
    bridge = Bridge(args.host, args.port, token, args.client)
    try:
        bridge.handshake()
        args.func(bridge, args)
    finally:
        bridge.close()


if __name__ == "__main__":
    main()

# LocalBridge Design

Date: 2026-10-24

## Status

Implemented and validated. JVM tests, Python mock tests, and signed APK build pass. On-device ping, 10 MB round-trip/hash, path rejection, directory operations, single-client behavior, lockout/recovery, Stop/Start, and token persistence passed on `127.0.0.1:39401`. Final Stop confirmed; port 39401 is closed. `Android/data` can be statted but listing returns `io_error`.

## Problem

The agent runs inside a proot environment under the Android app `gptos.intelligence.assistant`. The host app targets SDK 36 and does not declare `MANAGE_EXTERNAL_STORAGE`. The agent can read most of `/sdcard` through a proot bind, but it cannot reliably use Android shell tools, and it cannot access protected shared-storage paths such as `/sdcard/Android/data` and `/sdcard/Android/obb`.

A native companion app can obtain broader shared-storage access through `MANAGE_EXTERNAL_STORAGE`, expose a small authenticated file API on loopback, and let the agent perform file operations without proot path and tooling limitations.

## Goals

- Provide authenticated read/write/list/stat/rename/delete/hash operations on shared storage.
- Require no Shizuku, no root, and no remote server.
- Make no outbound network connections; `INTERNET` is used only for loopback sockets.
- Bind only to `127.0.0.1:39401`.
- Require a one-time user grant of All files access.
- Use a 256-bit pairing token and mutual HMAC-SHA256 challenge-response.
- Keep the APK small, dependency-free, and easy to audit.
- Provide a Python client usable from the proot environment.

## Non-Goals

- Access other apps' private data under `/data`.
- Access `/system`, `/vendor`, `/apex`, or other system partitions.
- Provide shell command execution.
- Bypass Android scoped-storage restrictions that remain after `MANAGE_EXTERNAL_STORAGE`.
- Work on a rooted or compromised device with a stronger threat model than app sandboxing.
- Auto-start after reboot.
- Encrypt loopback payloads in version 1.

## Architecture

### Components

- `MainActivity`: permission status, token display, copy/regenerate controls, start/stop control, server status, connected client name, failed-auth count.
- `BridgeService`: foreground service that owns the server socket and notification.
- `BridgeServer`: single-threaded accept loop, one active client, per-connection handshake and request loop.
- `FileOps`: sandboxed shared-storage operations.
- `PairingStore`: token generation and private storage.
- `Protocol`: newline-delimited JSON framing, request parsing, response serialization.
- `PathGuard`: canonical path validation against the shared-storage root.

### Package and platform

- Package: `dev.aetherix.localbridge`
- Language: Java, platform APIs only, no AndroidX or third-party libraries.
- `compileSdk = 36`, `minSdk = 30`, `targetSdk = 36`.
- Programmatic UI; no XML layouts.
- Minimal launcher icon.

### Manifest

Permissions:

- `android.permission.INTERNET`
- `android.permission.FOREGROUND_SERVICE`
- `android.permission.FOREGROUND_SERVICE_SPECIAL_USE`
- `android.permission.POST_NOTIFICATIONS`
- `android.permission.MANAGE_EXTERNAL_STORAGE`

Service declaration:

- `android:exported="false"`
- `android:foregroundServiceType="specialUse"`
- `android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE` value describing an authenticated local file bridge.

Application:

- `android:allowBackup="false"`
- `android:fullBackupContent="false"`
- No exported receivers or providers.
- No boot receiver.

### Service lifecycle

- The service starts only when the user taps Start.
- The service refuses to bind unless `Environment.isExternalStorageManager()` is true.
- `startForeground` is called within five seconds with a persistent notification.
- The notification contains Stop and no token.
- Stop closes the listening socket and active connection, then stops the foreground service.
- The service does not restart automatically after being stopped by the user.
- `START_NOT_STICKY` is used to avoid unexpected restarts.

### File sandbox

- Root: `Environment.getExternalStorageDirectory().getCanonicalFile()`, normally `/storage/emulated/0`.
- Relative paths are resolved against the root.
- Absolute paths must resolve under the root.
- `PathGuard` canonicalizes the path and its parent, rejects NUL bytes, and requires the result to equal the root or start with `root + File.separator`.
- Operations on non-existent targets validate the nearest existing parent.
- No operation follows a path outside the root.
- Symlinks cannot normally be created on `/sdcard`, but canonical validation still applies.

## Protocol

### Transport

- TCP on `127.0.0.1:39401`.
- Backlog 1.
- One active client at a time. Additional connections are accepted only after the active client disconnects; otherwise they are closed.
- UTF-8 newline-delimited JSON.
- Maximum control frame size: 1 MiB.
- Maximum base64 data payload: 512 KiB per read or write request.
- Connection idle timeout: 30 seconds during handshake; 120 seconds between requests.
- Socket read timeout enforced with `Socket.setSoTimeout`.

### Handshake

1. Client connects.
2. Server generates a 32-byte nonce and sends:

```json
{"type":"hello","v":1,"nonce":"<64 lowercase hex>","server_proof":"<64 lowercase hex>"}
```

3. `server_proof = HMAC-SHA256(token, "server|" + nonce)`.
4. Client verifies `server_proof` using its stored token in constant time.
5. Client sends:

```json
{"type":"auth","client":"opencode","proof":"<64 lowercase hex>"}
```

6. `proof = HMAC-SHA256(token, "client|" + nonce + "|" + client)`.
7. Server verifies the proof in constant time.
8. On success, server sends:

```json
{"type":"ready","session":"<32 lowercase hex>"}
```

9. On failure, server waits 500 ms, sends `{"type":"error","code":"auth_failed"}`, closes the connection, and increments the global failure counter.

Handshake rules:

- The token is never transmitted.
- The client name is limited to 64 printable ASCII characters; control characters are rejected.
- The nonce is single-use and expires after 30 seconds.
- Five consecutive failed client proofs trigger a 60-second lockout. The lockout applies to new connections.
- A successful authentication resets the failure counter.
- A new token invalidates all sessions immediately.

### Requests

Each request is one JSON object per line:

```json
{"id":1,"op":"stat","path":"Download"}
```

- `id` is a positive integer chosen by the client.
- One request may be in flight at a time.
- Responses are written in request order and include the same `id`.
- Unknown fields are ignored.
- Unknown operations return `unsupported`.

### Responses

Success:

```json
{"id":1,"ok":true,"result":{}}
```

Error:

```json
{"id":1,"ok":false,"error":{"code":"bad_path","message":"path escapes shared storage"}}
```

Error codes:

- `bad_request`
- `bad_path`
- `not_found`
- `exists`
- `not_empty`
- `denied`
- `too_large`
- `io_error`
- `unsupported`
- `auth_failed`
- `locked`

### Operations

#### ping

Request:

```json
{"id":1,"op":"ping"}
```

Result:

```json
{"time":1729770000000}
```

#### stat

Request:

```json
{"id":2,"op":"stat","path":"Download/example.txt"}
```

Result:

```json
{"path":"Download/example.txt","type":"file","size":1234,"mtime":1729770000000}
```

`type` is `file`, `dir`, or `other`.

#### list

Request:

```json
{"id":3,"op":"list","path":"Download","limit":1000}
```

Result:

```json
{"entries":[{"name":"example.txt","type":"file","size":1234,"mtime":1729770000000}],"truncated":false}
```

- `limit` defaults to 1000 and is capped at 5000.
- Entries are sorted by name.
- `list` is non-recursive.
- Encoding stops before the serialized response would exceed 900 KiB.
- If the directory contains more entries than fit within `limit` or the byte cap, `truncated` is true.

#### read

Request:

```json
{"id":4,"op":"read","path":"Download/example.bin","offset":0,"length":524288}
```

Result:

```json
{"data":"<base64>","offset":0,"length":1234,"size":1234,"eof":true}
```

- `offset` defaults to 0.
- `length` defaults to and is capped at 524288.
- Reading past EOF returns empty `data` and `eof:true`.
- The file is opened read-only and closed after the request.

#### write

Request:

```json
{"id":5,"op":"write","path":"Download/example.bin","offset":0,"data":"<base64>","truncate":true}
```

Result:

```json
{"written":1234,"size":1234}
```

- The parent directory must already exist.
- `truncate` defaults to false.
- The file is opened with `RandomAccessFile` in `rw` mode and closed after the request.
- The service does not create parent directories implicitly.
- The decoded payload must not exceed 524288 bytes.

#### mkdir

Request:

```json
{"id":6,"op":"mkdir","path":"Download/newdir","parents":false}
```

Result:

```json
{"created":true}
```

- `parents` defaults to false.
- Existing paths return `exists`.

#### rename

Request:

```json
{"id":7,"op":"rename","path":"Download/a.txt","to":"Download/b.txt"}
```

Result:

```json
{"renamed":true}
```

Both paths must pass `PathGuard`. The destination must not exist.

#### delete

Request:

```json
{"id":8,"op":"delete","path":"Download/a.txt"}
```

Result:

```json
{"deleted":true}
```

- Deletes a file or an empty directory only.
- Non-empty directories return `not_empty`.
- No recursive delete in version 1.

#### hash

Request:

```json
{"id":9,"op":"hash","path":"Download/example.bin"}
```

Result:

```json
{"algorithm":"sha256","value":"<64 lowercase hex>","size":1234}
```

The file is streamed through SHA-256; it is not loaded into memory.

## Security Model

### Layers

1. Network scope: the socket binds to `127.0.0.1` only, with one active client.
2. Authentication: 256-bit token plus mutual HMAC-SHA256 challenge-response. The token is never sent; the client authenticates the server before revealing its proof.
3. Authorization and abuse control: canonical path sandbox, fixed operation set, frame and payload limits, failed-auth delay and lockout.

### Token handling

- Generated with `SecureRandom` as 32 bytes.
- Displayed as 64 lowercase hex characters.
- Stored in app-private `SharedPreferences` with `MODE_PRIVATE`.
- Application backup disabled.
- Never written to logs, notifications, crash messages, or shared storage.
- Regenerate replaces the token, closes the active session, and stops the server so the new token is used on the next start.
- The user may paste the token into the agent chat once; the agent stores it locally with mode 0600.

### Threat assumptions

- Other apps can connect to loopback, so the token and HMAC handshake are mandatory.
- A local app can cause denial of service by occupying the port or flooding connections; this design does not attempt to prevent local DoS.
- A rooted device can read app-private storage and process memory; this design does not defend against root.
- Loopback payloads are authenticated but not encrypted. The data already resides on shared storage, and encryption is deferred.
- `MANAGE_EXTERNAL_STORAGE` is powerful. The fixed file API and path sandbox limit accidental misuse, not a malicious app with the token.

## Error Handling

- Malformed JSON: `bad_request`, then continue if the frame is under the limit; close after repeated malformed frames.
- Oversized frame: send `too_large` if possible, then close.
- Path escape: `bad_path`, no filesystem access.
- Missing file: `not_found`.
- Permission failure: `denied`.
- I/O failure: `io_error` with a short message; do not include absolute host paths or stack traces.
- Unexpected exception: log a short message without token or file contents; return `io_error`.
- Client disconnect: close streams and release the active-client slot.
- Server socket bind failure: stop the service and show an error notification.

## UI and User Flow

1. Install `LocalBridge.apk`.
2. Open the app.
3. Tap Grant All files access. The app opens the system All files access page.
4. Return to the app; status shows Granted.
5. Copy the 64-character token and paste it into chat.
6. Tap Start. The notification shows the bridge is active on `127.0.0.1:39401`.
7. Agent runs the client, verifies the server proof, and performs operations.
8. Tap Stop in the app or notification to close the port.

The app displays:

- Permission state.
- Token with Copy and Regenerate.
- Start/Stop state.
- Listening address.
- Connected client name, if any.
- Recent failed-auth count.
- A short note that Android/data may remain restricted.

## Build and Distribution

- Use `/opt/android-sdk` platform 36 and build-tools 36.0.0.
- The system `javac` is broken by a GLIBC mismatch. Compile with ECJ 3.40 from `/opt/bionic-build/lib/ecj-3.40.0.jar` and the working JRE at `/opt/jdk-17.0.20.1+1-jre`; restore a full JDK only if ECJ fails.
- Build with `aapt2`, ECJ, `d8`, `zipalign`, and `apksigner`. A small build script will encode the exact commands.
- Use `json-20240303.jar` only for JVM tests; the APK uses Android's platform `org.json`, so no JSON library is packaged.
- Generate a dedicated keystore under `/root/.local/share/localbridge/`; store its password in a 0600 file.
- Output `LocalBridge.apk` and copy it to `/sdcard/Download/LocalBridge.apk`.
- Install through the Android package installer; the user confirms installation.
- Provide `/root/tools/localbridge_client.py` with `ping`, `ls`, `stat`, `get`, `put`, `mkdir`, `mv`, `rm`, and `hash` subcommands.
- Client token path: `/root/.config/localbridge/token`, mode 0600, overridable with `--token` or `LOCALBRIDGE_TOKEN`.

## Testing

### Static

- `aapt2 dump badging` confirms package, SDK levels, and permissions.
- `apksigner verify` confirms the APK signature.
- Manifest inspection confirms no exported service, receiver, or provider.

### On-device

- App installs and launches.
- All files access page opens and status updates after grant.
- Server starts and listens on `127.0.0.1:39401`.
- Correct token authenticates.
- A client with a wrong token rejects the server proof and does not send a client proof.
- Five invalid client proofs trigger the lockout.
- `ping`, `stat`, `list`, `read`, `write`, `mkdir`, `rename`, `delete`, and `hash` work on a temporary directory under Download.
- A 10 MB file round-trip produces matching SHA-256 values.
- Paths containing `..`, absolute paths outside the root, and symlink escapes return `bad_path`.
- A second client is refused or delayed while one client is active.
- Stop closes the port; restart works and the token persists.
- An `Android/data` listing attempt is performed and its exact result recorded.
- Service remains alive with the screen off for at least two minutes on the test device.

### Cleanup

- Remove test files and temporary directories.
- Do not leave the server running after validation.
- Do not print the token in test output.

## Acceptance Criteria

- The agent can list and transfer files under shared storage using the authenticated client.
- The server is reachable only through loopback.
- No token appears in logs, notifications, shared storage, or the APK.
- The app works without Shizuku, root, internet connectivity, or outbound network calls.
- Any remaining Android/data restriction is documented with the observed error.

## Risks

- Android may still deny other apps' `Android/data` and `obb` even with All files access. If so, only Shizuku or root can cross that boundary; the design will report the limit instead of bypassing it.
- OEM battery management may stop the foreground service. The user may need to exempt the app.
- The system `javac` is broken; ECJ is the primary compiler, with a full JDK restore as fallback.
- A local app can deny service by holding the port; authentication still prevents file access.
- Pasting the token into chat exposes it to the chat history. The user can regenerate it at any time.

## Resolved Decisions

- Access scope: shared storage only.
- Authentication: 256-bit token plus mutual HMAC-SHA256 challenge-response.
- Pairing: on-screen token, one-time paste.
- Transport: raw TCP with newline-delimited JSON.
- No Shizuku, root, shell execution, or remote network access.

# LocalBridge Implementation Plan

> **Implementation status:** Complete. The signed APK is at `/sdcard/Download/LocalBridge.apk`; token stored at `/root/.config/localbridge/token` (0600). On-device ping, 10 MB upload/download/hash, path rejection, directory operations, single-client behavior, lockout/recovery, Stop/Start, and token persistence passed. Final Stop confirmed; port 39401 is closed.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a sideloadable Android companion app that exposes an authenticated, loopback-only file API for shared storage, plus a Python client the proot environment can use.

**Architecture:** A Java-only Android app with a foreground service, raw TCP NDJSON protocol, mutual HMAC-SHA256 handshake, and sandboxed file operations. Pure-Java protocol, path, file, and server classes run under JVM tests; Android UI, service, and pairing classes are compiled into the APK.

**Tech Stack:** Android SDK 36, build-tools 36.0.0, ECJ 3.40, JRE 17, org.json (test-only `json-20240303.jar`), Python 3.

## Global Constraints

- Package: `dev.aetherix.localbridge`
- `compileSdk = 36`, `minSdk = 30`, `targetSdk = 36`
- Listen only on `127.0.0.1:39401`
- Shared storage only, rooted at `/storage/emulated/0`
- No Shizuku, no root, no shell execution, no outbound network calls
- 256-bit token, 64 lowercase hex characters
- Mutual HMAC-SHA256 challenge-response
- One active client at a time
- Maximum control frame: 1 MiB; maximum data chunk: 512 KiB
- No third-party libraries in the APK; Android platform `org.json` only
- Test-only dependency: `json-20240303.jar` with SHA-256 `3cf6cd6892e32e2b4c1c39e0f52f5248a2f5b37646fdfbb79a66b46b618414ed`
- `/root` is not a git repository. Do not initialize git or create commits unless the user explicitly asks.
- Coreutils `mkdir`, `find`, `ls`, `sed`, and `tar` are unreliable in this proot. Use Python for directory creation and source enumeration.
- Working JRE: `/opt/jdk-17.0.20.1+1-jre/bin/java`
- ECJ compiler: `/opt/bionic-build/lib/ecj-3.40.0.jar`
- Android SDK: `/opt/android-sdk`
- Build-tools: `/opt/android-sdk/build-tools/36.0.0`
- Android platform jar: `/opt/android-sdk/platforms/android-36/android.jar`

---

### Task 1: Scaffold Project and Verify AAPT2

**Files:**
- Create: `/root/LocalBridge/AndroidManifest.xml`
- Create: `/root/LocalBridge/res/values/strings.xml`
- Create: `/root/LocalBridge/res/drawable/ic_launcher.xml`
- Create directories: `/root/LocalBridge/src/dev/aetherix/localbridge`, `/root/LocalBridge/test/dev/aetherix/localbridge`, `/root/LocalBridge/test-lib`, `/root/LocalBridge/build`

**Interfaces:**
- Consumes: none
- Produces: package name, manifest permissions, app label, launcher icon, SDK levels

- [ ] **Step 1: Create the project directories**

```bash
python3 - <<'PY'
import os
for d in [
    '/root/LocalBridge',
    '/root/LocalBridge/src/dev/aetherix/localbridge',
    '/root/LocalBridge/test/dev/aetherix/localbridge',
    '/root/LocalBridge/test-lib',
    '/root/LocalBridge/build',
    '/root/LocalBridge/res/values',
    '/root/LocalBridge/res/drawable',
]:
    os.makedirs(d, exist_ok=True)
print('created')
PY
```

Expected: `created`

- [ ] **Step 2: Write the manifest**

Create `/root/LocalBridge/AndroidManifest.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="dev.aetherix.localbridge"
    android:versionCode="1"
    android:versionName="1.0">

    <uses-sdk android:minSdkVersion="30" android:targetSdkVersion="36" />

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />

    <application
        android:allowBackup="false"
        android:fullBackupContent="false"
        android:icon="@drawable/ic_launcher"
        android:label="@string/app_name"
        android:usesCleartextTraffic="false"
        android:theme="@android:style/Theme.Material.Light.NoActionBar">

        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".BridgeService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Authenticated local file bridge" />
        </service>
    </application>
</manifest>
```

- [ ] **Step 3: Write the app label**

Create `/root/LocalBridge/res/values/strings.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">LocalBridge</string>
</resources>
```

- [ ] **Step 4: Write the launcher icon**

Create `/root/LocalBridge/res/drawable/ic_launcher.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp"
    android:height="48dp"
    android:viewportWidth="48"
    android:viewportHeight="48">
    <path
        android:fillColor="#1565C0"
        android:pathData="M4,4h40v40h-40z" />
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M14,22h20v16h-20z" />
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M18,22v-4a6,6 0,0 1,12 0v4h-4v-4a2,2 0,0 0,-4 0v4z" />
</vector>
```

- [ ] **Step 5: Link the resources and inspect the manifest**

```bash
AAPT2=/opt/android-sdk/build-tools/36.0.0/aapt2
ANDROID_JAR=/opt/android-sdk/platforms/android-36/android.jar
cd /root/LocalBridge
"$AAPT2" compile --dir res -o build/res.zip
"$AAPT2" link -o build/base.apk -I "$ANDROID_JAR" --manifest AndroidManifest.xml build/res.zip
"$AAPT2" dump badging build/base.apk | head -20
```

Expected: output includes `package: name='dev.aetherix.localbridge'`, `sdkVersion:'30'`, `targetSdkVersion:'36'`, and the five permissions.

- [ ] **Step 6: Download the test-only JSON jar**

```bash
python3 - <<'PY'
import hashlib, pathlib, urllib.request
url = 'https://repo1.maven.org/maven2/org/json/json/20240303/json-20240303.jar'
expected = '3cf6cd6892e32e2b4c1c39e0f52f5248a2f5b37646fdfbb79a66b46b618414ed'
data = urllib.request.urlopen(url, timeout=60).read()
actual = hashlib.sha256(data).hexdigest()
assert actual == expected, (actual, expected)
pathlib.Path('/root/LocalBridge/test-lib/json-20240303.jar').write_bytes(data)
print('json jar verified', len(data))
PY
```

Expected: `json jar verified 78332`

---

### Task 2: HMAC and Protocol Primitives

**Files:**
- Create: `/root/LocalBridge/src/dev/aetherix/localbridge/Hmac.java`
- Create: `/root/LocalBridge/src/dev/aetherix/localbridge/Protocol.java`
- Create: `/root/LocalBridge/test/dev/aetherix/localbridge/TestMain.java`

**Interfaces:**
- Consumes: `org.json` from the test jar
- Produces:
  - `Hmac.sha256(byte[] key, String text) -> byte[]`
  - `Hmac.hex(byte[] bytes) -> String`
  - `Hmac.fromHex(String hex) -> byte[]`
  - `Hmac.constantTimeEquals(String a, String b) -> boolean`
  - `Hmac.serverProof(byte[] token, String nonce) -> String`
  - `Hmac.clientProof(byte[] token, String nonce, String client) -> String`
  - `Protocol.parseObject(String line) -> JSONObject`
  - `Protocol.hello(String nonce, String serverProof) -> String`
  - `Protocol.ready(String session) -> String`
  - `Protocol.ok(long id, JSONObject result) -> String`
  - `Protocol.error(long id, String code, String message) -> String`
  - `Protocol.handshakeError(String code) -> String`

- [ ] **Step 1: Write the failing tests**

Create `/root/LocalBridge/test/dev/aetherix/localbridge/TestMain.java`:

```java
package dev.aetherix.localbridge;

import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

public final class TestMain {
    public static void main(String[] args) throws Exception {
        testHmac();
        testProtocol();
        System.out.println("ALL TESTS PASSED");
    }

    private static void testHmac() throws Exception {
        byte[] key = "Jefe".getBytes(StandardCharsets.UTF_8);
        String mac = Hmac.hex(Hmac.sha256(key, "what do ya want for nothing?"));
        eq("5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843", mac, "RFC 4231 case 2");

        byte[] token = Hmac.fromHex("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f");
        eq(64, Hmac.serverProof(token, "abc").length(), "server proof length");
        eq(64, Hmac.clientProof(token, "abc", "opencode").length(), "client proof length");
        check(!Hmac.serverProof(token, "abc").equals(Hmac.clientProof(token, "abc", "opencode")), "proof domains differ");
        check(Hmac.constantTimeEquals(Hmac.serverProof(token, "abc"), Hmac.serverProof(token, "abc")), "constant-time equal");
        check(!Hmac.constantTimeEquals(Hmac.serverProof(token, "abc"), Hmac.serverProof(token, "abd")), "constant-time unequal");
    }

    private static void testProtocol() throws Exception {
        JSONObject result = new JSONObject().put("time", 123L);
        JSONObject ok = Protocol.parseObject(Protocol.ok(7L, result));
        eq(7L, ok.getLong("id"), "ok id");
        eq(true, ok.getBoolean("ok"), "ok flag");
        eq(123L, ok.getJSONObject("result").getLong("time"), "ok result");

        JSONObject error = Protocol.parseObject(Protocol.error(8L, "bad_path", "nope"));
        eq(8L, error.getLong("id"), "error id");
        eq(false, error.getBoolean("ok"), "error flag");
        eq("bad_path", error.getJSONObject("error").getString("code"), "error code");

        JSONObject hello = Protocol.parseObject(Protocol.hello("00", "11"));
        eq(1, hello.getInt("v"), "hello version");
        eq("00", hello.getString("nonce"), "hello nonce");
        eq("11", hello.getString("server_proof"), "hello proof");
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static void eq(Object expected, Object actual, String message) {
        if (!expected.equals(actual)) throw new AssertionError(message + ": " + expected + " != " + actual);
    }
}
```

- [ ] **Step 2: Run the tests and verify they fail**

```bash
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON=/root/LocalBridge/test-lib/json-20240303.jar
cd /root/LocalBridge
"$JAVA" -jar "$ECJ" -source 17 -target 17 -cp "$JSON" -d build/test-classes test/dev/aetherix/localbridge/TestMain.java
```

Expected: compilation fails because `Hmac` and `Protocol` do not exist.

- [ ] **Step 3: Implement `Hmac.java`**

```java
package dev.aetherix.localbridge;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public final class Hmac {
    private Hmac() {
    }

    public static byte[] sha256(byte[] key, String text) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key, "HmacSHA256"));
            return mac.doFinal(text.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new IllegalStateException("HMAC failure", e);
        }
    }

    public static String hex(byte[] bytes) {
        char[] out = new char[bytes.length * 2];
        char[] digits = "0123456789abcdef".toCharArray();
        for (int i = 0; i < bytes.length; i++) {
            int value = bytes[i] & 0xff;
            out[i * 2] = digits[value >>> 4];
            out[i * 2 + 1] = digits[value & 0x0f];
        }
        return new String(out);
    }

    public static byte[] fromHex(String hex) {
        if (hex == null || (hex.length() & 1) != 0) throw new IllegalArgumentException("invalid hex");
        byte[] out = new byte[hex.length() / 2];
        for (int i = 0; i < out.length; i++) {
            int high = Character.digit(hex.charAt(i * 2), 16);
            int low = Character.digit(hex.charAt(i * 2 + 1), 16);
            if (high < 0 || low < 0) throw new IllegalArgumentException("invalid hex");
            out[i] = (byte) ((high << 4) | low);
        }
        return out;
    }

    public static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        return MessageDigest.isEqual(
                a.getBytes(StandardCharsets.US_ASCII),
                b.getBytes(StandardCharsets.US_ASCII));
    }

    public static String serverProof(byte[] token, String nonce) {
        return hex(sha256(token, "server|" + nonce));
    }

    public static String clientProof(byte[] token, String nonce, String client) {
        return hex(sha256(token, "client|" + nonce + "|" + client));
    }
}
```

- [ ] **Step 4: Implement `Protocol.java`**

```java
package dev.aetherix.localbridge;

import org.json.JSONException;
import org.json.JSONObject;

public final class Protocol {
    public static final int VERSION = 1;

    private Protocol() {
    }

    public static JSONObject parseObject(String line) throws JSONException {
        return new JSONObject(line);
    }

    public static String hello(String nonce, String serverProof) {
        return new JSONObject()
                .put("type", "hello")
                .put("v", VERSION)
                .put("nonce", nonce)
                .put("server_proof", serverProof)
                .toString();
    }

    public static String ready(String session) {
        return new JSONObject()
                .put("type", "ready")
                .put("session", session)
                .toString();
    }

    public static String ok(long id, JSONObject result) {
        return new JSONObject()
                .put("id", id)
                .put("ok", true)
                .put("result", result)
                .toString();
    }

    public static String error(long id, String code, String message) {
        JSONObject error = new JSONObject()
                .put("code", code)
                .put("message", message);
        return new JSONObject()
                .put("id", id)
                .put("ok", false)
                .put("error", error)
                .toString();
    }

    public static String handshakeError(String code) {
        return new JSONObject()
                .put("type", "error")
                .put("code", code)
                .toString();
    }
}
```

- [ ] **Step 5: Run the tests and verify they pass**

```bash
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON=/root/LocalBridge/test-lib/json-20240303.jar
cd /root/LocalBridge
"$JAVA" -jar "$ECJ" -source 17 -target 17 -cp "$JSON" -d build/test-classes \
  src/dev/aetherix/localbridge/Hmac.java \
  src/dev/aetherix/localbridge/Protocol.java \
  test/dev/aetherix/localbridge/TestMain.java
"$JAVA" -cp "build/test-classes:$JSON" dev.aetherix.localbridge.TestMain
```

Expected: `ALL TESTS PASSED`

---

### Task 3: Path Guard

**Files:**
- Create: `/root/LocalBridge/src/dev/aetherix/localbridge/PathGuard.java`
- Modify: `/root/LocalBridge/test/dev/aetherix/localbridge/TestMain.java`

**Interfaces:**
- Consumes: none
- Produces:
  - `new PathGuard(File root) throws IOException`
  - `PathGuard.resolve(String path) throws IOException, SecurityException`
  - `PathGuard.relative(File file) -> String`

- [ ] **Step 1: Add failing path tests**

Add these imports and calls to `TestMain`:

```java
import java.io.File;
import java.nio.file.Files;

// inside main
testPathGuard();
```

Add the test method:

```java
private static void testPathGuard() throws Exception {
    File root = Files.createTempDirectory("lb-path").toFile();
    new File(root, "Download").mkdirs();
    File outside = Files.createTempDirectory("lb-outside").toFile();
    Files.write(new File(root, "Download/ok.txt").toPath(), "ok".getBytes(StandardCharsets.UTF_8));

    PathGuard guard = new PathGuard(root);
    eq(new File(root, "Download/ok.txt").getCanonicalPath(), guard.resolve("Download/ok.txt").getPath(), "valid relative");
    eq("Download/ok.txt", guard.relative(guard.resolve("Download/ok.txt")), "relative output");

    expectBad(() -> guard.resolve("../etc/passwd"), "parent traversal");
    expectBad(() -> guard.resolve(outside.getAbsolutePath() + "/x"), "absolute outside");
    expectBad(() -> guard.resolve(root.getAbsolutePath() + "2/x"), "prefix collision");

    File link = new File(root, "escape");
    Files.createSymbolicLink(link.toPath(), outside.toPath());
    expectBad(() -> guard.resolve("escape/x"), "symlink escape");
}
```

Add the helper:

```java
private static void expectBad(ThrowingRunnable action, String message) {
    try {
        action.run();
        throw new AssertionError(message + ": expected SecurityException");
    } catch (SecurityException expected) {
    } catch (Exception e) {
        throw new AssertionError(message + ": wrong exception " + e, e);
    }
}

private interface ThrowingRunnable {
    void run() throws Exception;
}
```

- [ ] **Step 2: Run tests and verify failure**

```bash
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON=/root/LocalBridge/test-lib/json-20240303.jar
cd /root/LocalBridge
"$JAVA" -jar "$ECJ" -source 17 -target 17 -cp "$JSON" -d build/test-classes \
  src/dev/aetherix/localbridge/Hmac.java \
  src/dev/aetherix/localbridge/Protocol.java \
  test/dev/aetherix/localbridge/TestMain.java
```

Expected: compilation fails because `PathGuard` does not exist.

- [ ] **Step 3: Implement `PathGuard.java`**

```java
package dev.aetherix.localbridge;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

public final class PathGuard {
    private final File root;

    public PathGuard(File root) throws IOException {
        this.root = root.getCanonicalFile();
    }

    public File root() {
        return root;
    }

    public File resolve(String path) throws IOException, SecurityException {
        if (path == null) throw new SecurityException("missing path");
        if (path.indexOf('\0') >= 0) throw new SecurityException("path contains NUL");

        File candidate;
        if (path.isEmpty()) {
            candidate = root;
        } else if (path.startsWith("/")) {
            candidate = new File(path);
        } else {
            candidate = new File(root, path);
        }

        File canonical = candidate.getCanonicalFile();
        String rootPath = root.getPath();
        String candidatePath = canonical.getPath();
        if (!candidatePath.equals(rootPath) && !candidatePath.startsWith(rootPath + File.separator)) {
            throw new SecurityException("path escapes shared storage");
        }
        return canonical;
    }

    public String relative(File file) {
        Path rootPath = root.toPath();
        Path filePath = file.toPath();
        String value = rootPath.relativize(filePath).toString();
        return value.replace(File.separatorChar, '/');
    }
}
```

- [ ] **Step 4: Run tests and verify they pass**

```bash
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON=/root/LocalBridge/test-lib/json-20240303.jar
cd /root/LocalBridge
"$JAVA" -jar "$ECJ" -source 17 -target 17 -cp "$JSON" -d build/test-classes \
  src/dev/aetherix/localbridge/Hmac.java \
  src/dev/aetherix/localbridge/PathGuard.java \
  src/dev/aetherix/localbridge/Protocol.java \
  test/dev/aetherix/localbridge/TestMain.java
"$JAVA" -cp "build/test-classes:$JSON" dev.aetherix.localbridge.TestMain
```

Expected: `ALL TESTS PASSED`

---

### Task 4: File Operations

**Files:**
- Create: `/root/LocalBridge/src/dev/aetherix/localbridge/FileOps.java`
- Modify: `/root/LocalBridge/test/dev/aetherix/localbridge/TestMain.java`

**Interfaces:**
- Consumes: `PathGuard`
- Produces:
  - `FileOps.Error(String code, String message)`
  - `new FileOps(File root) throws IOException`
  - `FileOps.stat(String path) -> JSONObject`
  - `FileOps.list(String path, int limit) -> JSONObject`
  - `FileOps.read(String path, long offset, int length) -> JSONObject`
  - `FileOps.write(String path, long offset, byte[] data, boolean truncate) -> JSONObject`
  - `FileOps.mkdir(String path, boolean parents) -> JSONObject`
  - `FileOps.rename(String from, String to) -> JSONObject`
  - `FileOps.delete(String path) -> JSONObject`
  - `FileOps.hash(String path) -> JSONObject`

- [ ] **Step 1: Add failing file-operation tests**

Add `testFileOps();` to `main`, and add:

```java
private static void testFileOps() throws Exception {
    File root = Files.createTempDirectory("lb-files").toFile();
    new File(root, "Download").mkdirs();
    FileOps files = new FileOps(root);

    JSONObject write = files.write("Download/a.txt", 0, "hello".getBytes(StandardCharsets.UTF_8), true);
    eq(5L, write.getLong("written"), "write length");
    eq(5L, write.getLong("size"), "write size");

    JSONObject stat = files.stat("Download/a.txt");
    eq("file", stat.getString("type"), "stat type");
    eq(5L, stat.getLong("size"), "stat size");

    JSONObject read = files.read("Download/a.txt", 0, 1024);
    eq("hello", new String(java.util.Base64.getDecoder().decode(read.getString("data")), StandardCharsets.UTF_8), "read data");
    eq(true, read.getBoolean("eof"), "read eof");

    JSONObject hash = files.hash("Download/a.txt");
    eq("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824", hash.getString("value"), "sha256");

    files.mkdir("Download/sub", false);
    eq("dir", files.stat("Download/sub").getString("type"), "mkdir");

    JSONObject rename = files.rename("Download/a.txt", "Download/b.txt");
    eq(true, rename.getBoolean("renamed"), "rename");
    eq("file", files.stat("Download/b.txt").getString("type"), "rename target");

    JSONObject list = files.list("Download", 10);
    eq(2, list.getJSONArray("entries").length(), "list length");
    eq(false, list.getBoolean("truncated"), "list truncation");

    try {
        files.delete("Download/sub/x");
        throw new AssertionError("missing delete should fail");
    } catch (FileOps.Error e) {
        eq("not_found", e.code, "missing delete code");
    }

    files.delete("Download/b.txt");
    files.delete("Download/sub");
    expectBad(() -> {
        try { files.stat("../../etc/passwd"); }
        catch (FileOps.Error e) { throw new SecurityException(e.code); }
    }, "file traversal");

    try {
        files.delete(".");
        throw new AssertionError("root delete should fail");
    } catch (FileOps.Error e) {
        eq("bad_request", e.code, "root delete code");
    }
}
```

- [ ] **Step 2: Run tests and verify failure**

```bash
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON=/root/LocalBridge/test-lib/json-20240303.jar
cd /root/LocalBridge
"$JAVA" -jar "$ECJ" -source 17 -target 17 -cp "$JSON" -d build/test-classes \
  src/dev/aetherix/localbridge/Hmac.java \
  src/dev/aetherix/localbridge/PathGuard.java \
  src/dev/aetherix/localbridge/Protocol.java \
  test/dev/aetherix/localbridge/TestMain.java
```

Expected: compilation fails because `FileOps` does not exist.

- [ ] **Step 3: Implement `FileOps.java`**

```java
package dev.aetherix.localbridge;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;

public final class FileOps {
    public static final int MAX_CHUNK = 512 * 1024;
    private static final int MAX_LIST_BYTES = 800 * 1024;

    public static final class Error extends Exception {
        private static final long serialVersionUID = 1L;

        public final String code;

        public Error(String code, String message) {
            super(message);
            this.code = code;
        }
    }

    private final PathGuard guard;

    public FileOps(File root) throws IOException {
        this.guard = new PathGuard(root);
    }

    public JSONObject stat(String path) throws Error {
        File file = resolve(path);
        if (!file.exists()) throw new Error("not_found", "not found");
        return stat(file);
    }

    public JSONObject list(String path, int limit) throws Error {
        File dir = resolve(path);
        if (!dir.exists()) throw new Error("not_found", "not found");
        if (!dir.isDirectory()) throw new Error("bad_request", "not a directory");
        File[] children = dir.listFiles();
        if (children == null) throw new Error("io_error", "cannot list directory");

        List<File> sorted = new ArrayList<>(Arrays.asList(children));
        sorted.sort(Comparator.comparing(File::getName));

        int max = Math.max(1, Math.min(limit <= 0 ? 1000 : limit, 5000));
        JSONArray entries = new JSONArray();
        int bytes = 0;
        boolean truncated = false;

        for (File child : sorted) {
            if (entries.length() >= max) {
                truncated = true;
                break;
            }
            JSONObject entry = new JSONObject()
                    .put("name", child.getName())
                    .put("type", type(child))
                    .put("size", child.isFile() ? child.length() : 0L)
                    .put("mtime", child.lastModified());
            int size = entry.toString().getBytes(StandardCharsets.UTF_8).length + 1;
            if (bytes + size > MAX_LIST_BYTES) {
                truncated = true;
                break;
            }
            entries.put(entry);
            bytes += size;
        }

        return new JSONObject()
                .put("entries", entries)
                .put("truncated", truncated);
    }

    public JSONObject read(String path, long offset, int length) throws Error {
        File file = resolve(path);
        if (!file.exists()) throw new Error("not_found", "not found");
        if (!file.isFile()) throw new Error("bad_request", "not a file");
        if (offset < 0) throw new Error("bad_request", "negative offset");
        int max = Math.max(1, Math.min(length <= 0 ? MAX_CHUNK : length, MAX_CHUNK));
        long size = file.length();

        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] buffer = new byte[max];
            int count = 0;
            if (offset < size) {
                raf.seek(offset);
                count = raf.read(buffer);
                if (count < 0) count = 0;
            }
            byte[] data = count == buffer.length ? buffer : Arrays.copyOf(buffer, count);
            return new JSONObject()
                    .put("data", Base64.getEncoder().encodeToString(data))
                    .put("offset", offset)
                    .put("length", count)
                    .put("size", size)
                    .put("eof", offset + count >= size);
        } catch (IOException e) {
            throw new Error("io_error", "cannot read file");
        }
    }

    public JSONObject write(String path, long offset, byte[] data, boolean truncate) throws Error {
        if (data == null) throw new Error("bad_request", "missing data");
        if (data.length > MAX_CHUNK) throw new Error("too_large", "chunk too large");
        if (offset < 0) throw new Error("bad_request", "negative offset");

        File file = resolve(path);
        File parent = file.getParentFile();
        if (parent == null || !parent.isDirectory()) throw new Error("not_found", "parent not found");
        if (file.exists() && !file.isFile()) throw new Error("bad_request", "not a file");

        try (RandomAccessFile raf = new RandomAccessFile(file, "rw")) {
            if (truncate) raf.setLength(0);
            raf.seek(offset);
            raf.write(data);
            return new JSONObject()
                    .put("written", data.length)
                    .put("size", raf.length());
        } catch (IOException e) {
            throw new Error("io_error", "cannot write file");
        }
    }

    public JSONObject mkdir(String path, boolean parents) throws Error {
        File dir = resolve(path);
        if (dir.exists()) throw new Error("exists", "already exists");
        boolean created = parents ? dir.mkdirs() : dir.mkdir();
        if (!created) throw new Error("io_error", "cannot create directory");
        return new JSONObject().put("created", true);
    }

    public JSONObject rename(String from, String to) throws Error {
        File source = resolve(from);
        File target = resolve(to);
        if (!source.exists()) throw new Error("not_found", "source not found");
        if (target.exists()) throw new Error("exists", "target exists");
        File parent = target.getParentFile();
        if (parent == null || !parent.isDirectory()) throw new Error("not_found", "target parent not found");
        if (!source.renameTo(target)) throw new Error("io_error", "rename failed");
        return new JSONObject().put("renamed", true);
    }

    public JSONObject delete(String path) throws Error {
        File file = resolve(path);
        if (file.equals(guard.root())) throw new Error("bad_request", "cannot delete storage root");
        if (!file.exists()) throw new Error("not_found", "not found");
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null && children.length > 0) throw new Error("not_empty", "directory not empty");
        }
        if (!file.delete()) throw new Error("io_error", "delete failed");
        return new JSONObject().put("deleted", true);
    }

    public JSONObject hash(String path) throws Error {
        File file = resolve(path);
        if (!file.exists()) throw new Error("not_found", "not found");
        if (!file.isFile()) throw new Error("bad_request", "not a file");
        try (FileInputStream in = new FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = in.read(buffer)) >= 0) {
                digest.update(buffer, 0, count);
            }
            return new JSONObject()
                    .put("algorithm", "sha256")
                    .put("value", Hmac.hex(digest.digest()))
                    .put("size", file.length());
        } catch (Exception e) {
            throw new Error("io_error", "cannot hash file");
        }
    }

    private JSONObject stat(File file) {
        return new JSONObject()
                .put("path", guard.relative(file))
                .put("type", type(file))
                .put("size", file.isFile() ? file.length() : 0L)
                .put("mtime", file.lastModified());
    }

    private File resolve(String path) throws Error {
        try {
            return guard.resolve(path);
        } catch (SecurityException e) {
            throw new Error("bad_path", "path escapes shared storage");
        } catch (IOException e) {
            throw new Error("io_error", "cannot resolve path");
        }
    }

    private static String type(File file) {
        if (file.isDirectory()) return "dir";
        if (file.isFile()) return "file";
        return "other";
    }
}
```

- [ ] **Step 4: Run tests and verify they pass**

```bash
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON=/root/LocalBridge/test-lib/json-20240303.jar
cd /root/LocalBridge
"$JAVA" -jar "$ECJ" -source 17 -target 17 -cp "$JSON" -d build/test-classes \
  src/dev/aetherix/localbridge/Hmac.java \
  src/dev/aetherix/localbridge/PathGuard.java \
  src/dev/aetherix/localbridge/FileOps.java \
  src/dev/aetherix/localbridge/Protocol.java \
  test/dev/aetherix/localbridge/TestMain.java
"$JAVA" -cp "build/test-classes:$JSON" dev.aetherix.localbridge.TestMain
```

Expected: `ALL TESTS PASSED`

---

### Task 5: TCP Server and Handshake

**Files:**
- Create: `/root/LocalBridge/src/dev/aetherix/localbridge/BridgeServer.java`
- Modify: `/root/LocalBridge/test/dev/aetherix/localbridge/TestMain.java`

**Interfaces:**
- Consumes: `Hmac`, `Protocol`, `FileOps`
- Produces:
  - `BridgeServer.Listener.onState(String state)`
  - `new BridgeServer(int port, byte[] token, File root, BridgeServer.Listener listener) throws IOException`
  - `BridgeServer.getPort() -> int`
  - `BridgeServer.run() -> void`
  - `BridgeServer.close() -> void`

- [ ] **Step 1: Add failing server tests**

Add `testServer();` to `main`, and add:

```java
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;

private static void testServer() throws Exception {
    File root = Files.createTempDirectory("lb-server").toFile();
    Files.write(new File(root, "hello.txt").toPath(), "hello".getBytes(StandardCharsets.UTF_8));
    byte[] token = Hmac.fromHex("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f");

    BridgeServer server = new BridgeServer(0, token, root, null);
    Thread thread = new Thread(server, "test-server");
    thread.start();
    try {
        try (Socket socket = new Socket("127.0.0.1", server.getPort())) {
            socket.setSoTimeout(5000);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            Writer out = new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8);

            JSONObject hello = new JSONObject(in.readLine());
            eq("hello", hello.getString("type"), "hello type");
            String nonce = hello.getString("nonce");
            eq(Hmac.serverProof(token, nonce), hello.getString("server_proof"), "server proof");

            out.write(new JSONObject()
                    .put("type", "auth")
                    .put("client", "test")
                    .put("proof", Hmac.clientProof(token, nonce, "test"))
                    .toString() + "\n");
            out.flush();

            JSONObject ready = new JSONObject(in.readLine());
            eq("ready", ready.getString("type"), "ready type");

            out.write("{\"id\":1,\"op\":\"ping\"}\n");
            out.flush();
            JSONObject ping = new JSONObject(in.readLine());
            eq(true, ping.getBoolean("ok"), "ping ok");
            check(ping.getJSONObject("result").getLong("time") > 0, "ping time");

            out.write("{\"id\":2,\"op\":\"stat\",\"path\":\"hello.txt\"}\n");
            out.flush();
            JSONObject stat = new JSONObject(in.readLine());
            eq(5L, stat.getJSONObject("result").getLong("size"), "stat size");

            out.write("{\"id\":3,\"op\":\"stat\",\"path\":\"../x\"}\n");
            out.flush();
            JSONObject bad = new JSONObject(in.readLine());
            eq(false, bad.getBoolean("ok"), "bad path failed");
            eq("bad_path", bad.getJSONObject("error").getString("code"), "bad path code");
        }

        try (Socket socket = new Socket("127.0.0.1", server.getPort())) {
            socket.setSoTimeout(5000);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            Writer out = new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8);
            JSONObject hello = new JSONObject(in.readLine());
            out.write(new JSONObject()
                    .put("type", "auth")
                    .put("client", "test")
                    .put("proof", "00".repeat(32))
                    .toString() + "\n");
            out.flush();
            JSONObject error = new JSONObject(in.readLine());
            eq("error", error.getString("type"), "auth error type");
            eq("auth_failed", error.getString("code"), "auth error code");
        }
    } finally {
        server.close();
        thread.join(3000);
    }
}
```

- [ ] **Step 2: Run tests and verify failure**

```bash
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON=/root/LocalBridge/test-lib/json-20240303.jar
cd /root/LocalBridge
"$JAVA" -jar "$ECJ" -source 17 -target 17 -cp "$JSON" -d build/test-classes \
  src/dev/aetherix/localbridge/Hmac.java \
  src/dev/aetherix/localbridge/PathGuard.java \
  src/dev/aetherix/localbridge/FileOps.java \
  src/dev/aetherix/localbridge/Protocol.java \
  test/dev/aetherix/localbridge/TestMain.java
```

Expected: compilation fails because `BridgeServer` does not exist.

- [ ] **Step 3: Implement `BridgeServer.java`**

```java
package dev.aetherix.localbridge;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.concurrent.atomic.AtomicInteger;

public final class BridgeServer implements Runnable, Closeable {
    public interface Listener {
        void onState(String state);
    }

    private static final int MAX_FRAME = 1024 * 1024;

    private final ServerSocket server;
    private final byte[] token;
    private final FileOps files;
    private final Listener listener;
    private final SecureRandom random = new SecureRandom();
    private final AtomicInteger failures = new AtomicInteger();
    private volatile boolean running = true;
    private volatile Socket client;
    private volatile long lockUntil;

    public BridgeServer(int port, byte[] token, File root, Listener listener) throws IOException {
        this.token = token.clone();
        this.files = new FileOps(root);
        this.listener = listener;
        this.server = new ServerSocket();
        this.server.setReuseAddress(false);
        this.server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 1);
    }

    public int getPort() {
        return server.getLocalPort();
    }

    @Override
    public void run() {
        state("listening");
        while (running) {
            try {
                Socket socket = server.accept();
                client = socket;
                handle(socket);
            } catch (SocketException e) {
                if (running) state("error");
                break;
            } catch (IOException e) {
                if (running) state("error");
            } finally {
                client = null;
            }
        }
        state("stopped");
    }

    private void handle(Socket socket) {
        try (Socket ignored = socket) {
            socket.setSoTimeout(30000);
            InputStream in = socket.getInputStream();
            OutputStream out = socket.getOutputStream();

            if (System.currentTimeMillis() < lockUntil) {
                send(out, Protocol.handshakeError("locked"));
                return;
            }

            byte[] nonceBytes = new byte[32];
            random.nextBytes(nonceBytes);
            String nonce = Hmac.hex(nonceBytes);
            send(out, Protocol.hello(nonce, Hmac.serverProof(token, nonce)));

            String authLine = readLine(in, MAX_FRAME);
            if (authLine == null) return;
            JSONObject auth;
            try {
                auth = Protocol.parseObject(authLine);
            } catch (JSONException e) {
                fail(out);
                return;
            }

            String clientName = auth.optString("client", "");
            String proof = auth.optString("proof", "");
            if (!"auth".equals(auth.optString("type", ""))
                    || !validClientName(clientName) || !Hmac.constantTimeEquals(
                    Hmac.clientProof(token, nonce, clientName), proof)) {
                fail(out);
                return;
            }

            failures.set(0);
            byte[] session = new byte[16];
            random.nextBytes(session);
            send(out, Protocol.ready(Hmac.hex(session)));
            state("authenticated");

            socket.setSoTimeout(120000);
            while (running) {
                String line = readLine(in, MAX_FRAME);
                if (line == null) break;
                JSONObject request;
                long id = 0;
                try {
                    request = Protocol.parseObject(line);
                    id = request.optLong("id", 0);
                    send(out, handleRequest(id, request));
                } catch (JSONException e) {
                    send(out, Protocol.error(id, "bad_request", "invalid JSON"));
                } catch (FileOps.Error e) {
                    send(out, Protocol.error(id, e.code, e.getMessage()));
                } catch (IllegalArgumentException e) {
                    send(out, Protocol.error(id, "bad_request", "invalid argument"));
                } catch (Exception e) {
                    send(out, Protocol.error(id, "io_error", "request failed"));
                }
            }
        } catch (IOException e) {
            state("disconnected");
        }
    }

    private String handleRequest(long id, JSONObject request) throws Exception {
        String op = request.optString("op", "");
        switch (op) {
            case "ping":
                return Protocol.ok(id, new JSONObject().put("time", System.currentTimeMillis()));
            case "stat":
                return Protocol.ok(id, files.stat(required(request, "path")));
            case "list":
                return Protocol.ok(id, files.list(required(request, "path"), request.optInt("limit", 1000)));
            case "read":
                return Protocol.ok(id, files.read(
                        required(request, "path"),
                        request.optLong("offset", 0),
                        request.optInt("length", FileOps.MAX_CHUNK)));
            case "write": {
                String encoded = required(request, "data");
                byte[] data = Base64.getDecoder().decode(encoded);
                return Protocol.ok(id, files.write(
                        required(request, "path"),
                        request.optLong("offset", 0),
                        data,
                        request.optBoolean("truncate", false)));
            }
            case "mkdir":
                return Protocol.ok(id, files.mkdir(required(request, "path"), request.optBoolean("parents", false)));
            case "rename":
                return Protocol.ok(id, files.rename(required(request, "path"), required(request, "to")));
            case "delete":
                return Protocol.ok(id, files.delete(required(request, "path")));
            case "hash":
                return Protocol.ok(id, files.hash(required(request, "path")));
            default:
                return Protocol.error(id, "unsupported", "unknown operation");
        }
    }

    private static String required(JSONObject request, String name) throws JSONException {
        if (!request.has(name) || request.isNull(name)) throw new JSONException("missing " + name);
        return request.getString(name);
    }

    private void fail(OutputStream out) throws IOException {
        int count = failures.incrementAndGet();
        if (count >= 5) {
            lockUntil = System.currentTimeMillis() + 60000;
            failures.set(0);
        }
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        send(out, Protocol.handshakeError("auth_failed"));
        state("auth_failed");
    }

    private static boolean validClientName(String name) {
        if (name == null || name.isEmpty() || name.length() > 64) return false;
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c < 0x20 || c > 0x7e) return false;
        }
        return true;
    }

    private static void send(OutputStream out, String line) throws IOException {
        out.write((line + "\n").getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    private static String readLine(InputStream in, int max) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int value;
        while ((value = in.read()) != -1) {
            if (value == '\n') break;
            if (value != '\r') buffer.write(value);
            if (buffer.size() > max) throw new IOException("frame too large");
        }
        if (value == -1 && buffer.size() == 0) return null;
        return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
    }

    private void state(String value) {
        if (listener != null) listener.onState(value);
    }

    @Override
    public void close() {
        running = false;
        Socket current = client;
        if (current != null) {
            try {
                current.close();
            } catch (IOException ignored) {
            }
        }
        try {
            server.close();
        } catch (IOException ignored) {
        }
    }
}
```

- [ ] **Step 4: Run tests and verify they pass**

```bash
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON=/root/LocalBridge/test-lib/json-20240303.jar
cd /root/LocalBridge
"$JAVA" -jar "$ECJ" -source 17 -target 17 -cp "$JSON" -d build/test-classes \
  src/dev/aetherix/localbridge/Hmac.java \
  src/dev/aetherix/localbridge/PathGuard.java \
  src/dev/aetherix/localbridge/FileOps.java \
  src/dev/aetherix/localbridge/Protocol.java \
  src/dev/aetherix/localbridge/BridgeServer.java \
  test/dev/aetherix/localbridge/TestMain.java
"$JAVA" -cp "build/test-classes:$JSON" dev.aetherix.localbridge.TestMain
```

Expected: `ALL TESTS PASSED`

---

### Task 6: Android Pairing, Service, and UI

**Files:**
- Create: `/root/LocalBridge/src/dev/aetherix/localbridge/PairingStore.java`
- Create: `/root/LocalBridge/src/dev/aetherix/localbridge/BridgeService.java`
- Create: `/root/LocalBridge/src/dev/aetherix/localbridge/MainActivity.java`

**Interfaces:**
- Consumes: `Hmac`, `BridgeServer`, `FileOps`
- Produces:
  - `PairingStore.getOrCreate(Context) -> byte[]`
  - `PairingStore.hex(Context) -> String`
  - `PairingStore.regenerate(Context) -> String`
  - `BridgeService.ACTION_START`, `ACTION_STOP`, `PORT`
  - `BridgeService.isRunning() -> boolean`

- [ ] **Step 1: Implement `PairingStore.java`**

```java
package dev.aetherix.localbridge;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.SecureRandom;

public final class PairingStore {
    private static final String PREFS = "localbridge";
    private static final String KEY = "token";

    private PairingStore() {
    }

    public static synchronized byte[] getOrCreate(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String value = prefs.getString(KEY, null);
        if (value != null && value.length() == 64) {
            try {
                return Hmac.fromHex(value);
            } catch (IllegalArgumentException ignored) {
            }
        }
        return Hmac.fromHex(regenerate(context));
    }

    public static synchronized String hex(Context context) {
        return Hmac.hex(getOrCreate(context));
    }

    public static synchronized String regenerate(Context context) {
        byte[] token = new byte[32];
        new SecureRandom().nextBytes(token);
        String value = Hmac.hex(token);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY, value)
                .commit();
        return value;
    }
}
```

- [ ] **Step 2: Implement `BridgeService.java`**

```java
package dev.aetherix.localbridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;

import java.io.File;

public final class BridgeService extends Service {
    public static final String ACTION_START = "dev.aetherix.localbridge.START";
    public static final String ACTION_STOP = "dev.aetherix.localbridge.STOP";
    public static final int PORT = 39401;

    private static final String CHANNEL = "localbridge";
    private static final int NOTIFICATION_ID = 39401;

    private BridgeServer server;
    private Thread thread;
    private static volatile boolean running;

    public static boolean isRunning() {
        return running;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager.getNotificationChannel(CHANNEL) == null) {
            manager.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "LocalBridge", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        startForegroundCompat(notification("Starting"));
        if (ACTION_STOP.equals(action)) {
            stopBridge();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Environment.isExternalStorageManager()) {
            notify("All files access is required");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (server == null) {
            try {
                File root = Environment.getExternalStorageDirectory();
                server = new BridgeServer(PORT, PairingStore.getOrCreate(this), root, this::notify);
                thread = new Thread(server, "localbridge-server");
                thread.start();
                running = true;
                notify("Listening on 127.0.0.1:" + PORT);
            } catch (Exception e) {
                notify("Cannot start: " + e.getMessage());
                stopSelf();
            }
        }
        return START_NOT_STICKY;
    }

    private void stopBridge() {
        running = false;
        if (server != null) {
            server.close();
            server = null;
        }
        if (thread != null) {
            try {
                thread.join(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            thread = null;
        }
    }

    private void startForegroundCompat(Notification notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(
                this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, BridgeService.class).setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(
                this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("LocalBridge")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentIntent(content)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent).build())
                .setOngoing(true)
                .build();
    }

    private void notify(String text) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.notify(NOTIFICATION_ID, notification(text));
    }

    @Override
    public void onDestroy() {
        stopBridge();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
```

- [ ] **Step 3: Implement `MainActivity.java`**

```java
package dev.aetherix.localbridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private TextView status;
    private TextView token;
    private Button grant;
    private Button start;
    private Button stop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[] { android.Manifest.permission.POST_NOTIFICATIONS }, 1);
        }
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        title.setText("LocalBridge");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 24, 0, 8);
        root.addView(status);

        grant = new Button(this);
        grant.setText("Grant All files access");
        grant.setOnClickListener(v -> openAllFilesSettings());
        root.addView(grant);

        TextView label = new TextView(this);
        label.setText("Pairing token");
        label.setPadding(0, 24, 0, 4);
        root.addView(label);

        token = new TextView(this);
        token.setTextSize(13);
        token.setTypeface(Typeface.MONOSPACE);
        token.setTextIsSelectable(true);
        ScrollView tokenScroll = new ScrollView(this);
        tokenScroll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 160));
        tokenScroll.addView(token);
        root.addView(tokenScroll);

        LinearLayout tokenButtons = new LinearLayout(this);
        tokenButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = new Button(this);
        copy.setText("Copy");
        copy.setOnClickListener(v -> copyToken());
        Button regenerate = new Button(this);
        regenerate.setText("Regenerate");
        regenerate.setOnClickListener(v -> confirmRegenerate());
        tokenButtons.addView(copy);
        tokenButtons.addView(regenerate);
        root.addView(tokenButtons);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        start = new Button(this);
        start.setText("Start");
        start.setOnClickListener(v -> startBridge());
        stop = new Button(this);
        stop.setText("Stop");
        stop.setOnClickListener(v -> stopBridge());
        controls.addView(start);
        controls.addView(stop);
        root.addView(controls);

        TextView note = new TextView(this);
        note.setText("Android/data and Android/obb may remain restricted even with All files access.");
        note.setTextSize(12);
        note.setPadding(0, 24, 0, 0);
        root.addView(note);

        return root;
    }

    private void refresh() {
        boolean granted = Environment.isExternalStorageManager();
        status.setText((granted ? "All files access: granted" : "All files access: not granted")
                + "\nServer: " + (BridgeService.isRunning() ? "running on 127.0.0.1:" + BridgeService.PORT : "stopped"));
        grant.setEnabled(!granted);
        token.setText(PairingStore.hex(this));
        start.setEnabled(granted && !BridgeService.isRunning());
        stop.setEnabled(BridgeService.isRunning());
    }

    private void openAllFilesSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
            startActivity(intent);
        }
    }

    private void startBridge() {
        if (!Environment.isExternalStorageManager()) {
            Toast.makeText(this, "Grant All files access first", Toast.LENGTH_SHORT).show();
            openAllFilesSettings();
            return;
        }
        Intent intent = new Intent(this, BridgeService.class).setAction(BridgeService.ACTION_START);
        startForegroundService(intent);
        start.postDelayed(this::refresh, 300);
    }

    private void stopBridge() {
        startService(new Intent(this, BridgeService.class).setAction(BridgeService.ACTION_STOP));
        start.postDelayed(this::refresh, 300);
    }

    private void copyToken() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("LocalBridge token", PairingStore.hex(this)));
        Toast.makeText(this, "Token copied", Toast.LENGTH_SHORT).show();
    }

    private void confirmRegenerate() {
        new AlertDialog.Builder(this)
                .setTitle("Regenerate token?")
                .setMessage("The current token will stop working immediately.")
                .setPositiveButton("Regenerate", (dialog, which) -> {
                    stopService(new Intent(this, BridgeService.class));
                    PairingStore.regenerate(this);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
```

- [ ] **Step 4: Compile the Android classes**

```bash
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
ANDROID_JAR=/opt/android-sdk/platforms/android-36/android.jar
JSON=/root/LocalBridge/test-lib/json-20240303.jar
cd /root/LocalBridge
"$JAVA" -jar "$ECJ" -source 8 -target 8 -cp "$JSON:$ANDROID_JAR" -d build/classes \
  src/dev/aetherix/localbridge/Hmac.java \
  src/dev/aetherix/localbridge/Protocol.java \
  src/dev/aetherix/localbridge/PathGuard.java \
  src/dev/aetherix/localbridge/FileOps.java \
  src/dev/aetherix/localbridge/BridgeServer.java \
  src/dev/aetherix/localbridge/PairingStore.java \
  src/dev/aetherix/localbridge/BridgeService.java \
  src/dev/aetherix/localbridge/MainActivity.java
```

Expected: compilation succeeds with class files under `build/classes/dev/aetherix/localbridge/`.

- [ ] **Step 5: Produce a draft DEX**

```bash
BT=/opt/android-sdk/build-tools/36.0.0
ANDROID_JAR=/opt/android-sdk/platforms/android-36/android.jar
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
cd /root/LocalBridge
python3 - <<'PY'
import os, zipfile
src = '/root/LocalBridge/build/classes'
out = '/root/LocalBridge/build/classes.jar'
with zipfile.ZipFile(out, 'w') as z:
    for root, dirs, files in os.walk(src):
        for name in files:
            path = os.path.join(root, name)
            z.write(path, os.path.relpath(path, src))
print(out)
PY
python3 - <<'PY'
import os
os.makedirs('/root/LocalBridge/build/dex', exist_ok=True)
PY
"$BT/d8" --lib "$ANDROID_JAR" --min-api 30 --output build/dex build/classes.jar
python3 - <<'PY'
import os
p = '/root/LocalBridge/build/dex/classes.dex'
print(p, os.path.getsize(p))
PY
```

Expected: `classes.dex` exists and is larger than 10 KB.

---

### Task 7: Build Script and Signed APK

**Files:**
- Create: `/root/LocalBridge/build.sh`
- Create: `/root/.local/share/localbridge/` (keystore directory, generated by script)
- Output: `/root/LocalBridge/build/LocalBridge.apk`

**Interfaces:**
- Consumes: all source files and resources
- Produces: signed `LocalBridge.apk`

- [ ] **Step 1: Create `build.sh`**

```bash
#!/bin/bash
set -euo pipefail

export JAVA_HOME=/opt/jdk-17.0.20.1+1-jre
export PATH="$JAVA_HOME/bin:$PATH"

ROOT=/root/LocalBridge
SDK=/opt/android-sdk
BT="$SDK/build-tools/36.0.0"
ANDROID_JAR="$SDK/platforms/android-36/android.jar"
JAVA=/opt/jdk-17.0.20.1+1-jre/bin/java
KEYTOOL=/opt/jdk-17.0.20.1+1-jre/bin/keytool
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON="$ROOT/test-lib/json-20240303.jar"
KEYDIR=/root/.local/share/localbridge
KEYSTORE="$KEYDIR/localbridge.keystore"
PASSFILE="$KEYDIR/keystore.pass"
OUT="$ROOT/build"
APK="$OUT/LocalBridge.apk"

python3 - <<'PY'
import os, shutil
for d in ['/root/LocalBridge/build/classes', '/root/LocalBridge/build/dex']:
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d, exist_ok=True)
for p in ['/root/LocalBridge/build/res.zip', '/root/LocalBridge/build/base.apk',
          '/root/LocalBridge/build/classes.jar', '/root/LocalBridge/build/unsigned.apk',
          '/root/LocalBridge/build/aligned.apk']:
    if os.path.exists(p):
        os.remove(p)
PY

"$BT/aapt2" compile --dir "$ROOT/res" -o "$OUT/res.zip"
"$BT/aapt2" link -o "$OUT/base.apk" -I "$ANDROID_JAR" \
    --manifest "$ROOT/AndroidManifest.xml" "$OUT/res.zip"

SOURCES=$(python3 - <<'PY'
import glob
print(' '.join(sorted(glob.glob('/root/LocalBridge/src/**/*.java', recursive=True))))
PY
)
"$JAVA" -jar "$ECJ" -source 8 -target 8 -cp "$JSON:$ANDROID_JAR" -d "$OUT/classes" $SOURCES

python3 - <<'PY'
import os, zipfile
src = '/root/LocalBridge/build/classes'
out = '/root/LocalBridge/build/classes.jar'
with zipfile.ZipFile(out, 'w') as z:
    for root, dirs, files in os.walk(src):
        for name in files:
            path = os.path.join(root, name)
            z.write(path, os.path.relpath(path, src))
PY

"$BT/d8" --lib "$ANDROID_JAR" --min-api 30 --output "$OUT/dex" "$OUT/classes.jar"

python3 - <<'PY'
import shutil, zipfile
base = '/root/LocalBridge/build/base.apk'
un = '/root/LocalBridge/build/unsigned.apk'
shutil.copyfile(base, un)
with zipfile.ZipFile(un, 'a') as z:
    z.write('/root/LocalBridge/build/dex/classes.dex', 'classes.dex')
PY

"$BT/zipalign" -f 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

python3 - <<'PY'
import os, secrets, pathlib
keydir = pathlib.Path('/root/.local/share/localbridge')
keydir.mkdir(parents=True, exist_ok=True)
passfile = keydir / 'keystore.pass'
if not passfile.exists():
    passfile.write_text(secrets.token_hex(24))
    os.chmod(passfile, 0o600)
PY

PASS=$(cat "$PASSFILE")
if [ ! -f "$KEYSTORE" ]; then
    "$KEYTOOL" -genkeypair -keystore "$KEYSTORE" -alias localbridge \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass "$PASS" -keypass "$PASS" \
        -dname "CN=LocalBridge" -noprompt
fi

"$BT/apksigner" sign --ks "$KEYSTORE" --ks-key-alias localbridge \
    --ks-pass "pass:$PASS" --key-pass "pass:$PASS" \
    --out "$APK" "$OUT/aligned.apk"

"$BT/apksigner" verify --print-certs "$APK"
"$BT/aapt2" dump badging "$APK" | head -20
python3 - <<'PY'
import os
p = '/root/LocalBridge/build/LocalBridge.apk'
print('APK', p, os.path.getsize(p), 'bytes')
PY
```

- [ ] **Step 2: Run the build**

```bash
python3 - <<'PY'
import os
os.chmod('/root/LocalBridge/build.sh', 0o755)
PY
/root/LocalBridge/build.sh
```

Expected: `apksigner` verification succeeds, badging shows `dev.aetherix.localbridge`, and the APK size is printed.

- [ ] **Step 3: Copy the APK to shared storage**

```bash
python3 - <<'PY'
import shutil
shutil.copyfile('/root/LocalBridge/build/LocalBridge.apk', '/sdcard/Download/LocalBridge.apk')
print('/sdcard/Download/LocalBridge.apk')
PY
```

Expected: path printed and file exists.

---

### Task 8: Python Client and Mock Test

**Files:**
- Create: `/root/tools/localbridge_client.py`
- Create: `/root/LocalBridge/test/test_client.py`

**Interfaces:**
- Consumes: localhost TCP server, token
- Produces: CLI subcommands `ping`, `ls`, `stat`, `get`, `put`, `mkdir`, `mv`, `rm`, `hash`

- [ ] **Step 1: Make the test directory importable**

```bash
python3 - <<'PY'
from pathlib import Path
Path('/root/LocalBridge/test/__init__.py').write_text('')
print('created test package')
PY
```

Expected: `created test package`

- [ ] **Step 2: Write the failing client test**

Create `/root/LocalBridge/test/test_client.py`:

```python
import base64
import hashlib
import hmac
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import unittest

TOKEN = bytes.fromhex("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
CLIENT = "/root/tools/localbridge_client.py"


def mac(key, text):
    return hmac.new(key, text.encode(), hashlib.sha256).hexdigest()


class MockServer(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.sock = socket.socket()
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(1)
        self.port = self.sock.getsockname()[1]
        self.error = None

    def run(self):
        try:
            conn, _ = self.sock.accept()
            with conn:
                f = conn.makefile("rwb")
                nonce = "aa" * 32
                f.write((json.dumps({
                    "type": "hello", "v": 1, "nonce": nonce,
                    "server_proof": mac(TOKEN, "server|" + nonce),
                }) + "\n").encode())
                f.flush()
                line = f.readline()
                if not line:
                    return
                auth = json.loads(line)
                expected = mac(TOKEN, "client|" + nonce + "|" + auth["client"])
                assert auth["proof"] == expected, auth
                f.write((json.dumps({"type": "ready", "session": "bb" * 16}) + "\n").encode())
                f.flush()
                req = json.loads(f.readline())
                assert req["op"] == "ping", req
                f.write((json.dumps({
                    "id": req["id"], "ok": True,
                    "result": {"time": 123},
                }) + "\n").encode())
                f.flush()
        except Exception as e:
            self.error = e
        finally:
            self.sock.close()


class ClientTest(unittest.TestCase):
    def test_ping(self):
        server = MockServer()
        server.start()
        proc = subprocess.run(
            [sys.executable, CLIENT, "--port", str(server.port), "--token", TOKEN.hex(), "ping"],
            capture_output=True, text=True, timeout=10)
        server.join(5)
        self.assertIsNone(server.error)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn('"time": 123', proc.stdout)

    def test_wrong_token_is_rejected_by_client(self):
        server = MockServer()
        server.start()
        proc = subprocess.run(
            [sys.executable, CLIENT, "--port", str(server.port), "--token", "00" * 32, "ping"],
            capture_output=True, text=True, timeout=10)
        server.join(5)
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("server authentication failed", proc.stderr)


if __name__ == "__main__":
    unittest.main()
```

- [ ] **Step 3: Run the test and verify it fails**

```bash
cd /root/LocalBridge
python3 -m unittest test.test_client -v
```

Expected: fails because `/root/tools/localbridge_client.py` does not exist.

- [ ] **Step 4: Implement the client**

Create `/root/tools/localbridge_client.py`:

```python
#!/usr/bin/env python3
import argparse
import base64
import hashlib
import hmac
import json
import os
import socket
import sys
from pathlib import Path

DEFAULT_PORT = 39401
CHUNK = 512 * 1024
TOKEN_FILE = Path("/root/.config/localbridge/token")


def mac(key, text):
    return hmac.new(key, text.encode(), hashlib.sha256).hexdigest()


def load_token(value):
    if value:
        return bytes.fromhex(value)
    env = os.environ.get("LOCALBRIDGE_TOKEN")
    if env:
        return bytes.fromhex(env)
    if TOKEN_FILE.exists():
        return bytes.fromhex(TOKEN_FILE.read_text().strip())
    raise SystemExit("no token; use --token or create /root/.config/localbridge/token")


class Bridge:
    def __init__(self, host, port, token, client="opencode"):
        self.sock = socket.create_connection((host, port), timeout=10)
        self.sock.settimeout(30)
        self.f = self.sock.makefile("rwb")
        self.token = token
        self.client = client
        self.next_id = 1

    def close(self):
        try:
            self.f.close()
        finally:
            self.sock.close()

    def handshake(self):
        hello = json.loads(self.f.readline())
        if hello.get("type") != "hello" or hello.get("v") != 1:
            raise SystemExit("unexpected server greeting")
        nonce = hello["nonce"]
        expected = mac(self.token, "server|" + nonce)
        if not hmac.compare_digest(expected, hello.get("server_proof", "")):
            raise SystemExit("server authentication failed")
        proof = mac(self.token, "client|" + nonce + "|" + self.client)
        self._write({"type": "auth", "client": self.client, "proof": proof})
        ready = json.loads(self.f.readline())
        if ready.get("type") != "ready":
            raise SystemExit("authentication rejected: %s" % ready)
        return ready

    def _write(self, obj):
        self.f.write((json.dumps(obj, separators=(",", ":")) + "\n").encode())
        self.f.flush()

    def request(self, op, **kwargs):
        rid = self.next_id
        self.next_id += 1
        obj = {"id": rid, "op": op}
        obj.update(kwargs)
        self._write(obj)
        line = self.f.readline()
        if not line:
            raise SystemExit("connection closed")
        response = json.loads(line)
        if response.get("id") != rid:
            raise SystemExit("response id mismatch")
        if not response.get("ok"):
            error = response.get("error", {})
            raise SystemExit("%s: %s" % (error.get("code", "error"), error.get("message", "")))
        return response.get("result", {})


def path_arg(value):
    return value


def cmd_ping(bridge, args):
    print(json.dumps(bridge.request("ping"), indent=2))


def cmd_ls(bridge, args):
    result = bridge.request("list", path=args.path, limit=args.limit)
    for entry in result.get("entries", []):
        print("%s\t%s\t%s" % (entry["type"], entry.get("size", 0), entry["name"]))
    if result.get("truncated"):
        print("(truncated)", file=sys.stderr)


def cmd_stat(bridge, args):
    print(json.dumps(bridge.request("stat", path=args.path), indent=2))


def cmd_get(bridge, args):
    stat = bridge.request("stat", path=args.remote)
    size = stat.get("size", 0)
    target = Path(args.local)
    target.parent.mkdir(parents=True, exist_ok=True)
    offset = 0
    with target.open("wb") as out:
        while offset < size or size == 0:
            result = bridge.request("read", path=args.remote, offset=offset, length=CHUNK)
            data = base64.b64decode(result["data"])
            out.write(data)
            offset += len(data)
            if result.get("eof") or not data:
                break
    print("%s bytes -> %s" % (target.stat().st_size, target))


def cmd_put(bridge, args):
    source = Path(args.local)
    size = source.stat().st_size
    if size == 0:
        bridge.request("write", path=args.remote, offset=0, data="", truncate=True)
        print("0 bytes -> %s" % args.remote)
        return
    offset = 0
    with source.open("rb") as inp:
        while True:
            data = inp.read(CHUNK)
            if not data:
                break
            bridge.request("write", path=args.remote, offset=offset,
                           data=base64.b64encode(data).decode(), truncate=offset == 0)
            offset += len(data)
    print("%s bytes -> %s" % (offset, args.remote))


def cmd_mkdir(bridge, args):
    print(json.dumps(bridge.request("mkdir", path=args.path, parents=args.parents), indent=2))


def cmd_mv(bridge, args):
    print(json.dumps(bridge.request("rename", path=args.source, to=args.target), indent=2))


def cmd_rm(bridge, args):
    print(json.dumps(bridge.request("delete", path=args.path), indent=2))


def cmd_hash(bridge, args):
    print(json.dumps(bridge.request("hash", path=args.path), indent=2))


def main():
    parser = argparse.ArgumentParser(description="LocalBridge client")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--token")
    parser.add_argument("--client", default="opencode")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("ping")
    p.set_defaults(func=cmd_ping)

    p = sub.add_parser("ls")
    p.add_argument("path", default=".", nargs="?")
    p.add_argument("--limit", type=int, default=1000)
    p.set_defaults(func=cmd_ls)

    p = sub.add_parser("stat")
    p.add_argument("path")
    p.set_defaults(func=cmd_stat)

    p = sub.add_parser("get")
    p.add_argument("remote")
    p.add_argument("local")
    p.set_defaults(func=cmd_get)

    p = sub.add_parser("put")
    p.add_argument("local")
    p.add_argument("remote")
    p.set_defaults(func=cmd_put)

    p = sub.add_parser("mkdir")
    p.add_argument("path")
    p.add_argument("--parents", action="store_true")
    p.set_defaults(func=cmd_mkdir)

    p = sub.add_parser("mv")
    p.add_argument("source")
    p.add_argument("target")
    p.set_defaults(func=cmd_mv)

    p = sub.add_parser("rm")
    p.add_argument("path")
    p.set_defaults(func=cmd_rm)

    p = sub.add_parser("hash")
    p.add_argument("path")
    p.set_defaults(func=cmd_hash)

    args = parser.parse_args()
    token = load_token(args.token)
    bridge = Bridge(args.host, args.port, token, args.client)
    try:
        bridge.handshake()
        args.func(bridge, args)
    finally:
        bridge.close()


if __name__ == "__main__":
    main()
```

- [ ] **Step 5: Make the client executable and run the tests**

```bash
python3 - <<'PY'
import os
os.chmod('/root/tools/localbridge_client.py', 0o755)
PY
cd /root/LocalBridge
python3 -m unittest test.test_client -v
```

Expected: two tests pass.

---

### Task 9: On-Device Validation

**Files:**
- Modify: none
- Runtime: `/sdcard/Download/LocalBridge.apk`
- Runtime: `/root/.config/localbridge/token`

**Interfaces:**
- Consumes: signed APK, token, client
- Produces: recorded on-device results

- [ ] **Step 1: Install the APK**

Tell the user to open `/sdcard/Download/LocalBridge.apk` from the device Files app and confirm installation.

Expected: LocalBridge appears in the launcher.

- [ ] **Step 2: Grant All files access**

Open LocalBridge, tap Grant All files access, enable the toggle, return to the app.

Expected: status reads `All files access: granted`.

- [ ] **Step 3: Store the token**

Ask the user to copy the 64-character token and paste it into chat. Then store it:

```bash
python3 - <<'PY'
import os, pathlib
token = input('token: ').strip()
assert len(token) == 64 and all(c in '0123456789abcdef' for c in token), 'invalid token'
p = pathlib.Path('/root/.config/localbridge/token')
p.parent.mkdir(parents=True, exist_ok=True)
p.write_text(token + '\n')
os.chmod(p, 0o600)
print('stored', p)
PY
```

Expected: `stored /root/.config/localbridge/token`

- [ ] **Step 4: Start the bridge and verify loopback binding**

Tap Start. Then:

```bash
dsh sh 'grep -i ":99E9" /proc/net/tcp || true'
python3 /root/tools/localbridge_client.py ping
```

Expected: `/proc/net/tcp` shows `0100007F:99E9` (127.0.0.1:39401), not `00000000:99E9`; `ping` returns a JSON time.

- [ ] **Step 5: Exercise file operations**

```bash
python3 /root/tools/localbridge_client.py ls Download | head
python3 /root/tools/localbridge_client.py mkdir Download/lb-test --parents
python3 - <<'PY'
import os
open('/tmp/lb-test.bin','wb').write(os.urandom(10 * 1024 * 1024))
PY
python3 /root/tools/localbridge_client.py put /tmp/lb-test.bin Download/lb-test/tenmb.bin
python3 /root/tools/localbridge_client.py hash Download/lb-test/tenmb.bin
python3 /root/tools/localbridge_client.py get Download/lb-test/tenmb.bin /tmp/lb-test.out
python3 - <<'PY'
import hashlib
a = hashlib.sha256(open('/tmp/lb-test.bin','rb').read()).hexdigest()
b = hashlib.sha256(open('/tmp/lb-test.out','rb').read()).hexdigest()
print(a, b, 'MATCH' if a == b else 'MISMATCH')
PY
```

Expected: both hashes match.

- [ ] **Step 6: Test rejection paths**

```bash
python3 /root/tools/localbridge_client.py stat ../../etc/passwd || true
python3 /root/tools/localbridge_client.py ls Android/data || true
```

Expected: traversal returns `bad_path`; `Android/data` returns either a listing or `denied`/`io_error`, recorded exactly.

- [ ] **Step 7: Verify five-failure lockout**

```bash
python3 - <<'PY'
import json, socket
for i in range(6):
    s = socket.create_connection(("127.0.0.1", 39401), timeout=10)
    f = s.makefile("rwb")
    hello = json.loads(f.readline())
    if hello.get("type") == "error":
        print(i, hello)
        f.close()
        s.close()
        break
    f.write((json.dumps({"type": "auth", "client": "bad", "proof": "00" * 32}) + "\n").encode())
    f.flush()
    print(i, f.readline().decode().strip())
    f.close()
    s.close()
PY
```

Expected: the first five responses are `auth_failed`; the sixth is `locked`. Tap Stop and Start to clear the in-memory lock before continuing.

- [ ] **Step 8: Stop and restart**

Tap Stop. Verify:

```bash
python3 /root/tools/localbridge_client.py ping || true
```

Expected: connection refused. Tap Start again; `ping` works; token persists.

- [ ] **Step 9: Clean up**

```bash
python3 /root/tools/localbridge_client.py rm Download/lb-test/tenmb.bin
python3 /root/tools/localbridge_client.py rm Download/lb-test
python3 - <<'PY'
import os
for p in ['/tmp/lb-test.bin','/tmp/lb-test.out']:
    try: os.remove(p)
    except FileNotFoundError: pass
PY
```

Expected: test files removed. Leave the app installed and the server stopped.

---

## Self-Review

### Spec Coverage

- Shared-storage-only scope: Task 1 manifest, Task 4 root sandbox, Task 9 Android/data test.
- Loopback-only binding: Task 5 constructor binds `127.0.0.1`; Task 9 verifies.
- 256-bit token and mutual HMAC: Task 2, Task 5.
- Token storage and pairing: Task 6 `PairingStore`, Task 6 UI, Task 9 storage.
- Foreground service and notification: Task 6.
- File operations and path sandbox: Task 3, Task 4, Task 5.
- Rate limiting and lockout: Task 5.
- Python client: Task 8.
- Build/sign/install: Task 7, Task 9.
- Error handling and limits: Task 4, Task 5, Task 7.

### Placeholder Scan

No `TBD`, `TODO`, or unspecified implementation steps remain.

### Type Consistency

- `Hmac.fromHex` is used by `PairingStore` and tests.
- `PathGuard.resolve` throws `IOException` and `SecurityException`; `FileOps.resolve` maps both.
- `FileOps.Error.code` is used by `BridgeServer` and tests.
- `BridgeServer` constructor is `(int, byte[], File, Listener)` in tests and service.
- `Protocol.ok` takes `JSONObject`; all `FileOps` methods return `JSONObject`.
- `BridgeService.ACTION_START`/`ACTION_STOP`/`PORT` match `MainActivity` and `build.sh`.
- `localbridge_client.py` command names match the protocol operations.

### Known Build Caveat

The system `mkdir` and `find` are broken. All plan steps use Python for directory creation and source enumeration. The build script uses `cat` for the password file and shell arrays are avoided.

ECJ must compile Android sources with `-source 8 -target 8 -cp "$JSON:$ANDROID_JAR"`. Android's `org.json.JSONException` is checked while the test jar's is unchecked, so the test jar must be first on the compile classpath; it is not packaged into the APK. The test runner is `dev.aetherix.localbridge.TestMain`, not bare `TestMain`.

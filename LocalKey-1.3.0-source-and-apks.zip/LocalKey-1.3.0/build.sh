#!/bin/bash
set -euo pipefail

export JAVA_HOME=/opt/jdk-17.0.20.1+1-jre
export PATH="$JAVA_HOME/bin:$PATH"

ROOT=/root/LocalKey
SDK=/opt/android-sdk
BT="$SDK/build-tools/36.0.0"
ANDROID_JAR="$SDK/platforms/android-36/android.jar"
JAVA="$JAVA_HOME/bin/java"
KEYTOOL="$JAVA_HOME/bin/keytool"
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar
JSON="$ROOT/test-lib/json-20240303.jar"
KEYDIR=/root/.local/share/localkey
KEYSTORE="$KEYDIR/localkey.keystore"
PASSFILE="$KEYDIR/keystore.pass"
OUT="$ROOT/build"
VERSION=1.3.0
CODE=5

if [ "$#" -eq 0 ]; then
    set -- A B C
fi

python3 - <<'PY'
import glob, os, shutil
for d in ['/root/LocalKey/build/A', '/root/LocalKey/build/B', '/root/LocalKey/build/C']:
    shutil.rmtree(d, ignore_errors=True)
for p in glob.glob('/root/LocalKey/build/LocalKey-1.3.0-*.apk'):
    os.remove(p)
for p in ['/root/LocalKey/build/res.zip', '/root/LocalKey/build/LocalKey.apk']:
    if os.path.exists(p):
        os.remove(p)
PY

"$BT/aapt2" compile --dir "$ROOT/res" -o "$OUT/res.zip"

LAST_VARIANT=""
for V in "$@"; do
    LAST_VARIANT="$V"
    case "$V" in
        A|B|C) ;;
        *) echo "unknown variant: $V" >&2; exit 2 ;;
    esac
    VAROUT="$OUT/$V"
    python3 - "$VAROUT" "$ROOT/flavors/$V/Flavor.java" <<'PY'
import os, shutil, sys
out, flavor = sys.argv[1], sys.argv[2]
for sub in ['gen', 'flavor-src/dev/aetherix/localkey', 'classes', 'dex']:
    os.makedirs(os.path.join(out, sub), exist_ok=True)
shutil.copyfile(flavor, os.path.join(out, 'flavor-src/dev/aetherix/localkey/Flavor.java'))
PY

    "$BT/aapt2" link -o "$VAROUT/base.apk" -I "$ANDROID_JAR" \
        --manifest "$ROOT/AndroidManifest.xml" --java "$VAROUT/gen" \
        --version-code "$CODE" --version-name "$VERSION-$V" \
        --replace-version "$OUT/res.zip"

    SOURCES=$(python3 - "$VAROUT" <<'PY'
import glob, sys
out = sys.argv[1]
sources = glob.glob('/root/LocalKey/src/**/*.java', recursive=True)
sources += glob.glob(out + '/gen/**/R.java', recursive=True)
sources += glob.glob(out + '/flavor-src/**/*.java', recursive=True)
print(' '.join(sorted(sources)))
PY
)
    "$JAVA" -jar "$ECJ" -source 8 -target 8 -cp "$JSON:$ANDROID_JAR" \
        -d "$VAROUT/classes" $SOURCES

    python3 - "$VAROUT" <<'PY'
import os, sys, zipfile
out = sys.argv[1]
src = os.path.join(out, 'classes')
target = os.path.join(out, 'classes.jar')
with zipfile.ZipFile(target, 'w') as z:
    for root, dirs, files in os.walk(src):
        for name in files:
            path = os.path.join(root, name)
            z.write(path, os.path.relpath(path, src))
PY

    "$BT/d8" --lib "$ANDROID_JAR" --min-api 30 --output "$VAROUT/dex" "$VAROUT/classes.jar"

    python3 - "$VAROUT" <<'PY'
import sys, zipfile
base = sys.argv[1] + '/base.apk'
unsigned = sys.argv[1] + '/unsigned.apk'
import shutil
shutil.copyfile(base, unsigned)
with zipfile.ZipFile(unsigned, 'a') as z:
    z.write(sys.argv[1] + '/dex/classes.dex', 'classes.dex')
PY

    "$BT/zipalign" -f 4 "$VAROUT/unsigned.apk" "$VAROUT/aligned.apk"

    python3 - <<'PY'
import os, secrets, pathlib
keydir = pathlib.Path('/root/.local/share/localkey')
keydir.mkdir(parents=True, exist_ok=True)
passfile = keydir / 'keystore.pass'
if not passfile.exists():
    passfile.write_text(secrets.token_hex(24))
    os.chmod(passfile, 0o600)
PY

    PASS=$(<"$PASSFILE")
    if [ ! -f "$KEYSTORE" ]; then
        "$KEYTOOL" -genkeypair -keystore "$KEYSTORE" -alias localkey \
            -keyalg RSA -keysize 2048 -validity 10000 \
            -storepass "$PASS" -keypass "$PASS" \
            -dname "CN=LocalKey" -noprompt
    fi

    APK="$OUT/LocalKey-$VERSION-$V.apk"
    "$BT/apksigner" sign --ks "$KEYSTORE" --ks-key-alias localkey \
        --ks-pass "pass:$PASS" --key-pass "pass:$PASS" \
        --out "$APK" "$VAROUT/aligned.apk"
    "$BT/apksigner" verify --print-certs "$APK"
    "$BT/aapt2" dump badging "$APK" | python3 -c 'import sys; [print(line.rstrip()) for _, line in zip(range(12), sys.stdin)]'
    python3 - "$APK" "$V" <<'PY'
import hashlib, os, sys
path, variant = sys.argv[1], sys.argv[2]
data = open(path, 'rb').read()
print('VARIANT', variant, 'APK', path, len(data), 'bytes')
print('VARIANT', variant, 'SHA256', hashlib.sha256(data).hexdigest())
PY
done

python3 - "$OUT" "$VERSION" "$LAST_VARIANT" <<'PY'
import shutil, sys
from pathlib import Path
out = Path(sys.argv[1])
version = sys.argv[2]
last = sys.argv[3]
source = out / ('LocalKey-%s-C.apk' % version)
if not source.exists():
    source = out / ('LocalKey-%s-%s.apk' % (version, last))
if source.exists():
    shutil.copyfile(source, out / 'LocalKey.apk')
PY

#!/usr/bin/env python3
"""LocalKey client: pairing plus AES-256-GCM encrypted loopback RPC."""

import argparse
import base64
import hashlib
import http.client
import json
import os
import secrets
import socket
import sys
import time
import uuid
from pathlib import Path
from urllib.parse import parse_qs, urlparse

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:  # pragma: no cover
    sys.exit("LocalKey client requires the Python 'cryptography' package")

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 39401
CHUNK = 1024 * 1024
CREDENTIALS = Path.home() / ".config" / "localkey" / "credentials.json"


class RemoteError(Exception):
    def __init__(self, code, message, status=0):
        super().__init__("%s: %s" % (code, message))
        self.code = code
        self.message = message
        self.status = status


def b64e(value):
    return base64.urlsafe_b64encode(value).decode().rstrip("=")


def b64d(value):
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def sha256(value):
    return hashlib.sha256(value).digest()


def sanitize_name(value):
    out = "".join(ch for ch in value if 0x20 <= ord(ch) <= 0x7E)
    return out[:64] or "client"


def parse_link(link):
    parsed = urlparse(link)
    if parsed.scheme != "localkey" or parsed.netloc != "pair":
        raise RemoteError("bad_link", "not a LocalKey pairing link")
    query = {key: values[-1] for key, values in parse_qs(parsed.query).items()}
    if query.get("v") != "1":
        raise RemoteError("bad_link", "unsupported pairing link version")
    if query.get("scope") != "loopback":
        raise RemoteError("bad_link", "pairing link is not loopback scoped")
    host = query.get("host", "")
    if host not in ("127.0.0.1", "localhost"):
        raise RemoteError("bad_link", "pairing link host is not loopback")
    try:
        port = int(query.get("port", ""))
    except ValueError:
        raise RemoteError("bad_link", "invalid port")
    if port < 1 or port > 65535:
        raise RemoteError("bad_link", "invalid port")
    token = query.get("tok", "")
    if len(token) < 20 or len(token) > 128:
        raise RemoteError("bad_link", "invalid pairing token")
    try:
        expires = int(query.get("exp", ""))
    except ValueError:
        raise RemoteError("bad_link", "invalid expiry")
    if expires + 5000 < int(time.time() * 1000):
        raise RemoteError("link_expired", "pairing link expired")
    return {
        "host": host,
        "port": port,
        "token": token,
        "expires": expires,
        "server_id": query.get("id", ""),
        "server_name": query.get("name", ""),
        "fingerprint": query.get("fp", ""),
    }


def http_post(host, port, path, body, content_type):
    connection = http.client.HTTPConnection(host, port, timeout=30)
    try:
        connection.request("POST", path, body=body, headers={"Content-Type": content_type})
        response = connection.getresponse()
        data = response.read()
        try:
            parsed = json.loads(data.decode())
        except (ValueError, UnicodeDecodeError):
            parsed = None
        return response.status, parsed
    finally:
        connection.close()


def fetch_health(host, port):
    connection = http.client.HTTPConnection(host, port, timeout=15)
    try:
        connection.request("GET", "/health")
        response = connection.getresponse()
        data = response.read()
        try:
            parsed = json.loads(data.decode())
        except (ValueError, UnicodeDecodeError):
            parsed = None
        if response.status != 200 or not parsed:
            raise RemoteError("health_failed", "health check failed", response.status)
        return parsed
    finally:
        connection.close()


def pair(link, credentials_path, client_name=None):
    info = parse_link(link)
    client_id = secrets.token_hex(16)
    name = sanitize_name(client_name or socket.gethostname())
    request = {
        "v": 1,
        "token": info["token"],
        "client": {"id": client_id, "name": name},
    }
    status, response = http_post(
        info["host"], info["port"], "/pair",
        json.dumps(request, separators=(",", ":")).encode(),
        "application/json",
    )
    if response is None:
        raise RemoteError("pairing_failed", "invalid server response", status)
    if status != 200 or not response.get("ok"):
        raise RemoteError(response.get("error", "pairing_failed"),
                          response.get("message", "pairing failed"), status)
    if response.get("clientId") != client_id:
        raise RemoteError("pairing_failed", "client id mismatch", status)

    pairing_key = sha256(info["token"].encode())
    try:
        blob = b64d(response["key"])
    except (KeyError, ValueError, TypeError):
        raise RemoteError("pairing_failed", "invalid wrapped key", status)
    if len(blob) < 12 + 16:
        raise RemoteError("pairing_failed", "invalid wrapped key", status)
    aad = ("LOCALKEY/PAIR/1|" + client_id).encode()
    try:
        key = AESGCM(pairing_key).decrypt(blob[:12], blob[12:], aad)
    except Exception:
        raise RemoteError("pairing_failed", "could not decrypt pairing response", status)
    if len(key) != 32:
        raise RemoteError("pairing_failed", "invalid key length", status)

    credentials = {
        "v": 1,
        "host": info["host"],
        "port": info["port"],
        "clientId": client_id,
        "clientName": name,
        "key": b64e(key),
        "fingerprint": response.get("fingerprint", ""),
        "pairedAt": int(time.time() * 1000),
    }
    save_credentials(credentials_path, credentials)
    return credentials


def save_credentials(path, credentials):
    path = Path(path)
    parent = path.parent
    if not parent.exists():
        parent.mkdir(parents=True, exist_ok=True)
        os.chmod(parent, 0o700)
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        fd = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(json.dumps(credentials, indent=2) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
        os.chmod(path, 0o600)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_credentials(path):
    path = Path(path)
    if not path.exists():
        raise RemoteError("no_credentials", "pair first or use --key")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise RemoteError("bad_credentials", "cannot read credentials: %s" % error)
    if not isinstance(data, dict):
        raise RemoteError("bad_credentials", "credentials must be an object")
    try:
        key = b64d(data["key"])
    except (KeyError, ValueError, TypeError):
        raise RemoteError("bad_credentials", "invalid client key")
    if len(key) != 32:
        raise RemoteError("bad_credentials", "invalid client key")
    client_id = data.get("clientId")
    if client_id is not None and (not isinstance(client_id, str)
                                  or not 16 <= len(client_id) <= 64):
        raise RemoteError("bad_credentials", "invalid client id")
    data["_key"] = key
    return data


class Client:
    def __init__(self, host, port, key, client_id=None):
        self.host = host
        self.port = port
        self.key = key
        self.client_id = client_id
        self.aad = (b"LOCALKEY/1|client:" + client_id.encode()) if client_id else b"LOCALKEY/1"

    @classmethod
    def from_credentials(cls, credentials):
        return cls(credentials.get("host", DEFAULT_HOST),
                   int(credentials.get("port", DEFAULT_PORT)),
                   credentials["_key"], credentials.get("clientId"))

    @classmethod
    def legacy(cls, host, port, key):
        return cls(host, port, key, None)

    def health(self):
        return fetch_health(self.host, self.port)

    def rpc(self, op, **fields):
        request_id = uuid.uuid4().hex
        request = {
            "v": 1,
            "id": request_id,
            "ts": int(time.time() * 1000),
            "op": op,
        }
        request.update(fields)
        nonce = os.urandom(12)
        plaintext = json.dumps(request, separators=(",", ":")).encode()
        ciphertext = AESGCM(self.key).encrypt(nonce, plaintext, self.aad)
        body = nonce + ciphertext
        headers = {"Content-Type": "application/octet-stream"}
        if self.client_id:
            headers["X-Localkey-Client"] = self.client_id
        connection = http.client.HTTPConnection(self.host, self.port, timeout=60)
        try:
            connection.request("POST", "/rpc", body=body, headers=headers)
            response = connection.getresponse()
            data = response.read()
            if response.status != 200:
                raise RemoteError("unauthorized", "server rejected request", response.status)
            if len(data) < 12 + 16:
                raise RemoteError("bad_response", "truncated response")
            try:
                plain = AESGCM(self.key).decrypt(data[:12], data[12:], self.aad)
                result = json.loads(plain.decode())
            except Exception:
                raise RemoteError("bad_response", "could not decrypt response")
            if not isinstance(result, dict):
                raise RemoteError("bad_response", "invalid response object")
            if result.get("id") != request_id:
                raise RemoteError("bad_response", "response id mismatch")
            if not result.get("ok"):
                raise RemoteError(result.get("code", "error"),
                                  result.get("error", "request failed"))
            return result.get("result", {})
        finally:
            connection.close()


def cmd_pair(args):
    link = args.link or os.environ.get("LOCALKEY_LINK")
    if not link:
        raise RemoteError("no_link", "pass --link or set LOCALKEY_LINK")
    credentials = pair(link, args.credentials, args.name)
    print(json.dumps({
        "ok": True,
        "clientId": credentials["clientId"],
        "clientName": credentials["clientName"],
        "host": credentials["host"],
        "port": credentials["port"],
        "fingerprint": credentials["fingerprint"],
        "credentials": str(args.credentials),
    }, indent=2))


def client_from_args(args):
    if args.key or os.environ.get("LOCALKEY_KEY"):
        key = b64d(args.key or os.environ["LOCALKEY_KEY"])
        if len(key) != 32:
            raise RemoteError("bad_key", "legacy key must be 32 bytes")
        return Client.legacy(args.host or DEFAULT_HOST,
                             args.port or DEFAULT_PORT, key)
    credentials = load_credentials(args.credentials)
    host = args.host or credentials.get("host", DEFAULT_HOST)
    port = int(args.port or credentials.get("port", DEFAULT_PORT))
    return Client(host, port, credentials["_key"], credentials.get("clientId"))


def cmd_health(args):
    print(json.dumps(fetch_health(args.host or DEFAULT_HOST,
                                  args.port or DEFAULT_PORT), indent=2))


def cmd_ping(client, args):
    print(json.dumps(client.rpc("ping"), indent=2))


def cmd_info(client, args):
    print(json.dumps(client.rpc("info"), indent=2))


def cmd_ls(client, args):
    result = client.rpc("list", path=args.path, limit=args.limit)
    for entry in result.get("entries", []):
        print("%s\t%s\t%s" % (entry.get("type", "?"), entry.get("size", 0),
                              entry.get("path") or entry.get("name", "")))
    if result.get("truncated"):
        print("(truncated)", file=sys.stderr)


def cmd_stat(client, args):
    print(json.dumps(client.rpc("stat", path=args.path), indent=2))


def cmd_get(client, args):
    info = client.rpc("stat", path=args.remote)
    if info.get("type") != "file":
        raise RemoteError("bad_request", "remote path is not a file")
    size = int(info.get("size", 0))
    target = Path(args.local)
    target.parent.mkdir(parents=True, exist_ok=True)
    offset = 0
    with target.open("wb") as out:
        while offset < size:
            result = client.rpc("read", path=args.remote, offset=offset, length=CHUNK)
            data = base64.b64decode(result["data"])
            out.write(data)
            offset += len(data)
            if not data or result.get("eof"):
                break
    print("%s bytes -> %s" % (target.stat().st_size, target))


def cmd_put(client, args):
    source = Path(args.local)
    size = source.stat().st_size
    if size == 0:
        client.rpc("write", path=args.remote, offset=0, data="", truncate=True)
        print("0 bytes -> %s" % args.remote)
        return
    offset = 0
    with source.open("rb") as stream:
        while True:
            data = stream.read(CHUNK)
            if not data:
                break
            client.rpc("write", path=args.remote, offset=offset,
                       data=base64.b64encode(data).decode(), truncate=offset == 0)
            offset += len(data)
    print("%s bytes -> %s" % (offset, args.remote))


def cmd_mkdir(client, args):
    print(json.dumps(client.rpc("mkdir", path=args.path, parents=args.parents), indent=2))


def cmd_rm(client, args):
    print(json.dumps(client.rpc("delete", path=args.path, recursive=args.recursive), indent=2))


def cmd_mv(client, args):
    print(json.dumps(client.rpc("move", path=args.source, to=args.target), indent=2))


def cmd_cp(client, args):
    print(json.dumps(client.rpc("copy", path=args.source, to=args.target), indent=2))


def cmd_find(client, args):
    result = client.rpc("search", path=args.path, query=args.query,
                        maxDepth=args.max_depth, limit=args.limit)
    for entry in result.get("entries", []):
        print("%s\t%s\t%s" % (entry.get("type", "?"), entry.get("size", 0),
                              entry.get("path") or entry.get("name", "")))
    if result.get("truncated"):
        print("(truncated)", file=sys.stderr)


def cmd_hash(client, args):
    print(json.dumps(client.rpc("hash", path=args.path), indent=2))


def cmd_logs(client, args):
    print(json.dumps(client.rpc("logs", limit=args.limit), indent=2))


def main(argv=None):
    parser = argparse.ArgumentParser(description="LocalKey encrypted loopback client")
    parser.add_argument("--host", default=None)
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--credentials", type=Path, default=CREDENTIALS)
    parser.add_argument("--key", help="legacy base64url key (no client header)")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("pair", help="pair using a localkey:// link")
    p.add_argument("--link")
    p.add_argument("--name")
    p.set_defaults(func=cmd_pair, needs_client=False)

    p = sub.add_parser("health")
    p.set_defaults(func=cmd_health, needs_client=False)

    p = sub.add_parser("ping")
    p.set_defaults(func=cmd_ping)

    p = sub.add_parser("info")
    p.set_defaults(func=cmd_info)

    p = sub.add_parser("ls")
    p.add_argument("path", nargs="?", default=".")
    p.add_argument("--limit", type=int, default=1000)
    p.set_defaults(func=cmd_ls)

    p = sub.add_parser("stat")
    p.add_argument("path")
    p.set_defaults(func=cmd_stat)

    p = sub.add_parser("get")
    p.add_argument("remote")
    p.add_argument("local")
    p.set_defaults(func=cmd_get)

    p = sub.add_parser("put")
    p.add_argument("local")
    p.add_argument("remote")
    p.set_defaults(func=cmd_put)

    p = sub.add_parser("mkdir")
    p.add_argument("path")
    p.add_argument("--parents", action="store_true")
    p.set_defaults(func=cmd_mkdir)

    p = sub.add_parser("rm")
    p.add_argument("path")
    p.add_argument("--recursive", action="store_true")
    p.set_defaults(func=cmd_rm)

    p = sub.add_parser("mv")
    p.add_argument("source")
    p.add_argument("target")
    p.set_defaults(func=cmd_mv)

    p = sub.add_parser("cp")
    p.add_argument("source")
    p.add_argument("target")
    p.set_defaults(func=cmd_cp)

    p = sub.add_parser("find")
    p.add_argument("path")
    p.add_argument("query")
    p.add_argument("--max-depth", type=int, default=8)
    p.add_argument("--limit", type=int, default=200)
    p.set_defaults(func=cmd_find)

    p = sub.add_parser("hash")
    p.add_argument("path")
    p.set_defaults(func=cmd_hash)

    p = sub.add_parser("logs")
    p.add_argument("--limit", type=int, default=100)
    p.set_defaults(func=cmd_logs)

    args = parser.parse_args(argv)
    try:
        if args.command == "pair":
            cmd_pair(args)
            return 0
        if args.command == "health":
            cmd_health(args)
            return 0
        client = client_from_args(args)
        args.func(client, args)
        return 0
    except RemoteError as error:
        print("localkey: %s" % error, file=sys.stderr)
        return 1
    except (OSError, ValueError, KeyError, TypeError, http.client.HTTPException) as error:
        print("localkey: %s" % error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())

import base64
import hashlib
import json
import os
import secrets
import sys
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

sys.path.insert(0, str(Path(__file__).resolve().parent))
import localkey_client as lk


def b64e(value):
    return base64.urlsafe_b64encode(value).decode().rstrip("=")


class MockServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self):
        super().__init__(("127.0.0.1", 0), MockHandler)
        self.token = b64e(os.urandom(32))
        self.legacy_key = os.urandom(32)
        self.clients = {}
        self.seen = set()


class MockHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, status, obj):
        data = json.dumps(obj, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path != "/health":
            self._send(404, {"ok": False, "error": "not_found"})
            return
        self._send(200, {"ok": True, "app": "localkey", "v": 1, "port": self.server.server_port})

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)
        if self.path == "/pair":
            self._pair(body)
        elif self.path == "/rpc":
            self._rpc(body)
        else:
            self._send(404, {"ok": False, "error": "not_found"})

    def _pair(self, body):
        request = json.loads(body)
        if request.get("token") != self.server.token:
            self._send(401, {"ok": False, "error": "pairing_denied"})
            return
        client = request["client"]
        client_id = client["id"]
        key = os.urandom(32)
        self.server.clients[client_id] = key
        pairing_key = hashlib.sha256(self.server.token.encode()).digest()
        nonce = os.urandom(12)
        aad = ("LOCALKEY/PAIR/1|" + client_id).encode()
        wrapped = nonce + AESGCM(pairing_key).encrypt(nonce, key, aad)
        self._send(200, {
            "v": 1,
            "ok": True,
            "clientId": client_id,
            "clientName": client["name"],
            "key": b64e(wrapped),
            "fingerprint": "0123456789abcdef",
            "serverTime": int(time.time() * 1000),
        })

    def _rpc(self, body):
        client_id = self.headers.get("X-Localkey-Client")
        if client_id:
            key = self.server.clients.get(client_id)
            aad = ("LOCALKEY/1|client:" + client_id).encode()
        else:
            key = self.server.legacy_key
            aad = b"LOCALKEY/1"
        if key is None or len(body) < 28:
            self._send(401, {"ok": False, "error": "unauthorized"})
            return
        try:
            plain = AESGCM(key).decrypt(body[:12], body[12:], aad)
            request = json.loads(plain)
        except Exception:
            self._send(401, {"ok": False, "error": "unauthorized"})
            return
        request_id = request.get("id")
        if request_id in self.server.seen:
            self._send(200, {"ok": False, "id": request_id, "code": "replay"})
            return
        self.server.seen.add(request_id)
        result = {"time": int(time.time() * 1000)}
        if request.get("op") == "list":
            result = {"entries": [{"name": "hello.txt", "path": "hello.txt",
                                   "type": "file", "size": 3, "mtime": 0}],
                      "truncated": False, "count": 1}
        response = {"v": 1, "ok": True, "id": request_id,
                    "serverTime": int(time.time() * 1000), "result": result}
        nonce = os.urandom(12)
        encrypted = nonce + AESGCM(key).encrypt(nonce, json.dumps(response).encode(), aad)
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(encrypted)))
        self.end_headers()
        self.wfile.write(encrypted)


def link_for(server, token=None, host="127.0.0.1", expires=None):
    token = token or server.token
    expires = expires if expires is not None else int(time.time() * 1000) + 120000
    return ("localkey://pair?v=1&scope=loopback&host=%s&port=%d&id=%s"
            "&name=test-phone&fp=0123456789abcdef&tok=%s&exp=%d"
            % (host, server.server_port, "a" * 32, token, expires))


class ClientTests(unittest.TestCase):
    def setUp(self):
        self.server = MockServer()
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.temp = tempfile.TemporaryDirectory()
        self.credentials = Path(self.temp.name) / "credentials.json"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.temp.cleanup()

    def test_pair_and_rpc(self):
        result = lk.pair(link_for(self.server), self.credentials, "test-client")
        self.assertEqual(result["clientId"], list(self.server.clients)[0])
        self.assertEqual(self.credentials.stat().st_mode & 0o777, 0o600)
        client = lk.Client.from_credentials(lk.load_credentials(self.credentials))
        self.assertIn("time", client.rpc("ping"))
        listing = client.rpc("list", path=".", limit=10)
        self.assertEqual(listing["entries"][0]["name"], "hello.txt")

    def test_health(self):
        self.assertTrue(lk.Client("127.0.0.1", self.server.server_port, b"\0" * 32).health()["ok"])

    def test_wrong_token_fails(self):
        with self.assertRaises(lk.RemoteError):
            lk.pair(link_for(self.server, token=b64e(os.urandom(32))), self.credentials)

    def test_legacy_and_client_key_separation(self):
        legacy = lk.Client.legacy("127.0.0.1", self.server.server_port, self.server.legacy_key)
        self.assertIn("time", legacy.rpc("ping"))
        result = lk.pair(link_for(self.server), self.credentials, "test-client")
        paired = lk.Client.from_credentials(lk.load_credentials(self.credentials))
        self.assertIn("time", paired.rpc("ping"))
        wrong = lk.Client.legacy("127.0.0.1", self.server.server_port, paired.key)
        with self.assertRaises(lk.RemoteError):
            wrong.rpc("ping")
        self.assertNotEqual(result["clientId"], "")

    def test_credentials_permissions_and_bad_file(self):
        shared = Path(self.temp.name) / "shared"
        shared.mkdir()
        os.chmod(shared, 0o755)
        path = shared / "credentials.json"
        lk.save_credentials(path, {
            "v": 1, "host": "127.0.0.1", "port": self.server.server_port,
            "clientId": "a" * 32, "key": b64e(os.urandom(32)),
        })
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        self.assertEqual(shared.stat().st_mode & 0o777, 0o755)
        path.write_text("{broken")
        with self.assertRaises(lk.RemoteError):
            lk.load_credentials(path)

    def test_parse_link_validation(self):
        good = lk.parse_link(link_for(self.server))
        self.assertEqual(good["port"], self.server.server_port)
        with self.assertRaises(lk.RemoteError):
            lk.parse_link(link_for(self.server, host="192.168.1.10"))
        with self.assertRaises(lk.RemoteError):
            lk.parse_link(link_for(self.server, expires=int(time.time() * 1000) - 60000))
        with self.assertRaises(lk.RemoteError):
            lk.parse_link("https://example.com/pair")


if __name__ == "__main__":
    unittest.main()

import base64
import os
import subprocess
import sys
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def b64e(value):
    return base64.urlsafe_b64encode(value).decode().rstrip("=")


def b64d(value):
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: test_cross_language.py <test-classes-dir>")
    classpath = sys.argv[1]
    java = "/opt/jdk-17.0.20.1+1-jre/bin/java"
    key = os.urandom(32)
    aad = b"LOCALKEY/1"
    plaintext = b'{"v":1,"id":"cross","ts":1,"op":"ping"}'

    encrypted = subprocess.run(
        [java, "-cp", classpath, "CryptoFixture", "encrypt", b64e(key), b64e(aad), b64e(plaintext)],
        check=True, capture_output=True, text=True,
    ).stdout.strip()
    blob = b64d(encrypted)
    assert len(blob) >= 28
    assert AESGCM(key).decrypt(blob[:12], blob[12:], aad) == plaintext

    nonce = os.urandom(12)
    python_blob = nonce + AESGCM(key).encrypt(nonce, plaintext, aad)
    decrypted = subprocess.run(
        [java, "-cp", classpath, "CryptoFixture", "decrypt", b64e(key), b64e(aad), b64e(python_blob)],
        check=True, capture_output=True, text=True,
    ).stdout.strip()
    assert b64d(decrypted) == plaintext
    print("OK cross-language crypto")


if __name__ == "__main__":
    main()

package dev.aetherix.localkey;

public final class Flavor {
    public static final String VARIANT = "B";
    public static final String DEFAULT_LAYOUT = "drawer";
    public static final boolean LAYOUT_SWITCH = false;

    private Flavor() {
    }
}

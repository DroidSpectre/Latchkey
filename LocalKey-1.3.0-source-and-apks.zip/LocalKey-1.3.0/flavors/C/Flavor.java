package dev.aetherix.localkey;

public final class Flavor {
    public static final String VARIANT = "C";
    public static final String DEFAULT_LAYOUT = "tabs";
    public static final boolean LAYOUT_SWITCH = true;

    private Flavor() {
    }
}

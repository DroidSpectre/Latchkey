package dev.aetherix.localkey;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

public final class AppInfo {
    public final String versionName;
    public final long versionCode;
    public final long firstInstallTime;
    public final long lastUpdateTime;
    public final String manufacturer;
    public final String model;
    public final String android;
    public final int sdk;

    private AppInfo(String versionName, long versionCode, long firstInstallTime, long lastUpdateTime,
                    String manufacturer, String model, String android, int sdk) {
        this.versionName = versionName;
        this.versionCode = versionCode;
        this.firstInstallTime = firstInstallTime;
        this.lastUpdateTime = lastUpdateTime;
        this.manufacturer = manufacturer;
        this.model = model;
        this.android = android;
        this.sdk = sdk;
    }

    public static AppInfo read(Context context) {
        String versionName = "unknown";
        long versionCode = 0L;
        long firstInstallTime = 0L;
        long lastUpdateTime = 0L;
        try {
            PackageInfo info = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            if (info.versionName != null && !info.versionName.isEmpty()) {
                versionName = info.versionName;
            }
            versionCode = info.getLongVersionCode();
            firstInstallTime = info.firstInstallTime;
            lastUpdateTime = info.lastUpdateTime;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        return new AppInfo(versionName, versionCode, firstInstallTime, lastUpdateTime,
                Build.MANUFACTURER == null ? "" : Build.MANUFACTURER,
                Build.MODEL == null ? "" : Build.MODEL,
                Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE,
                Build.VERSION.SDK_INT);
    }

    public String label() {
        return "v" + versionName + " (" + versionCode + ")";
    }
}

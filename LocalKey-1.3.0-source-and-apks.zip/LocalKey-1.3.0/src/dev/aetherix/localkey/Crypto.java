package dev.aetherix.localkey;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class Crypto {
    public static final int KEY_BYTES = 32;
    public static final int NONCE_BYTES = 12;
    public static final int TAG_BITS = 128;

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final char[] HEX = "0123456789abcdef".toCharArray();

    private Crypto() {
    }

    public static byte[] random(int length) {
        byte[] value = new byte[length];
        RANDOM.nextBytes(value);
        return value;
    }

    public static String b64(byte[] value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value);
    }

    public static byte[] unb64(String value) {
        return Base64.getUrlDecoder().decode(value);
    }

    public static String hex(byte[] value) {
        char[] out = new char[value.length * 2];
        for (int i = 0; i < value.length; i++) {
            int b = value[i] & 0xff;
            out[i * 2] = HEX[b >>> 4];
            out[i * 2 + 1] = HEX[b & 0x0f];
        }
        return new String(out);
    }

    public static byte[] sha256(byte[] value) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(value);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    public static byte[] sha256(String value) {
        return sha256(value.getBytes(StandardCharsets.UTF_8));
    }

    public static String fingerprint(byte[] key) {
        return hex(Arrays.copyOf(sha256(key), 8));
    }

    public static boolean constantTimeEquals(byte[] left, byte[] right) {
        return left != null && right != null && MessageDigest.isEqual(left, right);
    }

    public static byte[] encrypt(byte[] key, byte[] aad, byte[] plaintext)
            throws GeneralSecurityException {
        return encrypt(new SecretKeySpec(key, "AES"), aad, plaintext);
    }

    public static byte[] encrypt(SecretKey key, byte[] aad, byte[] plaintext)
            throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        if (aad != null) cipher.updateAAD(aad);
        byte[] ciphertext = cipher.doFinal(plaintext);
        byte[] nonce = cipher.getIV();
        if (nonce == null || nonce.length != NONCE_BYTES) {
            throw new GeneralSecurityException("unexpected GCM nonce");
        }
        byte[] out = new byte[nonce.length + ciphertext.length];
        System.arraycopy(nonce, 0, out, 0, nonce.length);
        System.arraycopy(ciphertext, 0, out, nonce.length, ciphertext.length);
        return out;
    }

    public static byte[] decrypt(byte[] key, byte[] aad, byte[] blob)
            throws GeneralSecurityException {
        return decrypt(new SecretKeySpec(key, "AES"), aad, blob);
    }

    public static byte[] decrypt(SecretKey key, byte[] aad, byte[] blob)
            throws GeneralSecurityException {
        if (blob == null || blob.length < NONCE_BYTES + TAG_BITS / 8) {
            throw new GeneralSecurityException("ciphertext too short");
        }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, blob, 0, NONCE_BYTES));
        if (aad != null) cipher.updateAAD(aad);
        return cipher.doFinal(blob, NONCE_BYTES, blob.length - NONCE_BYTES);
    }

    public static void zero(byte[] value) {
        if (value != null) Arrays.fill(value, (byte) 0);
    }
}

package dev.aetherix.localkey;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public final class EventLog {
    public static final int SCHEMA = 1;
    private static final int RING_SIZE = 1000;
    private static final long MAX_BYTES = 512L * 1024L;
    private static final String PREFS = "localkey-audit";
    private static final String LAST_CODE = "last_version_code";
    private static final String LAST_NAME = "last_version_name";
    private static final String LAST_UPDATE = "last_update_time";

    private static EventLog instance;
    private final Object lock = new Object();
    private final File file;
    private final File backup;
    private final ArrayDeque<String> ring = new ArrayDeque<>();
    private final AtomicLong sequence = new AtomicLong();
    private final AppInfo app;
    private final String session;
    private long maxSequence;

    private EventLog(Context context) {
        File dir = new File(context.getFilesDir(), "logs");
        if (!dir.exists() && !dir.mkdirs()) {
            // Keep logging in memory if the private directory cannot be prepared.
        }
        file = new File(dir, "events.jsonl");
        backup = new File(dir, "events.1.jsonl");
        loadHistory(backup);
        loadHistory(file);
        sequence.set(maxSequence);
        app = AppInfo.read(context);
        session = UUID.randomUUID().toString();
        logStart(context);
    }

    public static synchronized EventLog get(Context context) {
        if (instance == null) instance = new EventLog(context);
        return instance;
    }

    public void info(String category, String message) {
        JSONObject fields = Json.obj();
        Json.put(fields, "category", text(category));
        Json.put(fields, "message", text(message));
        write("info", fields);
    }

    public void error(String category, String message) {
        JSONObject fields = Json.obj();
        Json.put(fields, "category", text(category));
        Json.put(fields, "message", text(message));
        write("error", fields);
    }

    public void warn(String category, String message) {
        JSONObject fields = Json.obj();
        Json.put(fields, "category", text(category));
        Json.put(fields, "message", text(message));
        write("warn", fields);
    }

    public void event(String type, JSONObject fields) {
        write(type, fields);
    }

    public String versionName() {
        return app.versionName;
    }

    public long versionCode() {
        return app.versionCode;
    }

    public String sessionId() {
        return session;
    }

    public int size() {
        synchronized (lock) {
            return ring.size();
        }
    }

    public String text(int limit) {
        synchronized (lock) {
            StringBuilder out = new StringBuilder();
            Iterator<String> it = ring.descendingIterator();
            while (it.hasNext()) {
                String line = it.next();
                out.append(line).append('\n');
            }
            String value = out.toString();
            return value.length() <= limit ? value : value.substring(value.length() - limit);
        }
    }

    public JSONArray tail(int limit) {
        JSONArray result = new JSONArray();
        synchronized (lock) {
            if (limit <= 0) return result;
            int count = Math.min(limit, ring.size());
            List<String> lines = new ArrayList<>(ring);
            Collections.reverse(lines);
            int start = Math.max(0, lines.size() - count);
            for (int i = start; i < lines.size(); i++) {
                try {
                    result.put(new JSONObject(lines.get(i)));
                } catch (JSONException ignored) {
                }
            }
        }
        return result;
    }

    public int export(File target) throws IOException {
        synchronized (lock) {
            List<EventLine> entries = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            readEvents(backup, entries, seen);
            readEvents(file, entries, seen);
            Collections.sort(entries, new Comparator<EventLine>() {
                @Override
                public int compare(EventLine a, EventLine b) {
                    if (a.ts != b.ts) return a.ts < b.ts ? -1 : 1;
                    if (a.seq != b.seq) return a.seq < b.seq ? -1 : 1;
                    return a.line.compareTo(b.line);
                }
            });
            File parent = target.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new IOException("cannot create export directory");
            }
            try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(target), StandardCharsets.UTF_8))) {
                for (EventLine entry : entries) {
                    out.write(entry.line);
                    out.write('\n');
                }
            }
            return entries.size();
        }
    }

    public void clear() {
        synchronized (lock) {
            file.delete();
            backup.delete();
            ring.clear();
        }
    }

    private static void readEvents(File source, List<EventLine> entries, Set<String> seen) {
        if (source == null || !source.isFile()) return;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(source), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty() || !seen.add(line)) continue;
                try {
                    JSONObject entry = new JSONObject(line);
                    entries.add(new EventLine(line, entry.optLong("ts", 0L), entry.optLong("seq", 0L)));
                } catch (JSONException ignored) {
                    // Ignore incomplete or corrupt lines, but keep the rest of the export.
                }
            }
        } catch (IOException ignored) {
        }
    }

    private void logStart(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long storedCode = prefs.getLong(LAST_CODE, -1L);
        long storedUpdate = prefs.getLong(LAST_UPDATE, -1L);
        String storedName = prefs.getString(LAST_NAME, null);
        boolean first = storedCode < 0L;
        boolean nameChanged = storedName == null
                ? !"unknown".equals(app.versionName)
                : !storedName.equals(app.versionName);
        boolean changed = !first && (storedCode != app.versionCode
                || storedUpdate != app.lastUpdateTime || nameChanged);
        boolean updated = changed
                || (first && app.lastUpdateTime > app.firstInstallTime + 60000L);
        JSONObject fields = Json.obj();
        Json.put(fields, "firstStart", first);
        Json.put(fields, "app", "localkey");
        Json.put(fields, "sdk", app.sdk);
        Json.put(fields, "android", app.android);
        Json.put(fields, "manufacturer", app.manufacturer);
        Json.put(fields, "model", app.model);
        Json.put(fields, "firstInstallTime", app.firstInstallTime);
        Json.put(fields, "lastUpdateTime", app.lastUpdateTime);
        if (!first) {
            Json.put(fields, "previousVersionCode", storedCode);
            if (storedName != null) Json.put(fields, "previousVersionName", storedName);
            if (storedUpdate >= 0L) Json.put(fields, "previousLastUpdateTime", storedUpdate);
        }
        write(updated ? "app_updated" : "app_started", fields);
        prefs.edit()
                .putLong(LAST_CODE, app.versionCode)
                .putString(LAST_NAME, app.versionName)
                .putLong(LAST_UPDATE, app.lastUpdateTime)
                .apply();
    }

    private void loadHistory(File source) {
        if (!source.isFile()) return;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(source), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) continue;
                try {
                    JSONObject entry = new JSONObject(line);
                    long seq = entry.optLong("seq", 0L);
                    if (seq > maxSequence) maxSequence = seq;
                } catch (JSONException ignored) {
                    // Keep serving even if an old line is malformed.
                }
                ring.addFirst(line);
                if (ring.size() > RING_SIZE) ring.removeLast();
            }
        } catch (IOException ignored) {
        }
    }

    private void write(String type, JSONObject fields) {
        synchronized (lock) {
            try {
                if (file.length() > MAX_BYTES) {
                    if (file.exists()) {
                        Files.copy(file.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    }
                    file.delete();
                }
                JSONObject entry = new JSONObject();
                Iterator<String> keys = fields.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    try {
                        entry.put(key, fields.opt(key));
                    } catch (JSONException ignored) {
                    }
                }
                Json.put(entry, "ts", System.currentTimeMillis());
                Json.put(entry, "seq", sequence.incrementAndGet());
                Json.put(entry, "type", text(type, 32));
                Json.put(entry, "schema", SCHEMA);
                Json.put(entry, "session", session);
                Json.put(entry, "monoMs", SystemClock.elapsedRealtime());
                Json.put(entry, "appVersion", app.versionName);
                Json.put(entry, "appCode", app.versionCode);
                String line = entry.toString() + "\n";
                try (FileOutputStream out = new FileOutputStream(file, true)) {
                    out.write(line.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    out.getFD().sync();
                }
                ring.addFirst(line.trim());
                if (ring.size() > RING_SIZE) ring.removeLast();
            } catch (Exception ignored) {
                // Logging must never affect the bridge.
            }
        }
    }

    private static String text(String value, int limit) {
        if (value == null) return "";
        String clean = value.replace('\r', ' ').replace('\n', ' ').trim();
        return clean.length() <= limit ? clean : clean.substring(0, limit);
    }

    private static String text(String value) {
        return text(value, 200);
    }

    private static final class EventLine {
        final String line;
        final long ts;
        final long seq;

        EventLine(String line, long ts, long seq) {
            this.line = line;
            this.ts = ts;
            this.seq = seq;
        }
    }
}

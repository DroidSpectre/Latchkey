package dev.aetherix.localkey;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class FileApi {
    public static final int MAX_CHUNK = 1024 * 1024;
    private static final int MAX_LIST = 5000;
    private static final int MAX_LIST_BYTES = 800 * 1024;
    private static final int MAX_SEARCH = 500;
    private static final int MAX_SEARCH_DEPTH = 32;
    private static final long SEARCH_BUDGET_MS = 15000;

    public static final class Error extends Exception {
        private static final long serialVersionUID = 1L;
        public final String code;

        public Error(String code, String message) {
            super(message);
            this.code = code;
        }
    }

    private final PathGuard guard;

    public FileApi(File root) throws IOException {
        this.guard = new PathGuard(root);
    }

    public PathGuard guard() {
        return guard;
    }

    public JSONObject info() {
        File root = guard.root();
        JSONObject result = Json.obj();
        Json.put(result, "root", root.getAbsolutePath());
        Json.put(result, "readable", root.canRead());
        Json.put(result, "writable", root.canWrite());
        Json.put(result, "total", root.getTotalSpace());
        Json.put(result, "free", root.getFreeSpace());
        Json.put(result, "usable", root.getUsableSpace());
        Json.put(result, "separator", File.separator);
        return result;
    }

    public JSONObject stat(String path) throws Error {
        File file = resolve(path);
        if (!file.exists()) throw new Error("not_found", "not found");
        return statObject(file);
    }

    public JSONObject list(String path, int limit) throws Error {
        File dir = resolve(path);
        if (!dir.exists()) throw new Error("not_found", "not found");
        if (!dir.isDirectory()) throw new Error("bad_request", "not a directory");
        int max = Math.max(1, Math.min(limit <= 0 ? 1000 : limit, MAX_LIST));
        List<File> sorted = new ArrayList<>();
        boolean truncated = false;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir.toPath())) {
            for (Path child : stream) {
                if (sorted.size() >= max + 1) {
                    truncated = true;
                    break;
                }
                sorted.add(child.toFile());
            }
        } catch (IOException e) {
            throw new Error("io_error", "cannot list directory");
        }
        Collections.sort(sorted, new Comparator<File>() {
            @Override
            public int compare(File left, File right) {
                boolean leftDir = left.isDirectory();
                boolean rightDir = right.isDirectory();
                if (leftDir != rightDir) return leftDir ? -1 : 1;
                return left.getName().compareToIgnoreCase(right.getName());
            }
        });

        JSONArray entries = Json.arr();
        int bytes = 0;

        for (File child : sorted) {
            if (entries.length() >= max) {
                truncated = true;
                break;
            }
            if (Files.isSymbolicLink(child.toPath())) {
                try {
                    guard.resolve(child.getAbsolutePath());
                } catch (IOException | SecurityException e) {
                    continue;
                }
            }
            JSONObject entry = entry(child);
            int size = entry.toString().getBytes(StandardCharsets.UTF_8).length + 1;
            if (bytes + size > MAX_LIST_BYTES) {
                truncated = true;
                break;
            }
            entries.put(entry);
            bytes += size;
        }

        JSONObject result = Json.obj();
        Json.put(result, "path", guard.relative(dir));
        Json.put(result, "entries", entries);
        Json.put(result, "truncated", truncated);
        Json.put(result, "count", entries.length());
        return result;
    }

    public JSONObject read(String path, long offset, int length) throws Error {
        File file = resolve(path);
        if (!file.exists()) throw new Error("not_found", "not found");
        if (!file.isFile()) throw new Error("bad_request", "not a file");
        if (offset < 0) throw new Error("bad_request", "negative offset");
        int max = Math.max(1, Math.min(length <= 0 ? MAX_CHUNK : length, MAX_CHUNK));
        long size = file.length();

        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] buffer = new byte[max];
            int count = 0;
            if (offset < size) {
                raf.seek(offset);
                count = raf.read(buffer);
                if (count < 0) count = 0;
            }
            byte[] data = count == buffer.length ? buffer : Arrays.copyOf(buffer, count);
            JSONObject result = Json.obj();
            Json.put(result, "data", Base64.getEncoder().encodeToString(data));
            Json.put(result, "offset", offset);
            Json.put(result, "length", count);
            Json.put(result, "size", size);
            Json.put(result, "eof", offset + count >= size);
            return result;
        } catch (IOException e) {
            throw new Error("io_error", "cannot read file");
        }
    }

    public JSONObject write(String path, long offset, byte[] data, boolean truncate) throws Error {
        if (data == null) throw new Error("bad_request", "missing data");
        if (data.length > MAX_CHUNK) throw new Error("too_large", "chunk too large");
        if (offset < 0) throw new Error("bad_request", "negative offset");

        File file = resolve(path);
        File parent = file.getParentFile();
        if (parent == null || !parent.isDirectory()) throw new Error("not_found", "parent not found");
        if (file.exists() && !file.isFile()) throw new Error("bad_request", "not a file");

        try (RandomAccessFile raf = new RandomAccessFile(file, "rw")) {
            if (truncate) raf.setLength(0);
            raf.seek(offset);
            raf.write(data);
            JSONObject result = Json.obj();
            Json.put(result, "written", data.length);
            Json.put(result, "size", raf.length());
            return result;
        } catch (IOException e) {
            throw new Error("io_error", "cannot write file");
        }
    }

    public JSONObject mkdir(String path, boolean parents) throws Error {
        File dir = resolve(path);
        if (dir.exists()) throw new Error("exists", "already exists");
        File parent = dir.getParentFile();
        if (!parents && (parent == null || !parent.isDirectory())) {
            throw new Error("not_found", "parent not found");
        }
        boolean created = parents ? dir.mkdirs() : dir.mkdir();
        if (!created) throw new Error("io_error", "cannot create directory");
        return Json.put(Json.obj(), "created", true);
    }

    public JSONObject move(String from, String to) throws Error {
        File source = resolve(from);
        File target = resolve(to);
        if (source.equals(guard.root())) throw new Error("bad_request", "cannot move storage root");
        if (!source.exists()) throw new Error("not_found", "source not found");
        if (target.exists()) throw new Error("exists", "target exists");
        File parent = target.getParentFile();
        if (parent == null || !parent.isDirectory()) throw new Error("not_found", "target parent not found");
        if (source.isDirectory() && isInside(source, target)) {
            throw new Error("bad_request", "cannot move a directory into itself");
        }
        try {
            Files.move(source.toPath(), target.toPath());
            return Json.put(Json.put(Json.obj(), "moved", true), "to", guard.relative(target));
        } catch (IOException e) {
            throw new Error("io_error", "move failed");
        }
    }

    public JSONObject copy(String from, String to) throws Error {
        File source = resolve(from);
        File target = resolve(to);
        if (source.equals(guard.root())) throw new Error("bad_request", "cannot copy storage root");
        if (!source.exists()) throw new Error("not_found", "source not found");
        if (target.exists()) throw new Error("exists", "target exists");
        File parent = target.getParentFile();
        if (parent == null || !parent.isDirectory()) throw new Error("not_found", "target parent not found");
        if (source.isDirectory() && isInside(source, target)) {
            throw new Error("bad_request", "cannot copy a directory into itself");
        }
        try {
            if (source.isDirectory()) {
                Files.createDirectory(target.toPath());
                final Path sourcePath = source.toPath();
                final Path targetPath = target.toPath();
                Files.walkFileTree(sourcePath, new SimpleFileVisitor<Path>() {
                    @Override
                    public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                            throws IOException {
                        if (dir.equals(sourcePath)) return FileVisitResult.CONTINUE;
                        Files.createDirectory(targetPath.resolve(sourcePath.relativize(dir).toString()));
                        return FileVisitResult.CONTINUE;
                    }

                    @Override
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                            throws IOException {
                        if (attrs.isSymbolicLink()) return FileVisitResult.CONTINUE;
                        Files.copy(file, targetPath.resolve(sourcePath.relativize(file).toString()));
                        return FileVisitResult.CONTINUE;
                    }
                });
            } else {
                if (Files.isSymbolicLink(source.toPath())) {
                    throw new Error("bad_request", "symlinks are not supported");
                }
                Files.copy(source.toPath(), target.toPath());
            }
            return Json.put(Json.put(Json.obj(), "copied", true), "to", guard.relative(target));
        } catch (IOException e) {
            throw new Error("io_error", "copy failed");
        }
    }

    public JSONObject delete(String path, boolean recursive) throws Error {
        File file = resolve(path);
        if (file.equals(guard.root())) throw new Error("bad_request", "cannot delete storage root");
        if (!file.exists()) throw new Error("not_found", "not found");
        if (file.isDirectory()) {
            if (!recursive) {
                File[] children = file.listFiles();
                if (children != null && children.length > 0) {
                    throw new Error("not_empty", "directory not empty");
                }
            } else {
                try {
                    Files.walkFileTree(file.toPath(), new SimpleFileVisitor<Path>() {
                        @Override
                        public FileVisitResult visitFile(Path current, BasicFileAttributes attrs)
                                throws IOException {
                            Files.delete(current);
                            return FileVisitResult.CONTINUE;
                        }

                        @Override
                        public FileVisitResult postVisitDirectory(Path current, IOException error)
                                throws IOException {
                            if (error != null) throw error;
                            Files.delete(current);
                            return FileVisitResult.CONTINUE;
                        }
                    });
                } catch (IOException e) {
                    throw new Error("io_error", "delete failed");
                }
                return Json.put(Json.put(Json.obj(), "deleted", true), "recursive", true);
            }
        }
        if (!file.delete()) throw new Error("io_error", "delete failed");
        return Json.put(Json.put(Json.obj(), "deleted", true), "recursive", false);
    }

    public JSONObject search(String path, String query, int maxDepth, int limit) throws Error {
        File start = resolve(path);
        if (!start.exists()) throw new Error("not_found", "not found");
        if (!start.isDirectory()) throw new Error("bad_request", "not a directory");
        String needle = query == null ? "" : query.trim();
        if (needle.isEmpty()) throw new Error("bad_request", "missing query");
        if (needle.length() > 128) throw new Error("bad_request", "query too long");
        final String lowered = needle.toLowerCase(Locale.US);
        final int depth = Math.max(1, Math.min(maxDepth <= 0 ? 8 : maxDepth, MAX_SEARCH_DEPTH));
        final int max = Math.max(1, Math.min(limit <= 0 ? 200 : limit, MAX_SEARCH));
        final long deadline = System.currentTimeMillis() + SEARCH_BUDGET_MS;
        final JSONArray entries = Json.arr();
        final AtomicInteger count = new AtomicInteger();
        final AtomicBoolean truncated = new AtomicBoolean(false);
        final Path startPath = start.toPath();

        try {
            Files.walkFileTree(startPath, java.util.EnumSet.noneOf(java.nio.file.FileVisitOption.class), depth,
                    new SimpleFileVisitor<Path>() {
                        private boolean shouldStop() {
                            if (count.get() >= max || System.currentTimeMillis() > deadline) {
                                truncated.set(true);
                                return true;
                            }
                            return false;
                        }

                        private void add(Path current, BasicFileAttributes attrs) {
                            if (attrs.isSymbolicLink() || Files.isSymbolicLink(current)) return;
                            File file = current.toFile();
                            entries.put(entry(file));
                            count.incrementAndGet();
                        }

                        @Override
                        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                            if (shouldStop()) return FileVisitResult.TERMINATE;
                            if (!dir.equals(startPath)
                                    && dir.getFileName().toString().toLowerCase(Locale.US).contains(lowered)) {
                                add(dir, attrs);
                                if (count.get() >= max) {
                                    truncated.set(true);
                                    return FileVisitResult.TERMINATE;
                                }
                            }
                            return FileVisitResult.CONTINUE;
                        }

                        @Override
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                            if (shouldStop()) return FileVisitResult.TERMINATE;
                            if (file.getFileName().toString().toLowerCase(Locale.US).contains(lowered)) {
                                add(file, attrs);
                                if (count.get() >= max) {
                                    truncated.set(true);
                                    return FileVisitResult.TERMINATE;
                                }
                            }
                            return FileVisitResult.CONTINUE;
                        }

                        @Override
                        public FileVisitResult visitFileFailed(Path file, IOException error) {
                            return FileVisitResult.CONTINUE;
                        }
                    });
        } catch (IOException e) {
            throw new Error("io_error", "search failed");
        }

        JSONObject result = Json.obj();
        Json.put(result, "query", needle);
        Json.put(result, "entries", entries);
        Json.put(result, "truncated", truncated.get());
        Json.put(result, "count", entries.length());
        return result;
    }

    public JSONObject hash(String path) throws Error {
        File file = resolve(path);
        if (!file.exists()) throw new Error("not_found", "not found");
        if (!file.isFile()) throw new Error("bad_request", "not a file");
        try (FileInputStream in = new FileInputStream(file)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = in.read(buffer)) >= 0) {
                digest.update(buffer, 0, count);
            }
            JSONObject result = Json.obj();
            Json.put(result, "algorithm", "sha256");
            Json.put(result, "value", Crypto.hex(digest.digest()));
            Json.put(result, "size", file.length());
            return result;
        } catch (Exception e) {
            throw new Error("io_error", "cannot hash file");
        }
    }

    private JSONObject statObject(File file) {
        JSONObject result = Json.obj();
        Json.put(result, "path", guard.relative(file));
        Json.put(result, "name", file.getName());
        Json.put(result, "type", type(file));
        Json.put(result, "size", file.isFile() ? file.length() : 0L);
        Json.put(result, "mtime", file.lastModified());
        Json.put(result, "readable", file.canRead());
        Json.put(result, "writable", file.canWrite());
        return result;
    }

    private JSONObject entry(File file) {
        JSONObject result = Json.obj();
        Json.put(result, "name", file.getName());
        Json.put(result, "path", guard.relative(file));
        Json.put(result, "type", type(file));
        Json.put(result, "size", file.isFile() ? file.length() : 0L);
        Json.put(result, "mtime", file.lastModified());
        return result;
    }

    private File resolve(String path) throws Error {
        try {
            return guard.resolve(path);
        } catch (SecurityException e) {
            throw new Error("bad_path", "path escapes shared storage");
        } catch (IOException e) {
            throw new Error("io_error", "cannot resolve path");
        }
    }

    private static boolean isInside(File parent, File child) {
        try {
            String parentPath = parent.getCanonicalPath();
            String childPath = child.getCanonicalPath();
            return childPath.startsWith(parentPath + File.separator);
        } catch (IOException e) {
            return true;
        }
    }

    private static String type(File file) {
        if (Files.isSymbolicLink(file.toPath())) return "link";
        if (file.isDirectory()) return "dir";
        if (file.isFile()) return "file";
        return "other";
    }
}

package dev.aetherix.localkey;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class Json {
    private Json() {
    }

    public static JSONObject obj() {
        return new JSONObject();
    }

    public static JSONObject put(JSONObject object, String key, Object value) {
        try {
            object.put(key, value);
            return object;
        } catch (JSONException e) {
            throw new IllegalStateException("invalid json value", e);
        }
    }

    public static JSONArray arr() {
        return new JSONArray();
    }

    public static JSONArray add(JSONArray array, Object value) {
        array.put(value);
        return array;
    }

    public static String str(JSONObject object, String key) throws JSONException {
        if (!object.has(key) || object.isNull(key)) throw new JSONException("missing " + key);
        return object.getString(key);
    }

    public static JSONObject child(JSONObject object, String key) throws JSONException {
        JSONObject value = object.optJSONObject(key);
        if (value == null) throw new JSONException("missing " + key);
        return value;
    }
}

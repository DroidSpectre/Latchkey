package dev.aetherix.localkey;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.Arrays;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public final class KeyStoreManager {
    private static final String PREFS = "localkey";
    private static final String ALIAS_LEGACY = "localkey_access_key_v1";
    private static final String ALIAS_CLIENT_KEK = "localkey_client_kek_v1";
    private static final byte[] LEGACY_AAD = "LOCALKEY/KEYWRAP/1".getBytes(StandardCharsets.UTF_8);
    private static final byte[] CLIENT_AAD_PREFIX = "LOCALKEY/PAIRWRAP/1|".getBytes(StandardCharsets.UTF_8);

    private static final Object SESSION_LOCK = new Object();
    private static final Object KEK_LOCK = new Object();
    private static byte[] sessionLegacy;

    private final SharedPreferences prefs;
    private final EventLog log;

    public KeyStoreManager(Context context) {
        this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.log = EventLog.get(context);
    }

    public byte[] getLegacyKey() {
        synchronized (SESSION_LOCK) {
            if (sessionLegacy != null) return sessionLegacy.clone();

            String stored = prefs.getString("wrapped_legacy", null);
            if (stored != null) {
                try {
                    byte[] key = unwrapWithAlias(ALIAS_LEGACY, LEGACY_AAD, stored);
                    if (key.length == Crypto.KEY_BYTES) return key;
                    Crypto.zero(key);
                } catch (Exception e) {
                    resetAlias(ALIAS_LEGACY);
                    log.warn("keystore", "legacy key unwrap failed; generating a new key");
                }
            }

            byte[] key = Crypto.random(Crypto.KEY_BYTES);
            try {
                String wrapped = wrapWithAlias(ALIAS_LEGACY, LEGACY_AAD, key);
                prefs.edit()
                        .putString("wrapped_legacy", wrapped)
                        .putLong("legacy_created", System.currentTimeMillis())
                        .apply();
            } catch (Exception e) {
                sessionLegacy = key.clone();
                prefs.edit().remove("wrapped_legacy").apply();
                log.warn("keystore", "hardware keystore unavailable; legacy key is session-only");
            }
            return key;
        }
    }

    public byte[] rotateLegacyKey() {
        synchronized (SESSION_LOCK) {
            Crypto.zero(sessionLegacy);
            sessionLegacy = null;
            byte[] key = Crypto.random(Crypto.KEY_BYTES);
            try {
                String wrapped = wrapWithAlias(ALIAS_LEGACY, LEGACY_AAD, key);
                prefs.edit()
                        .putString("wrapped_legacy", wrapped)
                        .putLong("legacy_created", System.currentTimeMillis())
                        .apply();
            } catch (Exception e) {
                sessionLegacy = key.clone();
                prefs.edit().remove("wrapped_legacy").apply();
                log.warn("keystore", "hardware keystore unavailable; rotated key is session-only");
            }
            log.info("keystore", "legacy key rotated");
            return key;
        }
    }

    public String fingerprint() {
        byte[] key = getLegacyKey();
        try {
            return Crypto.fingerprint(key);
        } finally {
            Crypto.zero(key);
        }
    }

    public synchronized String hostId() {
        String value = prefs.getString("host_id", null);
        if (value != null && value.matches("[a-f0-9]{32}")) return value;
        value = Crypto.hex(Crypto.random(16));
        prefs.edit().putString("host_id", value).apply();
        return value;
    }

    public String wrapClientKey(String clientId, byte[] key) throws GeneralSecurityException {
        synchronized (KEK_LOCK) {
            return Crypto.b64(Crypto.encrypt(clientKek(), clientAad(clientId), key));
        }
    }

    public byte[] unwrapClientKey(String clientId, String wrapped) throws GeneralSecurityException {
        byte[] blob;
        try {
            blob = Crypto.unb64(wrapped);
        } catch (IllegalArgumentException e) {
            throw new GeneralSecurityException("invalid wrapped key", e);
        }
        synchronized (KEK_LOCK) {
            return Crypto.decrypt(clientKek(), clientAad(clientId), blob);
        }
    }

    public void deleteClientKek() {
        synchronized (KEK_LOCK) {
            try {
                KeyStore store = KeyStore.getInstance("AndroidKeyStore");
                store.load(null);
                if (store.containsAlias(ALIAS_CLIENT_KEK)) store.deleteEntry(ALIAS_CLIENT_KEK);
            } catch (Exception e) {
                log.warn("keystore", "could not delete client wrapping key");
            }
        }
    }

    private SecretKey clientKek() throws GeneralSecurityException {
        try {
            return getOrCreate(ALIAS_CLIENT_KEK);
        } catch (IOException e) {
            throw new GeneralSecurityException("keystore unavailable", e);
        }
    }

    private String wrapWithAlias(String alias, byte[] aad, byte[] key)
            throws GeneralSecurityException, IOException {
        return Crypto.b64(Crypto.encrypt(getOrCreate(alias), aad, key));
    }

    private byte[] unwrapWithAlias(String alias, byte[] aad, String wrapped)
            throws GeneralSecurityException, IOException {
        return Crypto.decrypt(getOrCreate(alias), aad, Crypto.unb64(wrapped));
    }

    private SecretKey getOrCreate(String alias) throws GeneralSecurityException, IOException {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        KeyStore.Entry entry = store.getEntry(alias, null);
        if (entry instanceof KeyStore.SecretKeyEntry) {
            return ((KeyStore.SecretKeyEntry) entry).getSecretKey();
        }
        if (entry != null) {
            store.deleteEntry(alias);
        }

        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                alias, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build();
        generator.init(spec);
        generator.generateKey();
        return (SecretKey) store.getKey(alias, null);
    }

    private void resetAlias(String alias) {
        try {
            KeyStore store = KeyStore.getInstance("AndroidKeyStore");
            store.load(null);
            if (store.containsAlias(alias)) store.deleteEntry(alias);
        } catch (Exception ignored) {
        }
    }

    private static byte[] clientAad(String clientId) {
        byte[] id = clientId.getBytes(StandardCharsets.UTF_8);
        byte[] aad = Arrays.copyOf(CLIENT_AAD_PREFIX, CLIENT_AAD_PREFIX.length + id.length);
        System.arraycopy(id, 0, aad, CLIENT_AAD_PREFIX.length, id.length);
        return aad;
    }
}

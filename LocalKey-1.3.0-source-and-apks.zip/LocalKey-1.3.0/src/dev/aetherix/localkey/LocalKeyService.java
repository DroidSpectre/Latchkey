package dev.aetherix.localkey;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.graphics.drawable.Icon;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;

public final class LocalKeyService extends Service {
    public static final String ACTION_START = "dev.aetherix.localkey.START";
    public static final String ACTION_STOP = "dev.aetherix.localkey.STOP";
    public static final String ACTION_REVOKE_ALL = "dev.aetherix.localkey.REVOKE_ALL";
    public static final String ACTION_REVOKE_CLIENT = "dev.aetherix.localkey.REVOKE_CLIENT";
    public static final String ACTION_ROTATE = "dev.aetherix.localkey.ROTATE";
    public static final String EXTRA_CLIENT_ID = "client_id";
    public static final int PORT = 39401;
    public static final String EXTRA_PAIR = "pair";
    public static final String EXTRA_REVOKE = "revoke";

    private static final String CHANNEL = "localkey";
    private static final int NOTIFICATION_ID = 39401;
    private static volatile boolean running;

    private EventLog log;
    private AppInfo appInfo;
    private KeyStoreManager keys;
    private PairStore pairs;
    private PairingManager pairing;
    private FileApi files;
    private RpcHandler handler;
    private RpcServer server;
    private Thread thread;

    public static boolean isRunning() {
        return running;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        log = EventLog.get(this);
        appInfo = AppInfo.read(this);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager.getNotificationChannel(CHANNEL) == null) {
            manager.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "LocalKey", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        startForegroundCompat(notification("Starting"));

        if (ACTION_STOP.equals(action)) {
            stopServer();
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!Environment.isExternalStorageManager()) {
            updateNotification("All files access is required");
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!ensureComponents()) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_REVOKE_ALL.equals(action)) {
            pairing.invalidate();
            int count = pairs.revokeAll();
            keys.deleteClientKek();
            keys.rotateLegacyKey();
            if (server != null) restartServer();
            log.info("pairing", "revoked " + count + " client(s); rotated legacy key");
            updateNotification("Revoked " + count + " client(s); legacy key rotated");
            return START_NOT_STICKY;
        }

        if (ACTION_REVOKE_CLIENT.equals(action)) {
            String id = intent == null ? null : intent.getStringExtra(EXTRA_CLIENT_ID);
            if (id != null && pairs.revoke(id)) {
                updateNotification("Client revoked");
            }
            return START_NOT_STICKY;
        }

        if (ACTION_ROTATE.equals(action)) {
            keys.rotateLegacyKey();
            if (server != null) restartServer();
            updateNotification("Legacy key rotated");
            return START_NOT_STICKY;
        }

        if (server == null) startServer();
        return START_NOT_STICKY;
    }

    private boolean ensureComponents() {
        if (keys != null && files != null) return true;
        try {
            keys = new KeyStoreManager(this);
            pairs = new PairStore(this, keys);
            pairing = new PairingManager(keys, pairs, log);
            files = new FileApi(Environment.getExternalStorageDirectory());
            return true;
        } catch (Exception e) {
            log.error("server", "initialization failed");
            updateNotification("Cannot initialize: " + e.getMessage());
            return false;
        }
    }

    private void startServer() {
        try {
            handler = new RpcHandler(keys, pairs, files, log);
            server = new RpcServer(PORT, handler, pairing, log, appInfo, this::onServerState);
            thread = new Thread(server, "localkey-server");
            thread.start();
            running = true;
            updateNotification("Listening on 127.0.0.1:" + PORT);
        } catch (Exception e) {
            log.error("server", "start failed");
            updateNotification("Cannot start: " + e.getMessage());
            if (server != null) {
                server.close();
                server = null;
            }
            handler = null;
            running = false;
            stopSelf();
        }
    }

    private void restartServer() {
        stopServer();
        startServer();
    }

    private void stopServer() {
        running = false;
        if (pairing != null) pairing.invalidate();
        if (server != null) {
            server.close();
            server = null;
        }
        handler = null;
        if (thread != null) {
            try {
                thread.join(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            thread = null;
        }
    }

    private void onServerState(String state) {
        if ("listening".equals(state)) {
            if (!running || server == null) return;
            int clients = pairs == null ? 0 : pairs.count();
            updateNotification("Listening on 127.0.0.1:" + PORT + " · " + clients + " client(s)");
        } else if ("stopped".equals(state)) {
            if (running || server != null) return;
            updateNotification("Stopped");
        }
    }

    private void startForegroundCompat(Notification value) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, value, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, value);
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(
                this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent pair = new Intent(this, MainActivity.class)
                .putExtra(EXTRA_PAIR, true)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pairIntent = PendingIntent.getActivity(
                this, 3, pair, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent revoke = new Intent(this, MainActivity.class)
                .putExtra(EXTRA_REVOKE, true)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent revokeIntent = PendingIntent.getActivity(
                this, 4, revoke, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, LocalKeyService.class).setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(
                this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL)
                .setContentTitle(appInfo == null ? "LocalKey" : "LocalKey " + appInfo.versionName)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentIntent(content)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, android.R.drawable.ic_menu_add), "Pair", pairIntent).build())
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, android.R.drawable.ic_menu_delete), "Revoke", revokeIntent).build())
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stopIntent).build())
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String text) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.notify(NOTIFICATION_ID, notification(text));
    }

    @Override
    public void onDestroy() {
        stopServer();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

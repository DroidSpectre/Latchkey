package dev.aetherix.localkey;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final long POLL_MS = 2000;
    private static final int RC_NOTIFICATIONS = 101;
    private static final int PAGE_HOME = 0;
    private static final int PAGE_CONNECT = 1;
    private static final int PAGE_AUDIT = 2;
    private static final int PAGE_SETTINGS = 3;
    private static final String STATE_PAGE = "active_page";
    private static final String UI_PREFS = "localkey-ui";
    private static final String PREF_NOTIFICATION_ASKED = "notification_asked";
    private static final String PREF_LAYOUT = "layout_mode";
    private static final String LAYOUT_TABS = "tabs";
    private static final String LAYOUT_DRAWER = "drawer";

    private TextView serverTitle;
    private TextView serverMeta;
    private TextView statusPill;
    private TextView readinessCount;
    private TextView readinessHint;
    private TextView fileState;
    private TextView notifyState;
    private TextView batteryState;
    private TextView assistantSummary;
    private TextView fingerprintView;
    private TextView keyView;
    private TextView auditSummary;
    private TextView auditText;
    private TextView clientsCount;
    private LinearLayout readinessPanel;
    private LinearLayout clientsContainer;

    private View statusDot;
    private Button startStopButton;
    private Button fileAction;
    private Button notifyAction;
    private Button batteryAction;
    private Button pairButton;
    private Button revokeAllButton;
    private Button revealAction;

    private KeyStoreManager keys;
    private PairStore pairs;
    private EventLog log;
    private boolean revealed;
    private String lastReadiness;
    private String layoutMode;
    private int activePage = PAGE_HOME;
    private View[] pages;
    private FrameLayout pageHost;
    private View drawerScrim;
    private LinearLayout drawerPanel;
    private boolean drawerOpen;
    private final List<NavBinding> navBindings = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, POLL_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        keys = new KeyStoreManager(this);
        pairs = new PairStore(this, keys);
        log = EventLog.get(this);
        layoutMode = resolveLayout();
        if (savedInstanceState != null) {
            activePage = savedInstanceState.getInt(STATE_PAGE, PAGE_HOME);
            if (activePage < PAGE_HOME || activePage > PAGE_SETTINGS) activePage = PAGE_HOME;
        }
        setContentView(buildShell());
        hardenTouches(getWindow().getDecorView());
        handleIntent(getIntent());
        refresh();
        updateKeyView();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_PAGE, activePage);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        if (intent.getBooleanExtra(LocalKeyService.EXTRA_PAIR, false)) {
            intent.removeExtra(LocalKeyService.EXTRA_PAIR);
            selectPage(PAGE_CONNECT);
            getWindow().getDecorView().post(this::pair);
        }
        if (intent.getBooleanExtra(LocalKeyService.EXTRA_REVOKE, false)) {
            intent.removeExtra(LocalKeyService.EXTRA_REVOKE);
            selectPage(PAGE_CONNECT);
            getWindow().getDecorView().post(this::confirmRevokeAll);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        updateKeyView();
        handler.removeCallbacks(poll);
        handler.postDelayed(poll, POLL_MS);
        handler.postDelayed(this::refresh, 350);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(poll);
        if (revealed) {
            revealed = false;
            updateKeyView();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (drawerOpen) {
            closeDrawer();
            return;
        }
        if (activePage != PAGE_HOME) {
            selectPage(PAGE_HOME);
            return;
        }
        super.onBackPressed();
    }

    private String resolveLayout() {
        if (!Flavor.LAYOUT_SWITCH) return Flavor.DEFAULT_LAYOUT;
        String saved = getSharedPreferences(UI_PREFS, MODE_PRIVATE)
                .getString(PREF_LAYOUT, Flavor.DEFAULT_LAYOUT);
        return LAYOUT_DRAWER.equals(saved) ? LAYOUT_DRAWER : LAYOUT_TABS;
    }

    private boolean isDrawerLayout() {
        return LAYOUT_DRAWER.equals(layoutMode);
    }

    private View buildShell() {
        pages = new View[] { buildHomePage(), buildConnectPage(), buildAuditPage(), buildSettingsPage() };
        pageHost = new FrameLayout(this);
        pageHost.setBackgroundColor(Ui.BG);
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == activePage ? View.VISIBLE : View.GONE);
            pageHost.addView(pages[i], new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        return isDrawerLayout() ? buildDrawerShell() : buildTabShell();
    }

    private View buildTabShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.addView(appBar(false), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(pageHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(bottomNav(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        updateNavigation();
        return root;
    }

    private View buildDrawerShell() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.addView(appBar(true), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(pageHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        drawerScrim = new View(this);
        drawerScrim.setBackgroundColor(Color.BLACK);
        drawerScrim.setAlpha(0f);
        drawerScrim.setVisibility(View.GONE);
        drawerScrim.setClickable(true);
        drawerScrim.setOnClickListener(v -> closeDrawer());
        root.addView(drawerScrim, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        drawerPanel = buildDrawer();
        int screen = getResources().getDisplayMetrics().widthPixels;
        int width = Math.min(Ui.dp(this, 310), Math.max(Ui.dp(this, 260), screen - Ui.dp(this, 54)));
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(
                width, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START);
        root.addView(drawerPanel, drawerParams);
        drawerPanel.setVisibility(View.INVISIBLE);
        drawerPanel.setTranslationX(-width);
        updateNavigation();
        return root;
    }

    private View appBar(boolean menuMode) {
        LinearLayout bar = row();
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Ui.BG);
        bar.setPadding(Ui.dp(this, 20), Ui.dp(this, 10), Ui.dp(this, 20), Ui.dp(this, 8));

        if (menuMode) {
            FrameLayout menu = navIconButton(R.drawable.ic_menu, "Open navigation", this::openDrawer);
            bar.addView(menu, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        } else {
            View logo = Ui.iconBox(this, R.drawable.ic_key, Ui.TEAL, 36, 19);
            bar.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)));
        }

        TextView title = Ui.text(this, "LocalKey", 22f, Ui.TEXT, Ui.sansBold());
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleParams.leftMargin = Ui.dp(this, 11);
        bar.addView(title, titleParams);

        TextView version = Ui.pill(this, "v" + log.versionName(),
                Ui.MUTED, Ui.withAlpha(Ui.BORDER, 120), Ui.BORDER);
        bar.addView(version);
        return bar;
    }

    private View bottomNav() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(Ui.BG);
        bar.addView(Ui.divider(this));

        LinearLayout items = row();
        items.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10), Ui.dp(this, 8));
        items.addView(tabItem(PAGE_HOME, "Home", R.drawable.ic_home),
                new LinearLayout.LayoutParams(0, Ui.dp(this, 54), 1f));
        items.addView(tabItem(PAGE_CONNECT, "Connect", R.drawable.ic_link),
                new LinearLayout.LayoutParams(0, Ui.dp(this, 54), 1f));
        items.addView(tabItem(PAGE_AUDIT, "Audit", R.drawable.ic_log),
                new LinearLayout.LayoutParams(0, Ui.dp(this, 54), 1f));
        items.addView(tabItem(PAGE_SETTINGS, "Settings", R.drawable.ic_settings),
                new LinearLayout.LayoutParams(0, Ui.dp(this, 54), 1f));
        bar.addView(items);
        return bar;
    }

    private View tabItem(int page, String label, int iconRes) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setClickable(true);
        item.setFocusable(true);
        item.setContentDescription(label);
        item.setOnClickListener(v -> selectPage(page));

        ImageView icon = Ui.icon(this, iconRes, Ui.MUTED, 21);
        item.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 21), Ui.dp(this, 21)));

        TextView text = Ui.text(this, label, 10.5f, Ui.MUTED, Ui.sansMedium());
        text.setPadding(0, Ui.dp(this, 3), 0, 0);
        item.addView(text);
        navBindings.add(new NavBinding(item, icon, text, page));
        return item;
    }

    private LinearLayout buildDrawer() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 22));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Ui.CARD_DEEP);
        background.setStroke(Ui.dp(this, 1), Ui.BORDER);
        float radius = Ui.dp(this, 24);
        background.setCornerRadii(new float[] { 0, 0, radius, radius, radius, radius, 0, 0 });
        panel.setBackground(background);
        panel.setElevation(Ui.dp(this, 18));

        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(Ui.iconBox(this, R.drawable.ic_key, Ui.TEAL, 44, 23),
                new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        copy.addView(Ui.text(this, "LocalKey", 23f, Ui.TEXT, Ui.sansBold()));
        copy.addView(Ui.text(this, "v" + log.versionName(), 10.5f, Ui.MUTED, Ui.mono()));
        header.addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(navIconButton(R.drawable.ic_close, "Close navigation", this::closeDrawer),
                new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)));
        panel.addView(header);

        TextView label = Ui.section(this, "Navigation");
        label.setPadding(0, Ui.dp(this, 28), 0, Ui.dp(this, 8));
        panel.addView(label);

        panel.addView(drawerItem(PAGE_HOME, "Home", R.drawable.ic_home));
        panel.addView(drawerItem(PAGE_CONNECT, "Connect", R.drawable.ic_link));
        panel.addView(drawerItem(PAGE_AUDIT, "Audit", R.drawable.ic_log));
        panel.addView(drawerItem(PAGE_SETTINGS, "Settings", R.drawable.ic_settings));

        View spacer = new View(this);
        panel.addView(spacer, new LinearLayout.LayoutParams(0, 0, 1f));
        panel.addView(Ui.divider(this));
        TextView note = Ui.text(this,
                "Loopback only · AES-256-GCM\nVariant " + Flavor.VARIANT + " · schema " + EventLog.SCHEMA,
                10f, Ui.FAINT, Ui.sans());
        note.setLineSpacing(Ui.dp(this, 3), 1f);
        note.setPadding(0, Ui.dp(this, 14), 0, 0);
        panel.addView(note);
        return panel;
    }

    private View drawerItem(int page, String label, int iconRes) {
        LinearLayout item = row();
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        item.setClickable(true);
        item.setFocusable(true);
        item.setContentDescription(label);
        item.setOnClickListener(v -> selectPage(page));

        ImageView icon = Ui.icon(this, iconRes, Ui.MUTED, 22);
        item.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22)));
        TextView text = Ui.text(this, label, 15f, Ui.MUTED, Ui.sansMedium());
        text.setPadding(Ui.dp(this, 13), 0, 0, 0);
        item.addView(text, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        navBindings.add(new NavBinding(item, icon, text, page));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 50));
        params.topMargin = Ui.dp(this, 3);
        item.setLayoutParams(params);
        return item;
    }

    private FrameLayout navIconButton(int iconRes, String description, Runnable action) {
        FrameLayout box = new FrameLayout(this);
        box.setBackground(Ui.card(this, Ui.withAlpha(Ui.CARD, 170), Ui.BORDER, 11));
        box.setClickable(true);
        box.setFocusable(true);
        box.setContentDescription(description);
        ImageView icon = Ui.icon(this, iconRes, Ui.MUTED, 21);
        box.addView(icon, new FrameLayout.LayoutParams(
                Ui.dp(this, 21), Ui.dp(this, 21), Gravity.CENTER));
        box.setOnClickListener(v -> action.run());
        return box;
    }

    private void updateNavigation() {
        for (NavBinding binding : navBindings) {
            boolean selected = binding.page == activePage;
            binding.container.setSelected(selected);
            binding.container.setBackground(selected
                    ? Ui.card(this, Ui.withAlpha(Ui.TEAL, 18), Ui.withAlpha(Ui.TEAL, 38), 14)
                    : null);
            binding.icon.setColorFilter(selected ? Ui.TEAL : Ui.MUTED);
            binding.label.setTextColor(selected ? Ui.TEAL : Ui.MUTED);
        }
    }

    private void selectPage(int page) {
        if (page < 0 || page >= pages.length) return;
        activePage = page;
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == activePage ? View.VISIBLE : View.GONE);
        }
        updateNavigation();
        if (drawerOpen) closeDrawer();
        if (page == PAGE_CONNECT) refreshClients();
        if (page == PAGE_AUDIT) updateAuditView();
    }

    private void openDrawer() {
        if (drawerPanel == null || drawerOpen) return;
        drawerOpen = true;
        int width = drawerPanel.getWidth() > 0 ? drawerPanel.getWidth() : Ui.dp(this, 304);
        drawerPanel.setVisibility(View.VISIBLE);
        drawerPanel.setTranslationX(-width);
        drawerScrim.setVisibility(View.VISIBLE);
        drawerScrim.setAlpha(0f);
        drawerPanel.animate().translationX(0f).setDuration(220).start();
        drawerScrim.animate().alpha(0.55f).setDuration(180).start();
    }

    private void closeDrawer() {
        if (drawerPanel == null || !drawerOpen) return;
        drawerOpen = false;
        int width = drawerPanel.getWidth() > 0 ? drawerPanel.getWidth() : Ui.dp(this, 304);
        drawerPanel.animate().translationX(-width).setDuration(180)
                .withEndAction(() -> drawerPanel.setVisibility(View.INVISIBLE)).start();
        drawerScrim.animate().alpha(0f).setDuration(180)
                .withEndAction(() -> drawerScrim.setVisibility(View.GONE)).start();
    }

    private View buildHomePage() {
        Page page = newPage("Home", "Status", "Private access, ready when you are.", Ui.TEAL);
        TextView pill = Ui.pill(this, "LOCAL · ENCRYPTED · LOOPBACK",
                Ui.TEAL, Ui.withAlpha(Ui.TEAL, 22), Ui.withAlpha(Ui.TEAL, 62));
        page.body.addView(pill);
        page.body.addView(statusCard(), topParams(14));
        page.body.addView(readinessCard(), topParams(14));
        page.body.addView(footer(), topParams(26));
        return page.scroll;
    }

    private View buildConnectPage() {
        Page page = newPage("Connect", "Connect", "Pair assistants and keep keys on-device.", Ui.VIOLET);
        page.body.addView(assistantCard(), topParams(10));
        page.body.addView(clientsCard(), topParams(14));
        page.body.addView(keyCard(), topParams(14));
        page.body.addView(footer(), topParams(26));
        return page.scroll;
    }

    private View buildAuditPage() {
        Page page = newPage("Audit", "Audit", "A versioned record of local actions.", Ui.TEAL);
        page.body.addView(auditCard(), topParams(10));
        page.body.addView(auditViewerCard(), topParams(14));
        page.body.addView(footer(), topParams(26));
        return page.scroll;
    }

    private View buildSettingsPage() {
        Page page = newPage("Settings", "Settings", "Choose how LocalKey moves and behaves.", Ui.TEAL);
        page.body.addView(layoutCard(), topParams(10));
        page.body.addView(aboutCard(), topParams(14));
        page.body.addView(footer(), topParams(26));
        return page.scroll;
    }

    private Page newPage(String eyebrow, String title, String subtitle, int accent) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), Ui.dp(this, 34));
        scroll.addView(body);

        TextView eye = Ui.eyebrow(this, eyebrow);
        eye.setTextColor(accent);
        body.addView(eye);

        TextView heading = Ui.text(this, title, 27f, Ui.TEXT, Ui.sansBold());
        heading.setPadding(0, Ui.dp(this, 5), 0, 0);
        body.addView(heading);

        TextView sub = Ui.text(this, subtitle, 12.5f, Ui.MUTED, Ui.sans());
        sub.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 14));
        body.addView(sub);
        return new Page(scroll, body);
    }

    private LinearLayout statusCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 20), Ui.dp(this, 18), Ui.dp(this, 20), Ui.dp(this, 18));
        card.setBackground(Ui.gradient(this, Color.rgb(16, 34, 45), Color.rgb(10, 17, 28),
                Ui.withAlpha(Ui.TEAL, 58), 20));

        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        statusDot = Ui.circle(this, Ui.FAINT, 9);
        top.addView(statusDot);
        TextView eyebrow = Ui.eyebrow(this, "Server");
        eyebrow.setPadding(Ui.dp(this, 8), 0, 0, 0);
        top.addView(eyebrow);
        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
        statusPill = Ui.pill(this, "OFFLINE", Ui.FAINT,
                Ui.withAlpha(Ui.FAINT, 18), Ui.BORDER);
        top.addView(statusPill);
        card.addView(top);

        serverTitle = Ui.text(this, "Server stopped", 27f, Ui.TEXT, Ui.sansBold());
        serverTitle.setPadding(0, Ui.dp(this, 12), 0, 0);
        card.addView(serverTitle);

        serverMeta = Ui.text(this, "127.0.0.1:39401", 12.5f, Ui.MUTED, Ui.mono());
        serverMeta.setPadding(0, Ui.dp(this, 5), 0, 0);
        card.addView(serverMeta);

        startStopButton = Ui.button(this, "Start server", Ui.KIND_PRIMARY, Ui.TEAL);
        startStopButton.setOnClickListener(v -> {
            if (LocalKeyService.isRunning()) stopBridge();
            else startBridge();
        });
        LinearLayout.LayoutParams startParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        startParams.topMargin = Ui.dp(this, 17);
        card.addView(startStopButton, startParams);
        return card;
    }

    private LinearLayout readinessCard() {
        readinessPanel = new LinearLayout(this);
        readinessPanel.setOrientation(LinearLayout.VERTICAL);
        readinessPanel.setPadding(Ui.dp(this, 18), Ui.dp(this, 17), Ui.dp(this, 18), Ui.dp(this, 10));
        readinessPanel.setBackground(Ui.card(this, Ui.CARD, Ui.withAlpha(Ui.AMBER, 80), 20));

        LinearLayout titleRow = row();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.text(this, "Device readiness", 18f, Ui.TEXT, Ui.sansBold());
        titleRow.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        readinessCount = Ui.pill(this, "0/3 SETUP", Ui.AMBER,
                Ui.withAlpha(Ui.AMBER, 18), Ui.withAlpha(Ui.AMBER, 62));
        titleRow.addView(readinessCount);
        readinessPanel.addView(titleRow);

        readinessHint = Ui.text(this, "", 12f, Ui.MUTED, Ui.sans());
        readinessHint.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 2));
        readinessHint.setLineSpacing(0f, 1.12f);
        readinessPanel.addView(readinessHint);

        ReadinessRow file = addReadinessRow(readinessPanel, R.drawable.ic_folder, Ui.TEAL, "File access");
        fileState = file.state;
        fileAction = file.action;
        fileAction.setOnClickListener(v -> openAllFilesSettings());

        ReadinessRow notify = addReadinessRow(readinessPanel, R.drawable.ic_bell, Ui.AMBER, "Notifications");
        notifyState = notify.state;
        notifyAction = notify.action;
        notifyAction.setOnClickListener(v -> notificationAction());

        ReadinessRow battery = addReadinessRow(readinessPanel, R.drawable.ic_battery, Ui.VIOLET, "Battery optimization");
        batteryState = battery.state;
        batteryAction = battery.action;
        batteryAction.setOnClickListener(v -> batteryAction());
        return readinessPanel;
    }

    private ReadinessRow addReadinessRow(LinearLayout parent, int iconRes, int tint, String title) {
        if (parent.getChildCount() > 2) parent.addView(Ui.divider(this));
        LinearLayout row = row();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(this, 11), 0, Ui.dp(this, 11));
        row.addView(Ui.iconBox(this, iconRes, tint, 36, 18),
                new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        copy.addView(Ui.text(this, title, 14f, Ui.TEXT, Ui.sansMedium()));
        TextView state = Ui.text(this, "Checking…", 11.5f, Ui.MUTED, Ui.sans());
        state.setPadding(0, Ui.dp(this, 2), 0, 0);
        copy.addView(state);
        row.addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button action = Ui.button(this, "Manage", Ui.KIND_SECONDARY, tint, true);
        row.addView(action, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 38)));
        parent.addView(row);
        return new ReadinessRow(state, action);
    }

    private LinearLayout assistantCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 17), Ui.dp(this, 18), Ui.dp(this, 18));
        card.setBackground(Ui.gradient(this, Color.rgb(27, 21, 43), Color.rgb(14, 12, 24),
                Ui.withAlpha(Ui.VIOLET, 78), 20));

        card.addView(Ui.text(this, "Pair an assistant", 18f, Ui.TEXT, Ui.sansBold()));
        TextView description = Ui.text(this,
                "Create a single-use link. Each assistant gets its own encrypted key.",
                12.5f, Ui.MUTED, Ui.sans());
        description.setLineSpacing(0f, 1.12f);
        description.setPadding(0, Ui.dp(this, 5), 0, 0);
        card.addView(description);

        assistantSummary = Ui.text(this, "No assistants paired yet.", 12f, Ui.VIOLET, Ui.sansMedium());
        assistantSummary.setPadding(0, Ui.dp(this, 12), 0, 0);
        card.addView(assistantSummary);

        pairButton = Ui.button(this, "Pair assistant", Ui.KIND_PRIMARY, Ui.VIOLET, true);
        pairButton.setOnClickListener(v -> pair());
        LinearLayout.LayoutParams pairParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 44));
        pairParams.topMargin = Ui.dp(this, 14);
        card.addView(pairButton, pairParams);
        return card;
    }

    private LinearLayout clientsCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 17), Ui.dp(this, 18), Ui.dp(this, 16));
        card.setBackground(Ui.card(this, Ui.CARD, Ui.BORDER, 20));

        LinearLayout titleRow = row();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(Ui.text(this, "Paired clients", 18f, Ui.TEXT, Ui.sansBold()),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        clientsCount = Ui.pill(this, "0", Ui.VIOLET,
                Ui.withAlpha(Ui.VIOLET, 18), Ui.withAlpha(Ui.VIOLET, 62));
        titleRow.addView(clientsCount);
        card.addView(titleRow);

        TextView description = Ui.text(this, "Tap a client to revoke its access.",
                12f, Ui.MUTED, Ui.sans());
        description.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 7));
        card.addView(description);

        clientsContainer = new LinearLayout(this);
        clientsContainer.setOrientation(LinearLayout.VERTICAL);
        card.addView(clientsContainer);

        revokeAllButton = Ui.button(this, "Revoke all clients", Ui.KIND_DANGER, Ui.RED, true);
        revokeAllButton.setOnClickListener(v -> confirmRevokeAll());
        LinearLayout.LayoutParams revokeParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 42));
        revokeParams.topMargin = Ui.dp(this, 8);
        card.addView(revokeAllButton, revokeParams);
        return card;
    }

    private LinearLayout keyCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 17), Ui.dp(this, 18), Ui.dp(this, 18));
        card.setBackground(Ui.card(this, Ui.CARD, Ui.BORDER, 20));

        LinearLayout titleRow = row();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(Ui.text(this, "Legacy access key", 18f, Ui.TEXT, Ui.sansBold()),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        titleRow.addView(Ui.pill(this, "LEGACY", Ui.AMBER,
                Ui.withAlpha(Ui.AMBER, 18), Ui.withAlpha(Ui.AMBER, 62)));
        card.addView(titleRow);

        TextView description = Ui.text(this,
                "For clients that have not been paired. Rotating it does not affect paired clients.",
                12.5f, Ui.MUTED, Ui.sans());
        description.setLineSpacing(0f, 1.12f);
        description.setPadding(0, Ui.dp(this, 5), 0, 0);
        card.addView(description);

        TextView fingerprintLabel = Ui.section(this, "Fingerprint");
        fingerprintLabel.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 4));
        card.addView(fingerprintLabel);
        fingerprintView = Ui.text(this, "", 11.5f, Ui.MUTED, Ui.mono());
        fingerprintView.setTextIsSelectable(true);
        card.addView(fingerprintView);

        TextView keyLabel = Ui.section(this, "Key");
        keyLabel.setPadding(0, Ui.dp(this, 13), 0, Ui.dp(this, 5));
        card.addView(keyLabel);
        keyView = Ui.text(this, "", 13.5f, Ui.TEXT, Ui.mono());
        keyView.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        keyView.setBackground(Ui.inset(this, 12));
        keyView.setOnClickListener(v -> toggleReveal());
        card.addView(keyView);

        LinearLayout actions = row();
        actions.setPadding(0, Ui.dp(this, 13), 0, 0);
        revealAction = Ui.button(this, "Reveal", Ui.KIND_SECONDARY, Ui.TEAL, true);
        revealAction.setOnClickListener(v -> toggleReveal());
        actions.addView(revealAction, new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f));
        Button copy = Ui.button(this, "Copy", Ui.KIND_SECONDARY, Ui.TEAL, true);
        copy.setOnClickListener(v -> copyLegacyKey());
        LinearLayout.LayoutParams copyParams = new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f);
        copyParams.leftMargin = Ui.dp(this, 6);
        copyParams.rightMargin = Ui.dp(this, 6);
        actions.addView(copy, copyParams);
        Button rotate = Ui.button(this, "Rotate", Ui.KIND_DANGER, Ui.RED, true);
        rotate.setOnClickListener(v -> confirmRotate());
        actions.addView(rotate, new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f));
        card.addView(actions);
        return card;
    }

    private LinearLayout auditCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 17), Ui.dp(this, 18), Ui.dp(this, 18));
        card.setBackground(Ui.card(this, Ui.CARD, Ui.BORDER, 20));

        LinearLayout titleRow = row();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(Ui.text(this, "Versioned audit log", 18f, Ui.TEXT, Ui.sansBold()),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        titleRow.addView(Ui.pill(this, "SCHEMA " + EventLog.SCHEMA, Ui.TEAL,
                Ui.withAlpha(Ui.TEAL, 18), Ui.withAlpha(Ui.TEAL, 58)));
        card.addView(titleRow);

        auditSummary = Ui.text(this, "", 12f, Ui.MUTED, Ui.sans());
        auditSummary.setPadding(0, Ui.dp(this, 5), 0, 0);
        card.addView(auditSummary);

        LinearLayout actions = row();
        actions.setPadding(0, Ui.dp(this, 13), 0, 0);
        Button copy = Ui.button(this, "Copy visible", Ui.KIND_SECONDARY, Ui.TEAL, true);
        copy.setOnClickListener(v -> copyAudit());
        LinearLayout.LayoutParams copyParams = new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f);
        copyParams.rightMargin = Ui.dp(this, 8);
        actions.addView(copy, copyParams);
        Button export = Ui.button(this, "Export log", Ui.KIND_PRIMARY, Ui.TEAL, true);
        export.setOnClickListener(v -> exportLog());
        actions.addView(export, new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f));
        card.addView(actions);
        return card;
    }

    private LinearLayout auditViewerCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 15), Ui.dp(this, 16), Ui.dp(this, 16));
        card.setBackground(Ui.card(this, Ui.CARD, Ui.BORDER, 20));

        LinearLayout titleRow = row();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(Ui.text(this, "Recent events", 16f, Ui.TEXT, Ui.sansBold()),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        titleRow.addView(Ui.pill(this, "LATEST 80", Ui.FAINT,
                Ui.withAlpha(Ui.FAINT, 16), Ui.BORDER));
        card.addView(titleRow);

        auditText = Ui.text(this, "No events yet.", 9.5f, Ui.TEXT, Ui.mono());
        auditText.setTextIsSelectable(true);
        auditText.setLineSpacing(Ui.dp(this, 2), 1f);
        auditText.setPadding(Ui.dp(this, 12), Ui.dp(this, 11), Ui.dp(this, 12), Ui.dp(this, 11));
        auditText.setBackground(Ui.inset(this, 12));
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        textParams.topMargin = Ui.dp(this, 10);
        card.addView(auditText, textParams);
        return card;
    }

    private LinearLayout layoutCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 17), Ui.dp(this, 18), Ui.dp(this, 18));
        card.setBackground(Ui.card(this, Ui.CARD, Ui.BORDER, 20));

        LinearLayout titleRow = row();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(Ui.text(this, "Navigation layout", 18f, Ui.TEXT, Ui.sansBold()),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        String layoutPill = Flavor.LAYOUT_SWITCH ? "A / B" : Flavor.VARIANT;
        titleRow.addView(Ui.pill(this, "LAYOUT " + layoutPill, Ui.TEAL,
                Ui.withAlpha(Ui.TEAL, 18), Ui.withAlpha(Ui.TEAL, 58)));
        card.addView(titleRow);

        TextView description = Ui.text(this,
                Flavor.LAYOUT_SWITCH
                        ? "Choose how to move between the four LocalKey screens."
                        : "This build uses a fixed navigation shell. Install another variant to compare.",
                12.5f, Ui.MUTED, Ui.sans());
        description.setLineSpacing(0f, 1.12f);
        description.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 12));
        card.addView(description);

        if (layoutSwitchEnabled()) {
            card.addView(layoutChoice("A", "Bottom tabs", LAYOUT_TABS,
                    R.drawable.ic_home, Ui.TEAL));
            card.addView(layoutChoice("B", "Navigation drawer", LAYOUT_DRAWER,
                    R.drawable.ic_menu, Ui.VIOLET));
        } else if (isDrawerLayout()) {
            card.addView(layoutChoice("B", "Navigation drawer", LAYOUT_DRAWER,
                    R.drawable.ic_menu, Ui.VIOLET));
        } else {
            card.addView(layoutChoice("A", "Bottom tabs", LAYOUT_TABS,
                    R.drawable.ic_home, Ui.TEAL));
        }
        return card;
    }

    private View layoutChoice(String code, String title, String mode, int iconRes, int accent) {
        boolean selected = mode.equals(layoutMode);
        boolean enabled = layoutSwitchEnabled();

        LinearLayout row = row();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, 12), Ui.dp(this, 11), Ui.dp(this, 12), Ui.dp(this, 11));
        row.setBackground(selected
                ? Ui.card(this, Ui.withAlpha(accent, 18), Ui.withAlpha(accent, 72), 14)
                : Ui.card(this, Ui.CARD_DEEP, Ui.BORDER, 14));
        row.setClickable(enabled);
        row.setFocusable(enabled);
        row.setContentDescription(title);

        row.addView(Ui.iconBox(this, iconRes, selected ? accent : Ui.MUTED, 36, 18),
                new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(Ui.dp(this, 11), 0, Ui.dp(this, 6), 0);
        copy.addView(Ui.text(this, title, 14f, Ui.TEXT, Ui.sansMedium()));
        String detail = enabled
                ? "Layout " + code
                : "Layout " + code + " · fixed in this build";
        copy.addView(Ui.text(this, detail, 10.5f, Ui.MUTED, Ui.sans()));
        row.addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (selected) {
            row.addView(Ui.icon(this, R.drawable.ic_check, accent, 18),
                    new LinearLayout.LayoutParams(Ui.dp(this, 18), Ui.dp(this, 18)));
        }
        if (enabled) {
            row.setOnClickListener(v -> chooseLayout(mode));
        }
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = Ui.dp(this, 7);
        row.setLayoutParams(params);
        return row;
    }

    private void chooseLayout(String mode) {
        if (!layoutSwitchEnabled() || mode.equals(layoutMode)) return;
        getSharedPreferences(UI_PREFS, MODE_PRIVATE).edit()
                .putString(PREF_LAYOUT, mode).apply();
        JSONObject event = Json.obj();
        Json.put(event, "mode", mode);
        Json.put(event, "variant", Flavor.VARIANT);
        log.event("layout_changed", event);
        recreate();
    }

    private static boolean layoutSwitchEnabled() {
        return Flavor.LAYOUT_SWITCH;
    }

    private LinearLayout aboutCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 17), Ui.dp(this, 18), Ui.dp(this, 10));
        card.setBackground(Ui.card(this, Ui.CARD, Ui.BORDER, 20));

        card.addView(Ui.text(this, "About LocalKey", 18f, Ui.TEXT, Ui.sansBold()));
        TextView description = Ui.text(this,
                "Encrypted file access that never leaves your device.",
                12.5f, Ui.MUTED, Ui.sans());
        description.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 4));
        card.addView(description);

        addAboutRow(card, "Version", log.versionName());
        addAboutRow(card, "Variant", Flavor.VARIANT + " · "
                + (isDrawerLayout() ? "Navigation drawer" : "Bottom tabs"));
        addAboutRow(card, "Audit schema", String.valueOf(EventLog.SCHEMA));
        addAboutRow(card, "Package", getPackageName());
        return card;
    }

    private void addAboutRow(LinearLayout parent, String label, String value) {
        parent.addView(Ui.divider(this));
        LinearLayout row = row();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
        row.addView(Ui.text(this, label, 13f, Ui.MUTED, Ui.sans()));
        TextView valueView = Ui.text(this, value, 12.5f, Ui.TEXT, Ui.mono());
        valueView.setSingleLine(true);
        valueView.setEllipsize(TextUtils.TruncateAt.END);
        valueView.setGravity(Gravity.END);
        row.addView(valueView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        parent.addView(row);
    }

    private LinearLayout footer() {
        LinearLayout footer = row();
        footer.setGravity(Gravity.TOP);
        ImageView shield = Ui.icon(this, R.drawable.ic_shield, Ui.FAINT, 14);
        footer.addView(shield, new LinearLayout.LayoutParams(Ui.dp(this, 14), Ui.dp(this, 14)));
        TextView note = Ui.text(this,
                "Loopback only · AES-256-GCM · no secrets logged\n"
                        + "Android/data and Android/obb may remain restricted.",
                10.5f, Ui.FAINT, Ui.sans());
        note.setLineSpacing(Ui.dp(this, 3), 1f);
        note.setPadding(Ui.dp(this, 8), 0, 0, 0);
        footer.addView(note, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return footer;
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private LinearLayout.LayoutParams topParams(int topDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = Ui.dp(this, topDp);
        return params;
    }

    private static void hardenTouches(View view) {
        view.setFilterTouchesWhenObscured(true);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                hardenTouches(group.getChildAt(i));
            }
        }
    }

    private void hardenDialog(AlertDialog dialog) {
        if (dialog != null && dialog.getWindow() != null) {
            hardenTouches(dialog.getWindow().getDecorView());
        }
    }

    private void refresh() {
        boolean file = Environment.isExternalStorageManager();
        boolean notifications = notificationsReady();
        boolean battery = batteryReady();
        boolean running = LocalKeyService.isRunning();
        int clients = pairs.count();
        int ready = (file ? 1 : 0) + (notifications ? 1 : 0) + (battery ? 1 : 0);

        setDot(running ? Ui.GREEN : file ? Ui.FAINT : Ui.AMBER);
        if (running) {
            Ui.setPill(statusPill, "ONLINE", Ui.TEAL,
                    Ui.withAlpha(Ui.TEAL, 20), Ui.withAlpha(Ui.TEAL, 64));
            serverTitle.setText("Server running");
        } else {
            Ui.setPill(statusPill, "OFFLINE", Ui.FAINT,
                    Ui.withAlpha(Ui.FAINT, 18), Ui.BORDER);
            serverTitle.setText("Server stopped");
        }
        serverMeta.setText("127.0.0.1:" + LocalKeyService.PORT + "  ·  "
                + (clients == 1 ? "1 paired client" : clients + " paired clients"));

        if (running) {
            Ui.styleButton(this, startStopButton, "Stop server", Ui.KIND_DANGER, Ui.RED, false);
            startStopButton.setEnabled(true);
            startStopButton.setAlpha(1f);
        } else if (file) {
            Ui.styleButton(this, startStopButton, "Start server", Ui.KIND_PRIMARY, Ui.TEAL, false);
            startStopButton.setEnabled(true);
            startStopButton.setAlpha(1f);
        } else {
            Ui.styleButton(this, startStopButton, "File access required", Ui.KIND_MUTED, Ui.FAINT, false);
            startStopButton.setEnabled(false);
            startStopButton.setAlpha(0.55f);
        }

        Ui.setPill(readinessCount, ready + "/3 " + (ready == 3 ? "READY" : "SETUP"),
                ready == 3 ? Ui.TEAL : Ui.AMBER,
                Ui.withAlpha(ready == 3 ? Ui.TEAL : Ui.AMBER, 18),
                Ui.withAlpha(ready == 3 ? Ui.TEAL : Ui.AMBER, 62));
        readinessPanel.setBackground(Ui.card(this, Ui.CARD,
                ready == 3 ? Ui.withAlpha(Ui.TEAL, 68) : Ui.withAlpha(Ui.AMBER, 82), 20));
        readinessHint.setText(readinessHint(file, notifications, battery));

        if (file) {
            fileState.setText("Granted");
            fileState.setTextColor(Ui.GREEN);
            Ui.styleButton(this, fileAction, "Manage", Ui.KIND_SECONDARY, Ui.TEAL, true);
        } else {
            fileState.setText("Required for Start");
            fileState.setTextColor(Ui.AMBER);
            Ui.styleButton(this, fileAction, "Grant", Ui.KIND_PRIMARY, Ui.TEAL, true);
        }
        fileAction.setEnabled(true);
        fileAction.setAlpha(1f);

        boolean notificationPermission = hasNotificationPermission();
        if (notifications) {
            notifyState.setText("Allowed");
            notifyState.setTextColor(Ui.GREEN);
            Ui.styleButton(this, notifyAction, "Manage", Ui.KIND_SECONDARY, Ui.TEAL, true);
        } else if (!notificationPermission) {
            notifyState.setText(notificationPermissionPermanentlyDenied()
                    ? "Permission blocked" : "Permission needed");
            notifyState.setTextColor(Ui.AMBER);
            Ui.styleButton(this, notifyAction,
                    notificationPermissionPermanentlyDenied() ? "Settings" : "Allow",
                    Ui.KIND_SECONDARY, Ui.AMBER, true);
        } else {
            notifyState.setText("Blocked");
            notifyState.setTextColor(Ui.AMBER);
            Ui.styleButton(this, notifyAction, "Settings", Ui.KIND_SECONDARY, Ui.AMBER, true);
        }
        notifyAction.setEnabled(true);
        notifyAction.setAlpha(1f);

        if (battery) {
            batteryState.setText("Unrestricted");
            batteryState.setTextColor(Ui.GREEN);
            Ui.styleButton(this, batteryAction, "Manage", Ui.KIND_SECONDARY, Ui.TEAL, true);
        } else {
            batteryState.setText("Optimized");
            batteryState.setTextColor(Ui.AMBER);
            Ui.styleButton(this, batteryAction, "Allow", Ui.KIND_SECONDARY, Ui.AMBER, true);
        }
        batteryAction.setEnabled(true);
        batteryAction.setAlpha(1f);

        if (!running) {
            assistantSummary.setText("Start the server to create a pairing link.");
            assistantSummary.setTextColor(Ui.MUTED);
        } else if (clients == 0) {
            assistantSummary.setText("No assistants paired yet.");
            assistantSummary.setTextColor(Ui.VIOLET);
        } else {
            assistantSummary.setText(clients == 1
                    ? "1 assistant paired · keys stay on this device."
                    : clients + " assistants paired · keys stay on this device.");
            assistantSummary.setTextColor(Ui.VIOLET);
        }
        pairButton.setEnabled(running);
        pairButton.setAlpha(running ? 1f : 0.45f);

        auditSummary.setText(log.size() + " events  ·  newest first");
        if (activePage == PAGE_AUDIT) updateAuditView();

        String signature = file + "|" + notifications + "|" + battery;
        if (lastReadiness != null && !signature.equals(lastReadiness)) {
            JSONObject event = Json.obj();
            Json.put(event, "fileAccess", file);
            Json.put(event, "notifications", notifications);
            Json.put(event, "battery", battery);
            log.event("readiness_changed", event);
        }
        lastReadiness = signature;

        refreshClients();
    }

    private void refreshClients() {
        if (clientsContainer == null) return;
        JSONArray clients = pairs.list();
        int count = clients.length();
        clientsCount.setText(count == 1 ? "1 CLIENT" : count + " CLIENTS");
        clientsContainer.removeAllViews();
        if (count == 0) {
            TextView empty = Ui.text(this, "No clients yet. Pair one from above.",
                    12f, Ui.FAINT, Ui.sans());
            empty.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            clientsContainer.addView(empty);
        } else {
            for (int i = 0; i < count; i++) {
                JSONObject client = clients.optJSONObject(i);
                if (client == null) continue;
                if (clientsContainer.getChildCount() > 0) clientsContainer.addView(Ui.divider(this));
                clientsContainer.addView(clientRow(client));
            }
        }
        revokeAllButton.setEnabled(count > 0);
        revokeAllButton.setAlpha(count > 0 ? 1f : 0.4f);
    }

    private View clientRow(JSONObject client) {
        LinearLayout row = row();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        row.setClickable(true);
        row.setFocusable(true);
        row.addView(Ui.iconBox(this, R.drawable.ic_key, Ui.VIOLET, 34, 17),
                new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34)));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(Ui.dp(this, 11), 0, Ui.dp(this, 8), 0);
        String name = client.optString("name");
        if (name.isEmpty()) name = "Assistant";
        final String displayName = name;
        TextView title = Ui.text(this, name, 13.5f, Ui.TEXT, Ui.sansMedium());
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        copy.addView(title);

        String id = client.optString("id");
        String fp = client.optString("fp");
        String meta = (id.length() > 8 ? id.substring(0, 8) : id)
                + " · " + (fp.length() > 12 ? fp.substring(0, 12) : fp);
        TextView detail = Ui.text(this, meta, 10f, Ui.MUTED, Ui.mono());
        detail.setSingleLine(true);
        detail.setEllipsize(TextUtils.TruncateAt.END);
        detail.setPadding(0, Ui.dp(this, 2), 0, 0);
        copy.addView(detail);
        row.addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        row.addView(Ui.icon(this, R.drawable.ic_chevron, Ui.FAINT, 15),
                new LinearLayout.LayoutParams(Ui.dp(this, 15), Ui.dp(this, 15)));
        row.setOnClickListener(v -> confirmRevokeClient(displayName, id));
        return row;
    }

    private void updateAuditView() {
        if (auditText == null) return;
        JSONArray events = log.tail(80);
        if (events.length() == 0) {
            auditText.setText("No events yet.");
            return;
        }
        StringBuilder out = new StringBuilder();
        for (int i = events.length() - 1; i >= 0; i--) {
            JSONObject entry = events.optJSONObject(i);
            if (entry == null) continue;
            out.append(entry.toString()).append('\n');
        }
        auditText.setText(out.toString().trim());
    }

    private String readinessHint(boolean file, boolean notifications, boolean battery) {
        if (!file) return "File access is required to start the server. Grant it to continue.";
        if (!notifications && !battery) return "File access is ready. Finish notifications and battery for reliable everyday use.";
        if (!notifications) return "File access is ready. Allow notifications so service status stays visible.";
        if (!battery) return "File access is ready. Allow unrestricted battery for reliable background service.";
        return "Everything LocalKey needs is ready.";
    }

    private void setDot(int color) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(color);
        statusDot.setBackground(drawable);
    }

    private void updateKeyView() {
        byte[] key = keys.getLegacyKey();
        try {
            String encoded = Crypto.b64(key);
            fingerprintView.setText("SHA-256  " + Crypto.fingerprint(key));
            if (revealed) {
                keyView.setText(encoded);
                revealAction.setText("Hide");
            } else {
                keyView.setText(mask(encoded));
                revealAction.setText("Reveal");
            }
        } finally {
            Crypto.zero(key);
        }
    }

    private void toggleReveal() {
        revealed = !revealed;
        if (revealed) logUi("legacy_key_revealed");
        updateKeyView();
    }

    private void openAllFilesSettings() {
        logUi("file_access_settings_opened");
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
        }
    }

    private void startBridge() {
        if (!Environment.isExternalStorageManager()) {
            toast("Grant All files access first");
            openAllFilesSettings();
            return;
        }
        logUi("server_start_requested");
        startForegroundService(new Intent(this, LocalKeyService.class)
                .setAction(LocalKeyService.ACTION_START));
        handler.postDelayed(this::refresh, 500);
    }

    private void stopBridge() {
        logUi("server_stop_requested");
        stopService(new Intent(this, LocalKeyService.class));
        handler.postDelayed(this::refresh, 300);
    }

    private void notificationAction() {
        boolean permission = hasNotificationPermission();
        if (!permission) {
            SharedPreferences prefs = getSharedPreferences(UI_PREFS, MODE_PRIVATE);
            boolean asked = prefs.getBoolean(PREF_NOTIFICATION_ASKED, false);
            if (asked && !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                openNotificationSettings();
                return;
            }
            prefs.edit().putBoolean(PREF_NOTIFICATION_ASKED, true).apply();
            logUi("notification_permission_requested");
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, RC_NOTIFICATIONS);
            return;
        }
        openNotificationSettings();
    }

    private void openNotificationSettings() {
        logUi("notification_settings_opened");
        try {
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void batteryAction() {
        if (batteryReady()) {
            openBatterySettings();
            return;
        }
        logUi("battery_exemption_requested");
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            openBatterySettings();
        }
    }

    private void openBatterySettings() {
        logUi("battery_settings_opened");
        try {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private boolean hasNotificationPermission() {
        return Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean notificationsReady() {
        if (!hasNotificationPermission()) return false;
        NotificationManager manager = getSystemService(NotificationManager.class);
        return manager != null && manager.areNotificationsEnabled();
    }

    private boolean notificationPermissionPermanentlyDenied() {
        return Build.VERSION.SDK_INT >= 33
                && !hasNotificationPermission()
                && getSharedPreferences(UI_PREFS, MODE_PRIVATE)
                .getBoolean(PREF_NOTIFICATION_ASKED, false)
                && !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS);
    }

    private boolean batteryReady() {
        PowerManager manager = getSystemService(PowerManager.class);
        return manager != null && manager.isIgnoringBatteryOptimizations(getPackageName());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RC_NOTIFICATIONS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            JSONObject event = Json.obj();
            Json.put(event, "granted", granted);
            log.event("notification_permission_result", event);
            toast(granted ? "Notifications allowed" : "Notifications stay off; you can enable them in Settings.");
            refresh();
        }
    }

    private void pair() {
        if (!LocalKeyService.isRunning()) {
            toast("Start the bridge first");
            return;
        }
        try {
            PairingManager manager = new PairingManager(keys, pairs, log);
            PairingManager.Link link = manager.createLink();
            String expires = DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(link.expires));
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Pair assistant")
                    .setMessage("Send this single-use link to the client. It expires at " + expires
                            + ".\n\n" + link.uri
                            + "\n\nAnyone with this link can pair while it is active. Do not post it publicly.")
                    .setPositiveButton("Copy link", (d, which) -> {
                        copy("LocalKey pairing link", link.uri, "Pairing link copied");
                        logUi("pairing_link_copied");
                    })
                    .setNegativeButton("Close", null)
                    .show();
            hardenDialog(dialog);
        } catch (Exception e) {
            toast("Could not create pairing link");
            log.error("pairing", "could not create link");
        }
    }

    private void confirmRevokeClient(String name, String id) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Revoke client?")
                .setMessage(name + " will lose access immediately.")
                .setPositiveButton("Revoke", (d, which) -> {
                    if (LocalKeyService.isRunning()) {
                        startService(new Intent(this, LocalKeyService.class)
                                .setAction(LocalKeyService.ACTION_REVOKE_CLIENT)
                                .putExtra(LocalKeyService.EXTRA_CLIENT_ID, id));
                    } else {
                        pairs.revoke(id);
                    }
                    log.event("ui_action", Json.put(Json.obj(), "action", "client_revoked"));
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
        hardenDialog(dialog);
    }

    private void confirmRevokeAll() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Revoke all clients?")
                .setMessage("All paired clients and the legacy key will be invalidated. The server will restart with a new key.")
                .setPositiveButton("Revoke all", (d, which) -> {
                    if (LocalKeyService.isRunning()) {
                        startService(new Intent(this, LocalKeyService.class)
                                .setAction(LocalKeyService.ACTION_REVOKE_ALL));
                    } else {
                        new PairingManager(keys, pairs, log).invalidate();
                        pairs.revokeAll();
                        keys.deleteClientKek();
                        keys.rotateLegacyKey();
                        updateKeyView();
                    }
                    handler.postDelayed(MainActivity.this::updateKeyView, 900);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
        hardenDialog(dialog);
    }

    private void confirmRotate() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Rotate legacy key?")
                .setMessage("Clients using the legacy key will stop working. Paired clients are unaffected.")
                .setPositiveButton("Rotate", (d, which) -> {
                    if (LocalKeyService.isRunning()) {
                        startService(new Intent(this, LocalKeyService.class)
                                .setAction(LocalKeyService.ACTION_ROTATE));
                    } else {
                        keys.rotateLegacyKey();
                    }
                    logUi("legacy_key_rotated");
                    updateKeyView();
                    handler.postDelayed(MainActivity.this::updateKeyView, 900);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
        hardenDialog(dialog);
    }

    private void copyLegacyKey() {
        byte[] key = keys.getLegacyKey();
        try {
            copy("LocalKey legacy key", Crypto.b64(key), "Legacy key copied");
            logUi("legacy_key_copied");
        } finally {
            Crypto.zero(key);
        }
    }

    private void copyAudit() {
        String text = auditText == null ? "" : auditText.getText().toString().trim();
        if (text.isEmpty()) text = "No events yet.";
        copy("LocalKey audit log", text, "Audit log copied");
        logUi("log_copied");
    }

    private void exportLog() {
        try {
            File dir = new File(Environment.getExternalStorageDirectory(), "Download/LocalKey");
            String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
            String version = log.versionName().replaceAll("[^0-9A-Za-z._-]", "_");
            File target = new File(dir, "localkey-" + version + "-" + stamp + ".jsonl");
            int count = log.export(target);
            JSONObject event = Json.obj();
            Json.put(event, "version", log.versionName());
            Json.put(event, "events", count);
            Json.put(event, "file", target.getName());
            log.event("log_exported", event);
            toast("Exported " + count + " events to " + target.getAbsolutePath());
        } catch (IOException e) {
            toast("Could not export log");
        }
    }

    private void logUi(String action) {
        JSONObject event = Json.obj();
        Json.put(event, "action", action);
        log.event("ui_action", event);
    }

    private void copy(String label, String value, String message) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText(label, value));
        toast(message);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private static String mask(String value) {
        if (value.length() <= 12) return value;
        return value.substring(0, 6) + "..." + value.substring(value.length() - 4);
    }

    private static final class ReadinessRow {
        final TextView state;
        final Button action;

        ReadinessRow(TextView state, Button action) {
            this.state = state;
            this.action = action;
        }
    }

    private static final class Page {
        final ScrollView scroll;
        final LinearLayout body;

        Page(ScrollView scroll, LinearLayout body) {
            this.scroll = scroll;
            this.body = body;
        }
    }

    private static final class NavBinding {
        final View container;
        final ImageView icon;
        final TextView label;
        final int page;

        NavBinding(View container, ImageView icon, TextView label, int page) {
            this.container = container;
            this.icon = icon;
            this.label = label;
            this.page = page;
        }
    }
}

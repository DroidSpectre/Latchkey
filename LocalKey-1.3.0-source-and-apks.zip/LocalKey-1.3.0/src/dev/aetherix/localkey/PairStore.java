package dev.aetherix.localkey;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.GeneralSecurityException;

public final class PairStore {
    private static final String PREFS = "localkey-pairing";
    private static final String CLIENTS = "clients";
    private static final int MAX_CLIENTS = 128;
    private static final Object LOCK = new Object();

    public static final class Error extends Exception {
        private static final long serialVersionUID = 1L;
        public final String code;

        public Error(String code, String message) {
            super(message);
            this.code = code;
        }
    }

    private final SharedPreferences prefs;
    private final KeyStoreManager keys;
    private final EventLog log;

    public PairStore(Context context, KeyStoreManager keys) {
        this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.keys = keys;
        this.log = EventLog.get(context);
    }

    public JSONObject issue(String id, String name, byte[] key) throws Error {
        if (id == null || !id.matches("[a-f0-9]{16,64}")) {
            throw new Error("bad_client", "invalid client id");
        }
        if (name == null || name.isEmpty() || name.length() > 64) {
            throw new Error("bad_client", "invalid client name");
        }
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c < 0x20 || c > 0x7e) throw new Error("bad_client", "invalid client name");
        }

        synchronized (LOCK) {
            JSONArray clients = read();
            if (clients.length() >= MAX_CLIENTS) {
                throw new Error("client_limit", "too many paired clients");
            }
            for (int i = 0; i < clients.length(); i++) {
                JSONObject client = clients.optJSONObject(i);
                if (client != null && id.equals(client.optString("id"))) {
                    throw new Error("client_exists", "client id already paired");
                }
            }
            String wrapped;
            try {
                wrapped = keys.wrapClientKey(id, key);
            } catch (GeneralSecurityException e) {
                throw new Error("keystore_unavailable", "cannot store client key");
            }
            JSONObject record = Json.put(Json.put(Json.put(Json.put(Json.put(Json.obj(),
                    "id", id),
                    "name", name),
                    "fp", Crypto.fingerprint(key)),
                    "created", System.currentTimeMillis()),
                    "wrapped", wrapped);
            clients.put(record);
            write(clients);
            return record;
        }
    }

    public byte[] getKey(String id) {
        if (id == null || !id.matches("[a-f0-9]{16,64}")) return null;
        synchronized (LOCK) {
            JSONArray clients = read();
            for (int i = 0; i < clients.length(); i++) {
                JSONObject client = clients.optJSONObject(i);
                if (client == null || !id.equals(client.optString("id"))) continue;
                try {
                    byte[] key = keys.unwrapClientKey(id, client.optString("wrapped"));
                    if (key.length == Crypto.KEY_BYTES) return key;
                    Crypto.zero(key);
                } catch (Exception e) {
                    log.warn("pairing", "client key unwrap failed; removing client");
                }
                clients.remove(i);
                write(clients);
                return null;
            }
            return null;
        }
    }

    public JSONArray list() {
        synchronized (LOCK) {
            JSONArray source = read();
            JSONArray out = Json.arr();
            for (int i = 0; i < source.length(); i++) {
                JSONObject client = source.optJSONObject(i);
                if (client == null) continue;
                JSONObject item = Json.put(Json.put(Json.put(Json.put(Json.obj(),
                        "id", client.optString("id")),
                        "name", client.optString("name")),
                        "fp", client.optString("fp")),
                        "created", client.optLong("created"));
                out.put(item);
            }
            return out;
        }
    }

    public int count() {
        synchronized (LOCK) {
            return read().length();
        }
    }

    public boolean revoke(String id) {
        synchronized (LOCK) {
            JSONArray clients = read();
            for (int i = 0; i < clients.length(); i++) {
                JSONObject client = clients.optJSONObject(i);
                if (client != null && id.equals(client.optString("id"))) {
                    clients.remove(i);
                    write(clients);
                    log.info("pairing", "client revoked");
                    return true;
                }
            }
            return false;
        }
    }

    public int revokeAll() {
        synchronized (LOCK) {
            JSONArray clients = read();
            int count = clients.length();
            write(Json.arr());
            if (count > 0) log.info("pairing", "all clients revoked");
            return count;
        }
    }

    private JSONArray read() {
        String raw = prefs.getString(CLIENTS, null);
        if (raw == null) return Json.arr();
        try {
            JSONArray value = new JSONArray(raw);
            return value;
        } catch (JSONException e) {
            log.warn("pairing", "pairing store corrupted; clearing");
            prefs.edit().remove(CLIENTS).apply();
            return Json.arr();
        }
    }

    private void write(JSONArray clients) {
        if (clients.length() == 0) {
            prefs.edit().remove(CLIENTS).apply();
        } else {
            prefs.edit().putString(CLIENTS, clients.toString()).apply();
        }
    }
}

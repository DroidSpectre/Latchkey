package dev.aetherix.localkey;

import android.net.Uri;
import android.os.Build;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

public final class PairingManager {
    public static final long TTL_MS = 120000;
    private static final long WINDOW_MS = 60000;
    private static final int MAX_FAILURES = 5;
    private static final Object PENDING_LOCK = new Object();

    private static Pending pending;

    private static final class Pending {
        final byte[] hash;
        final long expires;
        long windowStart;
        int failures;

        Pending(byte[] hash, long expires) {
            this.hash = hash;
            this.expires = expires;
            this.windowStart = System.currentTimeMillis();
        }
    }

    public static final class Link {
        public final String uri;
        public final long expires;

        Link(String uri, long expires) {
            this.uri = uri;
            this.expires = expires;
        }
    }

    public static final class Result {
        public final int status;
        public final JSONObject body;

        Result(int status, JSONObject body) {
            this.status = status;
            this.body = body;
        }
    }

    private final KeyStoreManager keys;
    private final PairStore pairs;
    private final EventLog log;

    public PairingManager(KeyStoreManager keys, PairStore pairs, EventLog log) {
        this.keys = keys;
        this.pairs = pairs;
        this.log = log;
    }

    public Link createLink() throws Exception {
        String token = Crypto.b64(Crypto.random(32));
        long expires = System.currentTimeMillis() + TTL_MS;
        byte[] hash = Crypto.sha256(token);
        synchronized (PENDING_LOCK) {
            pending = new Pending(hash, expires);
        }

        String fingerprint = keys.fingerprint();
        String hostName = safeName(Build.MODEL);
        String uri = new Uri.Builder()
                .scheme("localkey")
                .authority("pair")
                .appendQueryParameter("v", "1")
                .appendQueryParameter("scope", "loopback")
                .appendQueryParameter("host", "127.0.0.1")
                .appendQueryParameter("port", String.valueOf(LocalKeyService.PORT))
                .appendQueryParameter("id", keys.hostId())
                .appendQueryParameter("name", hostName)
                .appendQueryParameter("fp", fingerprint)
                .appendQueryParameter("tok", token)
                .appendQueryParameter("exp", String.valueOf(expires))
                .build()
                .toString();
        log.event("pair_link_created", Json.put(Json.obj(), "expires", expires));
        return new Link(uri, expires);
    }

    public Result pair(String body) {
        JSONObject request;
        try {
            request = new JSONObject(body);
        } catch (JSONException e) {
            return error(400, "bad_request", "invalid JSON");
        }

        String token;
        try {
            if (request.optInt("v", 0) != 1) throw new JSONException("bad version");
            token = Json.str(request, "token");
        } catch (JSONException e) {
            return error(400, "bad_request", "missing token");
        }
        if (token.length() < 20 || token.length() > 128) {
            return error(401, "pairing_denied", "pairing denied");
        }

        String clientId = "";
        String clientName = "";
        JSONObject client = request.optJSONObject("client");
        if (client != null) {
            clientId = client.optString("id", "");
            clientName = client.optString("name", "");
        }
        if (clientId.isEmpty()) clientId = Crypto.hex(Crypto.random(16));
        if (clientName.isEmpty()) clientName = "client";
        clientName = safeName(clientName);
        if (!clientId.matches("[a-f0-9]{16,64}")
                || clientName.isEmpty()
                || clientName.length() > 64) {
            return error(400, "bad_client", "invalid client");
        }

        byte[] presented = Crypto.sha256(token);
        try {
            synchronized (PENDING_LOCK) {
                long now = System.currentTimeMillis();
                if (pending == null) {
                    return error(401, "pairing_not_active", "no active pairing link");
                }
                if (now >= pending.expires) {
                    clearPending();
                    return error(401, "pairing_expired", "pairing link expired");
                }
                if (now - pending.windowStart > WINDOW_MS) {
                    pending.windowStart = now;
                    pending.failures = 0;
                }
                if (pending.failures >= MAX_FAILURES) {
                    return error(429, "pairing_locked", "too many pairing failures");
                }
                if (!Crypto.constantTimeEquals(presented, pending.hash)) {
                    pending.failures++;
                    if (pending.failures >= MAX_FAILURES) {
                        pending.windowStart = now;
                    }
                    log.warn("pairing", "pairing attempt failed");
                    sleepQuietly(350);
                    if (pending.failures >= MAX_FAILURES) {
                        return error(429, "pairing_locked", "too many pairing failures");
                    }
                    return error(401, "pairing_denied", "pairing denied");
                }

                clearPending();
                byte[] key = Crypto.random(Crypto.KEY_BYTES);
                boolean issued = false;
                try {
                    JSONObject record = pairs.issue(clientId, clientName, key);
                    issued = true;
                    byte[] pairKey = Crypto.sha256(token);
                    byte[] aad = ("LOCALKEY/PAIR/1|" + clientId).getBytes(StandardCharsets.UTF_8);
                    try {
                        String wrapped = Crypto.b64(Crypto.encrypt(pairKey, aad, key));
                        JSONObject response = Json.obj();
                        Json.put(response, "v", 1);
                        Json.put(response, "ok", true);
                        Json.put(response, "clientId", clientId);
                        Json.put(response, "clientName", clientName);
                        Json.put(response, "key", wrapped);
                        Json.put(response, "fingerprint", record.optString("fp"));
                        Json.put(response, "serverTime", System.currentTimeMillis());
                        JSONObject event = Json.obj();
                        Json.put(event, "client", clientId);
                        Json.put(event, "name", clientName);
                        log.event("pair_success", event);
                        return new Result(200, response);
                    } finally {
                        Crypto.zero(pairKey);
                        Crypto.zero(aad);
                    }
                } catch (PairStore.Error e) {
                    log.warn("pairing", e.code);
                    int status = e.code.equals("client_exists") ? 409
                            : e.code.equals("client_limit") ? 429 : 500;
                    return error(status, e.code, e.getMessage());
                } catch (Exception e) {
                    if (issued) pairs.revoke(clientId);
                    log.error("pairing", "pairing failed");
                    return error(500, "pairing_failed", "pairing failed");
                } finally {
                    Crypto.zero(key);
                }
            }
        } finally {
            Crypto.zero(presented);
        }
    }

    public boolean isActive() {
        synchronized (PENDING_LOCK) {
            return pending != null && System.currentTimeMillis() < pending.expires;
        }
    }

    public void invalidate() {
        synchronized (PENDING_LOCK) {
            clearPending();
        }
    }

    private static void clearPending() {
        if (pending != null) {
            Crypto.zero(pending.hash);
            pending = null;
        }
    }

    private static Result error(int status, String code, String message) {
        JSONObject body = Json.obj();
        Json.put(body, "v", 1);
        Json.put(body, "ok", false);
        Json.put(body, "error", code);
        Json.put(body, "message", message);
        return new Result(status, body);
    }

    private static String safeName(String value) {
        if (value == null) return "android";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < value.length() && out.length() < 48; i++) {
            char c = value.charAt(i);
            if (c >= 0x20 && c <= 0x7e) out.append(c);
        }
        return out.length() == 0 ? "android" : out.toString();
    }

    private static void sleepQuietly(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

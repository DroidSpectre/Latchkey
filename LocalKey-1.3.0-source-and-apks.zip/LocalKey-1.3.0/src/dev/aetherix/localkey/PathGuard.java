package dev.aetherix.localkey;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

public final class PathGuard {
    public static final int MAX_PATH = 4096;

    private final File root;

    public PathGuard(File root) throws IOException {
        this.root = root.getCanonicalFile();
    }

    public File root() {
        return root;
    }

    public File resolve(String path) throws IOException, SecurityException {
        if (path == null) throw new SecurityException("missing path");
        if (path.length() > MAX_PATH) throw new SecurityException("path too long");
        if (path.indexOf('\0') >= 0) throw new SecurityException("path contains NUL");

        File candidate;
        if (path.isEmpty()) {
            candidate = root;
        } else if (path.startsWith("/")) {
            candidate = new File(path);
        } else {
            candidate = new File(root, path);
        }

        File canonical = candidate.getCanonicalFile();
        String rootPath = root.getPath();
        String candidatePath = canonical.getPath();
        if (!candidatePath.equals(rootPath) && !candidatePath.startsWith(rootPath + File.separator)) {
            throw new SecurityException("path escapes shared storage");
        }
        return canonical;
    }

    public String relative(File file) {
        Path rootPath = root.toPath();
        Path filePath = file.toPath();
        String value = rootPath.relativize(filePath).toString();
        return value.replace(File.separatorChar, '/');
    }
}

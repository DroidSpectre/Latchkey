package dev.aetherix.localkey;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public final class RpcHandler {
    public static final class AuthException extends Exception {
        private static final long serialVersionUID = 1L;
    }

    private static final long CLOCK_SKEW_MS = 300000;
    private static final int MAX_SEEN = 16384;
    private static final byte[] LEGACY_AAD = "LOCALKEY/1".getBytes(StandardCharsets.UTF_8);

    private final PairStore pairs;
    private final FileApi files;
    private final EventLog log;
    private final byte[] legacyKey;
    private final LinkedHashMap<String, Long> seen = new LinkedHashMap<String, Long>(256, 0.75f, false) {
        private static final long serialVersionUID = 1L;

        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Long> eldest) {
            return size() > MAX_SEEN;
        }
    };
    private final AtomicLong requests = new AtomicLong();

    public RpcHandler(KeyStoreManager keys, PairStore pairs, FileApi files, EventLog log) {
        this.pairs = pairs;
        this.files = files;
        this.log = log;
        this.legacyKey = keys.getLegacyKey();
    }

    public long requests() {
        return requests.get();
    }

    public int clientCount() {
        return pairs.count();
    }

    public String fingerprint() {
        return Crypto.fingerprint(legacyKey);
    }

    public void close() {
        Crypto.zero(legacyKey);
    }

    public byte[] handle(byte[] body, String clientId) throws AuthException {
        long started = System.currentTimeMillis();
        byte[] key = null;
        byte[] aad;
        String clientLabel = clientId == null ? "legacy" : safeClient(clientId);
        JSONObject details = Json.obj();

        try {
            if (clientId != null) {
                key = pairs.getKey(clientId);
                if (key == null) {
                    log.event("rpc_auth_failed", authFields(clientLabel, "unknown_client"));
                    throw new AuthException();
                }
                aad = ("LOCALKEY/1|client:" + clientId).getBytes(StandardCharsets.UTF_8);
            } else {
                key = legacyKey.clone();
                aad = LEGACY_AAD;
            }

            byte[] plaintext;
            try {
                plaintext = Crypto.decrypt(key, aad, body);
            } catch (Exception e) {
                log.event("rpc_auth_failed", authFields(clientLabel, "decrypt_failed"));
                throw new AuthException();
            }

            String op = "";
            String path = "";
            boolean ok = false;
            boolean replay = false;
            String code = "";
            try {
                JSONObject request = new JSONObject(new String(plaintext, StandardCharsets.UTF_8));
                op = safeOp(request.optString("op", ""));
                path = safePath(request.optString("path", request.optString("from", "")));
                details = safeArgs(request);
                String id = request.optString("id", "");
                if (!validId(id)) {
                    code = "bad_request";
                    return encrypt(key, aad, error(null, "bad_request", "invalid request id"));
                }
                if (request.optInt("v", 0) != 1) {
                    code = "bad_request";
                    return encrypt(key, aad, error(id, "bad_request", "unsupported protocol version"));
                }
                long ts = request.optLong("ts", 0);
                long now = System.currentTimeMillis();
                if (ts <= 0 || Math.abs(now - ts) > CLOCK_SKEW_MS) {
                    code = "stale";
                    return encrypt(key, aad, error(id, "stale", "timestamp outside replay window"));
                }
                if (remember(clientLabel + "|" + id)) {
                    code = "replay";
                    replay = true;
                    return encrypt(key, aad, error(id, "replay", "replayed request"));
                }

                JSONObject result = dispatch(request, op);
                ok = true;
                requests.incrementAndGet();
                summarize(details, result);
                JSONObject response = Json.obj();
                Json.put(response, "v", 1);
                Json.put(response, "ok", true);
                Json.put(response, "id", id);
                Json.put(response, "serverTime", System.currentTimeMillis());
                Json.put(response, "result", result);
                return encrypt(key, aad, response);
            } catch (ProtocolError e) {
                code = e.code;
                return encrypt(key, aad, error(e.id, e.code, e.getMessage()));
            } catch (FileApi.Error e) {
                code = e.code;
                return encrypt(key, aad, error(currentId(plaintext), e.code, e.getMessage()));
            } catch (JSONException e) {
                code = "bad_request";
                return encrypt(key, aad, error(currentId(plaintext), "bad_request", "invalid JSON"));
            } catch (IllegalArgumentException e) {
                code = "bad_request";
                return encrypt(key, aad, error(currentId(plaintext), "bad_request", "invalid argument"));
            } catch (Exception e) {
                code = "io_error";
                log.error("rpc", "request failed");
                return encrypt(key, aad, error(currentId(plaintext), "io_error", "request failed"));
            } finally {
                Crypto.zero(plaintext);
                JSONObject event = Json.obj();
                Json.put(event, "client", clientLabel);
                Json.put(event, "op", op);
                Json.put(event, "path", path);
                Json.put(event, "ok", ok);
                Json.put(event, "code", code);
                Json.put(event, "ms", System.currentTimeMillis() - started);
                if (replay) Json.put(event, "replay", true);
                merge(event, details);
                log.event("rpc", event);
            }
        } finally {
            Crypto.zero(key);
        }
    }

    private JSONObject dispatch(JSONObject request, String op) throws ProtocolError, FileApi.Error, JSONException {
        switch (op) {
            case "ping":
                return Json.put(Json.obj(), "time", System.currentTimeMillis());
            case "info": {
                JSONObject info = files.info();
                Json.put(info, "clients", pairs.count());
                Json.put(info, "fingerprint", fingerprint());
                Json.put(info, "requests", requests.get());
                return info;
            }
            case "list":
                return files.list(required(request, "path"), request.optInt("limit", 1000));
            case "stat":
                return files.stat(required(request, "path"));
            case "read":
                return files.read(required(request, "path"),
                        request.optLong("offset", 0),
                        request.optInt("length", FileApi.MAX_CHUNK));
            case "write": {
                String encoded = required(request, "data");
                byte[] data;
                try {
                    data = Base64.getDecoder().decode(encoded);
                } catch (IllegalArgumentException e) {
                    throw new ProtocolError("bad_request", "invalid base64 data", request.optString("id"));
                }
                try {
                    return files.write(required(request, "path"),
                            request.optLong("offset", 0),
                            data,
                            request.optBoolean("truncate", false));
                } finally {
                    Crypto.zero(data);
                }
            }
            case "mkdir":
                return files.mkdir(required(request, "path"), request.optBoolean("parents", false));
            case "move": {
                String from = request.optString("path", request.optString("from", ""));
                if (from.isEmpty()) throw new ProtocolError("bad_request", "missing path", request.optString("id"));
                return files.move(from, required(request, "to"));
            }
            case "copy": {
                String from = request.optString("path", request.optString("from", ""));
                if (from.isEmpty()) throw new ProtocolError("bad_request", "missing path", request.optString("id"));
                return files.copy(from, required(request, "to"));
            }
            case "delete":
                return files.delete(required(request, "path"), request.optBoolean("recursive", false));
            case "search":
                return files.search(required(request, "path"),
                        required(request, "query"),
                        request.optInt("maxDepth", 8),
                        request.optInt("limit", 200));
            case "hash":
                return files.hash(required(request, "path"));
            case "logs": {
                JSONArray entries = log.tail(request.optInt("limit", 100));
                JSONObject result = Json.obj();
                Json.put(result, "entries", entries);
                Json.put(result, "count", entries.length());
                return result;
            }
            default:
                throw new ProtocolError("unsupported", "unknown operation", request.optString("id"));
        }
    }

    private boolean remember(String id) {
        synchronized (seen) {
            if (seen.containsKey(id)) return true;
            seen.put(id, System.currentTimeMillis());
            return false;
        }
    }

    private static String required(JSONObject request, String name) throws JSONException, ProtocolError {
        if (!request.has(name) || request.isNull(name)) {
            throw new ProtocolError("bad_request", "missing " + name, request.optString("id"));
        }
        return request.getString(name);
    }

    private static boolean validId(String id) {
        return id != null && id.matches("[A-Za-z0-9_.:-]{8,64}");
    }

    private static String currentId(byte[] plaintext) {
        try {
            return new JSONObject(new String(plaintext, StandardCharsets.UTF_8)).optString("id", "");
        } catch (Exception e) {
            return "";
        }
    }

    private static JSONObject authFields(String client, String reason) {
        JSONObject out = Json.obj();
        Json.put(out, "client", client);
        Json.put(out, "reason", reason);
        return out;
    }

    private static JSONObject safeArgs(JSONObject request) {
        JSONObject out = Json.obj();
        if (request.has("to") && !request.isNull("to")) {
            Json.put(out, "to", safePath(request.optString("to", "")));
        }
        if (request.has("offset")) Json.put(out, "offset", request.optLong("offset", 0L));
        if (request.has("length")) Json.put(out, "length", request.optInt("length", 0));
        if (request.has("truncate")) Json.put(out, "truncate", request.optBoolean("truncate", false));
        if (request.has("recursive")) Json.put(out, "recursive", request.optBoolean("recursive", false));
        if (request.has("parents")) Json.put(out, "parents", request.optBoolean("parents", false));
        if (request.has("limit")) Json.put(out, "limit", request.optInt("limit", 0));
        if (request.has("maxDepth")) Json.put(out, "maxDepth", request.optInt("maxDepth", 0));
        if (request.has("query")) {
            String query = request.optString("query", "");
            Json.put(out, "queryLen", query.length());
        }
        return out;
    }

    private static void summarize(JSONObject out, JSONObject result) {
        if (result == null) return;
        if (result.has("length")) Json.put(out, "bytes", result.optInt("length", 0));
        if (result.has("written")) Json.put(out, "bytes", result.optInt("written", 0));
        if (result.has("size")) Json.put(out, "size", result.optLong("size", 0L));
        if (result.has("count")) Json.put(out, "count", result.optInt("count", 0));
        if (result.has("truncated")) Json.put(out, "truncated", result.optBoolean("truncated", false));
        if (result.has("eof")) Json.put(out, "eof", result.optBoolean("eof", false));
        if (result.has("type")) Json.put(out, "resultType", safeOp(result.optString("type", "")));
    }

    private static void merge(JSONObject target, JSONObject source) {
        Iterator<String> keys = source.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            try {
                target.put(key, source.opt(key));
            } catch (JSONException ignored) {
            }
        }
    }

    private static String safeClient(String client) {
        if (client == null) return "";
        return client.length() > 64 ? client.substring(0, 64) : client;
    }

    private static String safePath(String path) {
        if (path == null) return "";
        return path.length() > 200 ? path.substring(0, 200) : path;
    }

    private static String safeOp(String op) {
        if (op == null) return "";
        return op.length() > 64 ? op.substring(0, 64) : op;
    }

    private static JSONObject error(String id, String code, String message) {
        JSONObject result = Json.obj();
        Json.put(result, "v", 1);
        Json.put(result, "ok", false);
        Json.put(result, "id", id == null ? "" : id);
        Json.put(result, "serverTime", System.currentTimeMillis());
        Json.put(result, "code", code);
        Json.put(result, "error", message);
        return result;
    }

    private static byte[] encrypt(byte[] key, byte[] aad, JSONObject response) throws AuthException {
        try {
            return Crypto.encrypt(key, aad, response.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new AuthException();
        }
    }

    private static final class ProtocolError extends Exception {
        private static final long serialVersionUID = 1L;
        final String code;
        final String id;

        ProtocolError(String code, String message, String id) {
            super(message);
            this.code = code;
            this.id = id == null ? "" : id;
        }
    }
}

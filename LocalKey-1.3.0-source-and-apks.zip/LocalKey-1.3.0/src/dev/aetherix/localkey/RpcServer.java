package dev.aetherix.localkey;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public final class RpcServer implements Runnable, Closeable {
    public interface Listener {
        void onState(String state);
    }

    private static final int MAX_HEADER_BYTES = 32 * 1024;
    private static final int MAX_HEADERS = 100;
    private static final int MAX_LINE = 8192;
    private static final int MAX_TARGET = 2048;
    private static final int MAX_PAIR = 16 * 1024;
    private static final int MAX_RPC = 8 * 1024 * 1024;
    private static final long CONNECTION_DEADLINE_MS = 60000;

    private final ServerSocket server;
    private final RpcHandler handler;
    private final PairingManager pairing;
    private final EventLog log;
    private final AppInfo appInfo;
    private final Listener listener;
    private final int port;
    private final long started = System.currentTimeMillis();
    private final ThreadPoolExecutor workers;
    private final ScheduledExecutorService deadlines;
    private final Set<Socket> active = ConcurrentHashMap.newKeySet();
    private volatile boolean running = true;

    public RpcServer(int port, RpcHandler handler, PairingManager pairing, EventLog log,
                     AppInfo appInfo, Listener listener) throws IOException {
        this.handler = handler;
        this.pairing = pairing;
        this.log = log;
        this.appInfo = appInfo;
        this.listener = listener;
        this.server = new ServerSocket();
        this.server.setReuseAddress(true);
        this.server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 32);
        this.port = server.getLocalPort();
        this.workers = new ThreadPoolExecutor(4, 4, 30, TimeUnit.SECONDS,
                new ArrayBlockingQueue<Runnable>(16), new NamedThreads("localkey-rpc-"),
                new ThreadPoolExecutor.AbortPolicy());
        this.deadlines = Executors.newSingleThreadScheduledExecutor(new NamedThreads("localkey-timeout-"));
    }

    public int getPort() {
        return port;
    }

    @Override
    public void run() {
        state("listening");
        log.info("server", "listening on 127.0.0.1:" + port);
        while (running) {
            try {
                final Socket socket = server.accept();
                socket.setTcpNoDelay(true);
                active.add(socket);
                try {
                    workers.execute(new Runnable() {
                        @Override
                        public void run() {
                            handle(socket);
                        }
                    });
                } catch (RejectedExecutionException e) {
                    active.remove(socket);
                    closeQuietly(socket);
                }
            } catch (SocketException e) {
                if (running) log.error("server", "socket error");
                break;
            } catch (IOException e) {
                if (running) log.warn("server", "accept failed");
            }
        }
        state("stopped");
        log.info("server", "stopped");
    }

    private void handle(Socket socket) {
        ScheduledFuture<?> deadline = deadlines.schedule(new Runnable() {
            @Override
            public void run() {
                closeQuietly(socket);
            }
        }, CONNECTION_DEADLINE_MS, TimeUnit.MILLISECONDS);

        try (Socket ignored = socket) {
            socket.setSoTimeout(30000);
            BufferedInputStream in = new BufferedInputStream(socket.getInputStream(), 8192);
            BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream(), 8192);

            Request request;
            try {
                request = readRequest(in);
            } catch (HttpError e) {
                reject(out, e.status, e.code, e.getMessage(), null);
                return;
            }
            if (request == null) return;

            if ("GET".equals(request.method) && "/health".equals(request.path)) {
                sendJson(out, 200, health(), null);
                return;
            }

            if ("/pair".equals(request.path)) {
                if (!"POST".equals(request.method)) {
                    reject(out, 405, "method_not_allowed", "POST required", allow("POST"));
                    return;
                }
                if (request.body == null || request.body.length == 0) {
                    reject(out, 400, "bad_request", "missing body", null);
                    return;
                }
                if (request.body.length > MAX_PAIR) {
                    reject(out, 413, "too_large", "pairing body too large", null);
                    return;
                }
                PairingManager.Result result;
                try {
                    result = pairing.pair(new String(request.body, StandardCharsets.UTF_8));
                } catch (RuntimeException e) {
                    log.error("pairing", "pairing request failed");
                    JSONObject failed = Json.obj();
                    Json.put(failed, "status", 500);
                    Json.put(failed, "code", "pairing_failed");
                    log.event("pair_failed", failed);
                    sendJson(out, 500, errorBody("pairing_failed", "pairing failed"), null);
                    return;
                }
                if (result.status != 200) {
                    JSONObject failed = Json.obj();
                    Json.put(failed, "status", result.status);
                    Json.put(failed, "code", result.body.optString("error", "pairing_failed"));
                    log.event("pair_failed", failed);
                }
                sendJson(out, result.status, result.body,
                        result.status == 429 ? "Retry-After: 60\r\n" : null);
                return;
            }

            if ("/rpc".equals(request.path)) {
                if (!"POST".equals(request.method)) {
                    reject(out, 405, "method_not_allowed", "POST required", allow("POST"));
                    return;
                }
                String contentType = request.headers.get("content-type");
                if (contentType == null
                        || !contentType.toLowerCase(Locale.US).startsWith("application/octet-stream")) {
                    reject(out, 415, "unsupported_media_type", "application/octet-stream required", null);
                    return;
                }
                if (request.body == null || request.body.length == 0) {
                    reject(out, 400, "bad_request", "missing body", null);
                    return;
                }
                if (request.body.length > MAX_RPC) {
                    reject(out, 413, "too_large", "request body too large", null);
                    return;
                }
                String client = clientHeader(request);
                if (client != null && !client.matches("[a-f0-9]{16,64}")) {
                    reject(out, 401, "unauthorized", "unauthorized", null);
                    return;
                }
                try {
                    byte[] response = handler.handle(request.body, client);
                    sendBytes(out, 200, "application/octet-stream", response, null);
                } catch (RpcHandler.AuthException e) {
                    reject(out, 401, "unauthorized", "unauthorized", null);
                }
                return;
            }

            reject(out, 404, "not_found", "not found", null);
        } catch (IOException e) {
            // The peer closed the connection or the deadline expired.
        } finally {
            deadline.cancel(false);
            active.remove(socket);
            closeQuietly(socket);
        }
    }

    private JSONObject health() {
        JSONObject result = Json.obj();
        Json.put(result, "ok", true);
        Json.put(result, "app", "localkey");
        Json.put(result, "name", "LocalKey");
        Json.put(result, "v", 1);
        Json.put(result, "time", System.currentTimeMillis());
        Json.put(result, "uptimeMs", System.currentTimeMillis() - started);
        Json.put(result, "port", port);
        Json.put(result, "clients", handler.clientCount());
        Json.put(result, "fingerprint", handler.fingerprint());
        Json.put(result, "pairingActive", pairing.isActive());
        Json.put(result, "requests", handler.requests());
        Json.put(result, "version", appInfo.versionName);
        Json.put(result, "versionCode", appInfo.versionCode);
        Json.put(result, "auditSchema", EventLog.SCHEMA);
        Json.put(result, "sdk", appInfo.sdk);
        Json.put(result, "android", appInfo.android);
        Json.put(result, "model", appInfo.model);
        return result;
    }

    private void reject(OutputStream out, int status, String code, String message,
                        String extraHeaders) throws IOException {
        JSONObject event = Json.obj();
        Json.put(event, "status", status);
        Json.put(event, "code", code);
        Json.put(event, "message", message);
        log.event("http_reject", event);
        sendJson(out, status, errorBody(code, message), extraHeaders);
    }

    private static String clientHeader(Request request) {
        String primary = request.headers.get("x-localkey-client");
        String legacy = request.headers.get("x-latchkey-client");
        if (primary == null) return legacy;
        if (legacy != null && !primary.equals(legacy)) return "invalid";
        return primary;
    }

    private boolean validHost(String host, String version) {
        if (host == null) return !"HTTP/1.1".equals(version);
        String value = host.toLowerCase(Locale.US);
        int colon = value.lastIndexOf(':');
        if (colon >= 0) {
            if (value.indexOf(':') != colon) return false;
            String portValue = value.substring(colon + 1);
            try {
                if (Integer.parseInt(portValue) != port) return false;
            } catch (NumberFormatException e) {
                return false;
            }
            value = value.substring(0, colon);
        }
        return "127.0.0.1".equals(value) || "localhost".equals(value);
    }

    private Request readRequest(InputStream in) throws IOException, HttpError {
        int[] headerBytes = new int[] {0};
        String line = readLine(in, MAX_LINE, headerBytes);
        if (line == null) return null;

        int first = line.indexOf(' ');
        int second = first < 0 ? -1 : line.indexOf(' ', first + 1);
        if (first <= 0 || second <= first + 1 || line.indexOf(' ', second + 1) >= 0) {
            throw new HttpError(400, "bad_request", "malformed request line");
        }
        String method = line.substring(0, first);
        String target = line.substring(first + 1, second);
        String version = line.substring(second + 1);
        if (!"GET".equals(method) && !"POST".equals(method)) {
            throw new HttpError(405, "method_not_allowed", "method not allowed");
        }
        if (!"HTTP/1.1".equals(version) && !"HTTP/1.0".equals(version)) {
            throw new HttpError(400, "bad_request", "unsupported HTTP version");
        }
        if (target.length() > MAX_TARGET || target.indexOf('#') >= 0 || !target.startsWith("/")) {
            throw new HttpError(400, "bad_request", "invalid request target");
        }
        int query = target.indexOf('?');
        String path = query >= 0 ? target.substring(0, query) : target;

        Map<String, String> headers = new HashMap<>();
        int count = 0;
        while (true) {
            line = readLine(in, MAX_LINE, headerBytes);
            if (line == null) throw new HttpError(400, "bad_request", "truncated headers");
            if (line.isEmpty()) break;
            if (++count > MAX_HEADERS) throw new HttpError(400, "bad_request", "too many headers");
            int colon = line.indexOf(':');
            if (colon <= 0) throw new HttpError(400, "bad_request", "malformed header");
            String name = line.substring(0, colon).toLowerCase(Locale.US);
            String value = line.substring(colon + 1).trim();
            if (!name.matches("[a-z0-9!#$%&'*+.^_`|~-]+")) {
                throw new HttpError(400, "bad_request", "invalid header name");
            }
            for (int i = 0; i < value.length(); i++) {
                char c = value.charAt(i);
                if (c < 0x20 || c == 0x7f) throw new HttpError(400, "bad_request", "invalid header value");
            }
            if (headers.put(name, value) != null) {
                throw new HttpError(400, "bad_request", "duplicate header");
            }
        }

        if (headers.containsKey("transfer-encoding") || headers.containsKey("expect")) {
            throw new HttpError(400, "bad_request", "unsupported transfer headers");
        }
        if ("HTTP/1.1".equals(version) && !headers.containsKey("host")) {
            throw new HttpError(400, "bad_request", "missing Host");
        }
        if (headers.containsKey("origin")) {
            throw new HttpError(403, "forbidden", "browser origins are not allowed");
        }
        if (!validHost(headers.get("host"), version)) {
            throw new HttpError(400, "bad_host", "loopback Host required");
        }

        int length = 0;
        int bodyLimit = "/pair".equals(path) ? MAX_PAIR : MAX_RPC;
        String contentLength = headers.get("content-length");
        if (contentLength != null) {
            try {
                long parsed = Long.parseLong(contentLength);
                if (parsed < 0 || parsed > bodyLimit) {
                    throw new HttpError(413, "too_large", "body too large");
                }
                length = (int) parsed;
            } catch (NumberFormatException e) {
                throw new HttpError(400, "bad_request", "invalid Content-Length");
            }
        } else if ("POST".equals(method)) {
            throw new HttpError(411, "length_required", "Content-Length required");
        }
        if ("GET".equals(method) && length != 0) {
            throw new HttpError(400, "bad_request", "GET body not allowed");
        }

        byte[] body = length == 0 ? new byte[0] : readFully(in, length);
        return new Request(method, path, headers, body);
    }

    private static String readLine(InputStream in, int max, int[] total) throws IOException, HttpError {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        boolean sawCarriageReturn = false;
        int value;
        while ((value = in.read()) != -1) {
            if (value == '\n') {
                if (total[0] + buffer.size() > MAX_HEADER_BYTES) {
                    throw new HttpError(400, "bad_request", "headers too large");
                }
                total[0] += buffer.size() + 2;
                return buffer.toString(StandardCharsets.UTF_8.name());
            }
            if (value == '\r') {
                if (sawCarriageReturn) throw new HttpError(400, "bad_request", "invalid line ending");
                sawCarriageReturn = true;
                continue;
            }
            if (sawCarriageReturn) throw new HttpError(400, "bad_request", "invalid line ending");
            buffer.write(value);
            if (buffer.size() > max) throw new HttpError(400, "bad_request", "line too long");
        }
        if (buffer.size() == 0 && !sawCarriageReturn) return null;
        throw new HttpError(400, "bad_request", "truncated request");
    }

    private static byte[] readFully(InputStream in, int length) throws IOException, HttpError {
        byte[] data = new byte[length];
        int offset = 0;
        while (offset < length) {
            int count = in.read(data, offset, length - offset);
            if (count < 0) throw new HttpError(400, "bad_request", "truncated body");
            offset += count;
        }
        return data;
    }

    private static JSONObject errorBody(String code, String message) {
        JSONObject result = Json.obj();
        Json.put(result, "ok", false);
        Json.put(result, "error", code);
        Json.put(result, "message", message);
        return result;
    }

    private static String allow(String methods) {
        return "Allow: " + methods + "\r\n";
    }

    private static void sendJson(OutputStream out, int status, JSONObject body, String extraHeaders)
            throws IOException {
        sendBytes(out, status, "application/json; charset=utf-8",
                body.toString().getBytes(StandardCharsets.UTF_8), extraHeaders);
    }

    private static void sendBytes(OutputStream out, int status, String contentType, byte[] body,
                                  String extraHeaders) throws IOException {
        String reason;
        switch (status) {
            case 200: reason = "OK"; break;
            case 400: reason = "Bad Request"; break;
            case 401: reason = "Unauthorized"; break;
            case 403: reason = "Forbidden"; break;
            case 404: reason = "Not Found"; break;
            case 405: reason = "Method Not Allowed"; break;
            case 409: reason = "Conflict"; break;
            case 411: reason = "Length Required"; break;
            case 413: reason = "Payload Too Large"; break;
            case 415: reason = "Unsupported Media Type"; break;
            case 417: reason = "Expectation Failed"; break;
            case 429: reason = "Too Many Requests"; break;
            case 500: reason = "Internal Server Error"; break;
            case 503: reason = "Service Unavailable"; break;
            default: reason = "Error"; break;
        }
        StringBuilder head = new StringBuilder();
        head.append("HTTP/1.1 ").append(status).append(' ').append(reason).append("\r\n")
                .append("Content-Type: ").append(contentType).append("\r\n")
                .append("Content-Length: ").append(body.length).append("\r\n")
                .append("Cache-Control: no-store\r\n")
                .append("X-Content-Type-Options: nosniff\r\n")
                .append("Connection: close\r\n");
        if (extraHeaders != null) head.append(extraHeaders);
        head.append("\r\n");
        out.write(head.toString().getBytes(StandardCharsets.UTF_8));
        out.write(body);
        out.flush();
    }

    private void state(String value) {
        if (listener == null) return;
        try {
            listener.onState(value);
        } catch (Exception ignored) {
        }
    }

    private static void closeQuietly(Socket socket) {
        try {
            socket.close();
        } catch (IOException ignored) {
        }
    }

    @Override
    public void close() {
        running = false;
        try {
            server.close();
        } catch (IOException ignored) {
        }
        for (Socket socket : active) closeQuietly(socket);
        active.clear();
        workers.shutdownNow();
        deadlines.shutdownNow();
        handler.close();
    }

    private static final class Request {
        final String method;
        final String path;
        final Map<String, String> headers;
        final byte[] body;

        Request(String method, String path, Map<String, String> headers, byte[] body) {
            this.method = method;
            this.path = path;
            this.headers = headers;
            this.body = body;
        }
    }

    private static final class HttpError extends Exception {
        private static final long serialVersionUID = 1L;
        final int status;
        final String code;

        HttpError(int status, String code, String message) {
            super(message);
            this.status = status;
            this.code = code;
        }
    }

    private static final class NamedThreads implements ThreadFactory {
        private final String prefix;
        private final AtomicInteger counter = new AtomicInteger();

        NamedThreads(String prefix) {
            this.prefix = prefix;
        }

        @Override
        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, prefix + counter.incrementAndGet());
            thread.setDaemon(true);
            return thread;
        }
    }
}

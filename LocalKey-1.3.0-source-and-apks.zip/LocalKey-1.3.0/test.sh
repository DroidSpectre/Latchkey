#!/bin/bash
set -euo pipefail

export JAVA_HOME=/opt/jdk-17.0.20.1+1-jre
export PATH="$JAVA_HOME/bin:$PATH"

ROOT=/root/LocalKey
JSON="$ROOT/test-lib/json-20240303.jar"
OUT="$ROOT/build/test-classes"
JAVA="$JAVA_HOME/bin/java"
ECJ=/opt/bionic-build/lib/ecj-3.40.0.jar

python3 - <<'PY'
import shutil, os
shutil.rmtree('/root/LocalKey/build/test-classes', ignore_errors=True)
os.makedirs('/root/LocalKey/build/test-classes', exist_ok=True)
PY

"$JAVA" -jar "$ECJ" -source 8 -target 8 -cp "$JSON" -d "$OUT" \
    "$ROOT/src/dev/aetherix/localkey/Json.java" \
    "$ROOT/src/dev/aetherix/localkey/Crypto.java" \
    "$ROOT/src/dev/aetherix/localkey/PathGuard.java" \
    "$ROOT/src/dev/aetherix/localkey/FileApi.java" \
    "$ROOT/test/TestMain.java" \
    "$ROOT/test/CryptoFixture.java"

"$JAVA" -cp "$JSON:$OUT" TestMain
python3 "$ROOT/client/test_client.py"
python3 "$ROOT/client/test_cross_language.py" "$OUT"

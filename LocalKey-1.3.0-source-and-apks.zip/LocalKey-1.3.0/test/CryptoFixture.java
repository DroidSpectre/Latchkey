import dev.aetherix.localkey.Crypto;

import java.util.Base64;

public final class CryptoFixture {
    public static void main(String[] args) throws Exception {
        if (args.length != 4) {
            System.err.println("usage: encrypt|decrypt keyB64 aadB64 dataB64");
            System.exit(2);
        }
        byte[] key = Base64.getUrlDecoder().decode(args[1]);
        byte[] aad = Base64.getUrlDecoder().decode(args[2]);
        byte[] data = Base64.getUrlDecoder().decode(args[3]);
        byte[] out = "encrypt".equals(args[0])
                ? Crypto.encrypt(key, aad, data)
                : Crypto.decrypt(key, aad, data);
        System.out.println(Base64.getUrlEncoder().withoutPadding().encodeToString(out));
    }
}

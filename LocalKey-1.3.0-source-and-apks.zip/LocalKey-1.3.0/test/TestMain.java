import dev.aetherix.localkey.Crypto;
import dev.aetherix.localkey.FileApi;
import dev.aetherix.localkey.PathGuard;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.GeneralSecurityException;
import java.util.Base64;

public final class TestMain {
    private static int checks;

    public static void main(String[] args) throws Exception {
        File root = Files.createTempDirectory("localkey-root").toFile();
        File outside = Files.createTempDirectory("localkey-outside").toFile();
        try {
            crypto();
            guard(root);
            files(root, outside);
            System.out.println("OK " + checks + " checks");
        } catch (Throwable error) {
            error.printStackTrace(System.err);
            System.exit(1);
        } finally {
            deleteTree(root);
            deleteTree(outside);
        }
    }

    private static void crypto() throws Exception {
        byte[] key = Crypto.random(32);
        byte[] aad = "aad".getBytes(StandardCharsets.UTF_8);
        byte[] blob = Crypto.encrypt(key, aad, "secret".getBytes(StandardCharsets.UTF_8));
        check(blob.length >= 28, "ciphertext length");
        byte[] plain = Crypto.decrypt(key, aad, blob);
        eq("secret", new String(plain, StandardCharsets.UTF_8), "round trip");
        try {
            Crypto.decrypt(key, "other".getBytes(StandardCharsets.UTF_8), blob);
            check(false, "wrong AAD must fail");
        } catch (GeneralSecurityException expected) {
            checks++;
        }
        eq(16, Crypto.fingerprint(key).length(), "fingerprint length");
        check(Crypto.constantTimeEquals(Crypto.sha256("x"), Crypto.sha256("x")), "constant time equals");
        eq(32, Crypto.unb64(Crypto.b64(Crypto.random(32))).length, "base64 round trip");
    }

    private static void guard(File root) throws Exception {
        PathGuard guard = new PathGuard(root);
        eq(root.getCanonicalFile(), guard.resolve("."), "relative root");
        eq(root.getCanonicalFile(), guard.resolve(""), "empty path root");
        expectSecurity(guard, "../outside");
        expectSecurity(guard, "/etc/passwd");
        expectSecurity(guard, "a\0b");
    }

    private static void files(File root, File outside) throws Exception {
        FileApi api = new FileApi(root);
        JSONObject info = api.info();
        eq(root.getAbsolutePath(), info.getString("root"), "info root");

        api.mkdir("a", true);
        api.write("a/one.txt", 0, "hello".getBytes(StandardCharsets.UTF_8), true);
        JSONObject stat = api.stat("a/one.txt");
        eq("file", stat.getString("type"), "stat type");
        eq(5L, stat.getLong("size"), "stat size");

        JSONObject read = api.read("a/one.txt", 1, 3);
        eq("ell", new String(Base64.getDecoder().decode(read.getString("data")),
                StandardCharsets.UTF_8), "read offset");
        eq(5L, read.getLong("size"), "read size");
        check(!read.getBoolean("eof"), "read not eof");

        JSONObject hash = api.hash("a/one.txt");
        eq("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824",
                hash.getString("value"), "sha256");

        JSONObject list = api.list("a", 100);
        eq(1, list.getJSONArray("entries").length(), "list count");
        eq("one.txt", list.getJSONArray("entries").getJSONObject(0).getString("name"), "list name");

        api.copy("a/one.txt", "a/two.txt");
        eq("hello", new String(Base64.getDecoder().decode(
                api.read("a/two.txt", 0, 10).getString("data")), StandardCharsets.UTF_8), "copy file");

        api.move("a/two.txt", "a/three.txt");
        eq("file", api.stat("a/three.txt").getString("type"), "move file");
        expectCode(api, "stat", "a/two.txt", "not_found");

        JSONObject search = api.search(".", "three", 5, 20);
        check(containsName(search.getJSONArray("entries"), "three.txt"), "search file");

        api.mkdir("a/sub", false);
        api.copy("a", "b");
        eq("file", api.stat("b/three.txt").getString("type"), "copy directory");
        check(contains(api.search(".", "three", 5, 20).getJSONArray("entries"), "b/three.txt"),
                "search copied directory");
        expectCode(api, "delete", "a", "not_empty");
        api.delete("b", true);
        api.delete("a", true);
        api.mkdir("empty", false);
        api.delete("empty", false);
        expectCode(api, "delete", "", "bad_request");
        expectCode(api, "stat", "/etc/passwd", "bad_path");
        expectCode(api, "write", "../escape.txt", "bad_path");

        File secret = new File(outside, "secret.txt");
        Files.write(secret.toPath(), "outside".getBytes(StandardCharsets.UTF_8));
        boolean linked = false;
        try {
            Files.createSymbolicLink(root.toPath().resolve("escape"), outside.toPath());
            linked = true;
        } catch (IOException | UnsupportedOperationException | SecurityException ignored) {
        }
        if (linked) {
            check(!containsName(api.list(".", 100).getJSONArray("entries"), "escape"),
                    "list skips escaping symlink");
            check(api.search(".", "escape", 6, 20).getJSONArray("entries").length() == 0,
                    "search skips symlinks");
            try {
                new PathGuard(root).resolve("escape");
                check(false, "symlink escape must fail");
            } catch (SecurityException expected) {
                checks++;
            }
        }
    }

    private static void expectCode(FileApi api, String operation, String path, String code) throws Exception {
        try {
            if ("stat".equals(operation)) api.stat(path);
            else if ("delete".equals(operation)) api.delete(path, false);
            else if ("write".equals(operation)) api.write(path, 0, new byte[0], true);
            else throw new IllegalArgumentException(operation);
            check(false, "expected " + code);
        } catch (FileApi.Error e) {
            eq(code, e.code, "error code for " + operation + " " + path);
        }
    }

    private static void expectSecurity(PathGuard guard, String path) throws Exception {
        try {
            guard.resolve(path);
            check(false, "expected path rejection: " + path);
        } catch (SecurityException expected) {
            checks++;
        }
    }

    private static boolean contains(JSONArray entries, String path) {
        for (int i = 0; i < entries.length(); i++) {
            JSONObject entry = entries.optJSONObject(i);
            if (entry != null && path.equals(entry.optString("path"))) return true;
        }
        return false;
    }

    private static boolean containsName(JSONArray entries, String name) {
        for (int i = 0; i < entries.length(); i++) {
            JSONObject entry = entries.optJSONObject(i);
            if (entry != null && name.equals(entry.optString("name"))) return true;
        }
        return false;
    }

    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }

    private static void eq(Object expected, Object actual, String label) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError(label + ": expected " + expected + ", got " + actual);
        }
        checks++;
    }

    private static void deleteTree(File root) throws IOException {
        if (root == null || !root.exists()) return;
        Files.walkFileTree(root.toPath(), new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.deleteIfExists(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException error) throws IOException {
                if (error != null) throw error;
                Files.deleteIfExists(dir);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}
